import { AlertCircle, RefreshCw, Search, SlidersHorizontal, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { CartItem, Category, Product } from '../types/pos';
import { ProductCard } from './ProductCard';

interface CatalogViewProps {
  products: Product[];
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  cartItems: CartItem[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onUpdateCartQty: (productId: string, nextQty: number) => void;
  isLoading: boolean;
  catalogError: string | null;
  onRetryCatalog: () => void;
}

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'stock-desc';

export function CatalogView({
  products,
  categories,
  selectedCategory,
  onSelectCategory,
  cartItems,
  onSelectProduct,
  onAddToCart,
  onUpdateCartQty,
  isLoading,
  catalogError,
  onRetryCatalog,
}: CatalogViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortOption>('featured');

  const filteredProducts = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    const matched = products.filter((product) => {
      const matchesCategory =
        selectedCategory === 'all' || product.categoryId === selectedCategory;
      if (!matchesCategory) return false;

      if (!query) return true;
      return (
        product.name.toLowerCase().includes(query) ||
        product.categoryName.toLowerCase().includes(query) ||
        product.sku.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query)
      );
    });

    return [...matched].sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'stock-desc') return b.stock - a.stock;
      return Number(Boolean(b.featured)) - Number(Boolean(a.featured));
    });
  }, [products, selectedCategory, searchQuery, sortBy]);

  function getCartQty(productId: string): number {
    return cartItems.find((c) => c.product.id === productId)?.quantity ?? 0;
  }

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-10 space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight">
            Katalog Produk
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Menampilkan <span className="font-mono tabular-nums font-semibold text-slate-900">{filteredProducts.length}</span> produk dari inventaris toko.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
          <div className="relative flex-1 sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Cari nama produk atau SKU..."
              aria-label="Cari produk"
              className="w-full min-h-[44px] pl-10 pr-9 py-2 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                aria-label="Hapus kata kunci pencarian"
                className="w-8 h-8 flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-700 absolute right-1.5 top-1/2 -translate-y-1/2"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="relative shrink-0">
            <SlidersHorizontal className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              aria-label="Urutkan produk"
              className="w-full sm:w-auto min-h-[44px] pl-10 pr-8 py-2 rounded-xl border border-slate-300 bg-white text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
            >
              <option value="featured">Urutan Utama</option>
              <option value="price-asc">Harga Terendah</option>
              <option value="price-desc">Harga Tertinggi</option>
              <option value="stock-desc">Stok Terbanyak</option>
            </select>
          </div>
        </div>
      </div>

      <div
        role="tablist"
        aria-label="Filter kategori produk"
        className="flex items-center gap-2 overflow-x-auto pb-1"
      >
        <button
          type="button"
          role="tab"
          aria-selected={selectedCategory === 'all'}
          onClick={() => onSelectCategory('all')}
          className={`min-h-[42px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors ${
            selectedCategory === 'all'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white border border-slate-200 text-slate-700 hover:border-blue-300 hover:text-blue-700'
          }`}
        >
          Semua Produk
        </button>

        {categories.map((category) => {
          const isActive = selectedCategory === category.id;
          return (
            <button
              key={category.id}
              type="button"
              role="tab"
              aria-selected={isActive}
              onClick={() => onSelectCategory(category.id)}
              className={`min-h-[42px] px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white border border-slate-200 text-slate-700 hover:border-blue-300 hover:text-blue-700'
              }`}
            >
              {category.name}
            </button>
          );
        })}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {Array.from({ length: 8 }).map((_, idx) => (
            <div
              key={idx}
              className="bg-white border border-slate-200 rounded-2xl overflow-hidden animate-pulse"
            >
              <div className="aspect-[4/3] bg-slate-200" />
              <div className="p-4 space-y-3">
                <div className="h-3 w-24 bg-slate-200 rounded" />
                <div className="h-4 w-full bg-slate-200 rounded" />
                <div className="h-9 w-full bg-slate-100 rounded-xl" />
              </div>
            </div>
          ))}
        </div>
      ) : catalogError ? (
        <div className="bg-white border border-amber-200 rounded-3xl p-8 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-6 h-6" />
          </div>
          <p className="text-base font-semibold text-slate-900">
            Katalog Owner Belum Tersedia
          </p>
          <p className="text-sm text-slate-600 max-w-lg mx-auto">
            {catalogError}
          </p>
          <button
            type="button"
            onClick={onRetryCatalog}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Muat Ulang Katalog</span>
          </button>
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-3">
          <p className="text-base font-semibold text-slate-900">
            Produk tidak ditemukan
          </p>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Tidak ada produk yang cocok dengan pencarian atau kategori yang dipilih.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              onSelectCategory('all');
            }}
            className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors"
          >
            Reset Filter
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              cartQuantity={getCartQty(product.id)}
              onSelect={onSelectProduct}
              onAdd={onAddToCart}
              onUpdateQty={onUpdateCartQty}
            />
          ))}
        </div>
      )}
    </section>
  );
}
