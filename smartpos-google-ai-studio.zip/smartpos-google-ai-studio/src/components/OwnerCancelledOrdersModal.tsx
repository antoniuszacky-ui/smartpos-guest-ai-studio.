import {
  AlertTriangle,
  Ban,
  CheckCircle2,
  Lock,
  LogIn,
  LogOut,
  RefreshCw,
  Search,
  ShieldCheck,
  Trash2,
  X,
} from 'lucide-react';
import {
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { apiUrl } from '../lib/api';
import { auth } from '../lib/firebase';
import type { OwnerGuestOrder, OwnerOrderFilter } from '../types/pos';
import { formatDateTimeID, formatRupiah } from '../utils/format';

interface OwnerCancelledOrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface OrderCounts {
  all: number;
  cancelled: number;
  active: number;
  completed: number;
}

function formatOwnerStatusLabel(status: string): string {
  const upper = status.toUpperCase();
  if (upper === 'CANCELLED' || upper === 'BATAL') return 'BATAL (Dibatalkan)';
  if (upper === 'REJECTED') return 'BATAL (Ditolak)';
  if (upper === 'COMPLETED') return 'SELESAI (Transaksi Kasir)';
  if (upper === 'ACCEPTED') return 'DITERIMA';
  if (upper === 'READY') return 'SIAP / DIKIRIM';
  return 'MENUNGGU (PENDING)';
}

function isCancelledStatus(status: string): boolean {
  const upper = status.toUpperCase();
  return upper === 'CANCELLED' || upper === 'REJECTED' || upper === 'BATAL';
}

export function OwnerCancelledOrdersModal({
  isOpen,
  onClose,
}: OwnerCancelledOrdersModalProps) {
  const [user, setUser] = useState<User | null>(() => auth.currentUser);
  const [authLoading, setAuthLoading] = useState(false);
  const [filter, setFilter] = useState<OwnerOrderFilter>('cancelled');
  const [searchQuery, setSearchQuery] = useState('');
  const [orders, setOrders] = useState<OwnerGuestOrder[]>([]);
  const [counts, setCounts] = useState<OrderCounts>({
    all: 0,
    cancelled: 0,
    active: 0,
    completed: 0,
  });
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);
  const [actionOrderId, setActionOrderId] = useState<string | null>(null);
  const [confirmDeleteOrder, setConfirmDeleteOrder] =
    useState<OwnerGuestOrder | null>(null);
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (nextUser) => {
      setUser(nextUser);
    });
    return () => unsub();
  }, []);

  const loadOrders = useCallback(
    async (activeUser: User | null, nextFilter: OwnerOrderFilter) => {
      if (!activeUser) return;
      try {
        setIsLoadingOrders(true);
        const token = await activeUser.getIdToken();
        const res = await fetch(
          apiUrl(`/api/owner/guest-orders?filter=${encodeURIComponent(nextFilter)}`),
          {
            cache: 'no-store',
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        const data = await res.json().catch(() => ({}));
        if (!res.ok) {
          setOrders([]);
          setFeedback({
            type: 'error',
            message:
              typeof data?.error === 'string' && data.error
                ? data.error
                : 'Gagal memuat daftar pesanan Owner.',
          });
          return;
        }
        setOrders(Array.isArray(data.orders) ? data.orders : []);
        if (data.counts) {
          setCounts(data.counts);
        }
      } catch {
        setFeedback({
          type: 'error',
          message: 'Koneksi ke server terganggu saat memuat daftar pesanan.',
        });
      } finally {
        setIsLoadingOrders(false);
      }
    },
    []
  );

  useEffect(() => {
    if (!isOpen || !user) return;
    setFeedback(null);
    void loadOrders(user, filter);
  }, [isOpen, user, filter, loadOrders]);

  useEffect(() => {
    if (!isOpen) {
      setConfirmDeleteOrder(null);
      setFeedback(null);
      return;
    }
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (confirmDeleteOrder) {
          setConfirmDeleteOrder(null);
        } else {
          onClose();
        }
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, confirmDeleteOrder, onClose]);

  const filteredBySearch = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return orders;
    return orders.filter(
      (ord) =>
        ord.orderNumber.toLowerCase().includes(q) ||
        ord.customerName.toLowerCase().includes(q) ||
        ord.customerPhone.toLowerCase().includes(q)
    );
  }, [orders, searchQuery]);

  if (!isOpen) return null;

  async function handleOwnerSignIn() {
    setFeedback(null);
    try {
      setAuthLoading(true);
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);
    } catch {
      setFeedback({
        type: 'error',
        message:
          'Login Google Owner dibatalkan atau gagal. Gunakan akun Google pemilik toko ADEAMIN SHOP.',
      });
    } finally {
      setAuthLoading(false);
    }
  }

  async function handleOwnerSignOut() {
    await signOut(auth);
    setOrders([]);
    setConfirmDeleteOrder(null);
    setFeedback(null);
  }

  async function handleCancelOrder(order: OwnerGuestOrder) {
    if (!user) return;
    setFeedback(null);
    try {
      setActionOrderId(order.id);
      const token = await user.getIdToken();
      const res = await fetch(
        apiUrl(`/api/owner/guest-orders/${encodeURIComponent(order.id)}/cancel`),
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ reason: 'Dibatalkan oleh Owner' }),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setFeedback({
          type: 'error',
          message:
            typeof data?.error === 'string' && data.error
              ? data.error
              : 'Pesanan tidak dapat dibatalkan.',
        });
        return;
      }

      const restoredCount = Number(data?.restoredProductCount ?? 0);
      setFeedback({
        type: 'success',
        message:
          restoredCount > 0
            ? `Pesanan ${order.orderNumber} dibatalkan dan stok ${restoredCount} produk dikembalikan satu kali.`
            : `Pesanan ${order.orderNumber} berstatus BATAL (stok tidak diubah karena belum pernah dipotong).`,
      });
      await loadOrders(user, filter);
    } catch {
      setFeedback({
        type: 'error',
        message: 'Gagal menghubungi server saat membatalkan pesanan.',
      });
    } finally {
      setActionOrderId(null);
    }
  }

  async function handleConfirmDeleteOrder() {
    if (!user || !confirmDeleteOrder) return;
    const target = confirmDeleteOrder;
    setFeedback(null);
    try {
      setActionOrderId(target.id);
      const token = await user.getIdToken();
      const res = await fetch(
        apiUrl(`/api/owner/guest-orders/${encodeURIComponent(target.id)}`),
        {
          method: 'DELETE',
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setConfirmDeleteOrder(null);
        setFeedback({
          type: 'error',
          message:
            typeof data?.error === 'string' && data.error
              ? data.error
              : 'Penghapusan pesanan ditolak oleh server.',
        });
        return;
      }

      setConfirmDeleteOrder(null);
      setFeedback({
        type: 'success',
        message: `Pesanan batal ${target.orderNumber} telah dihapus permanen tanpa memengaruhi transaksi Kasir maupun laporan keuangan.`,
      });
      await loadOrders(user, filter);
    } catch {
      setConfirmDeleteOrder(null);
      setFeedback({
        type: 'error',
        message: 'Koneksi terganggu saat menghapus pesanan.',
      });
    } finally {
      setActionOrderId(null);
    }
  }

  const filterTabs: Array<{
    key: OwnerOrderFilter;
    label: string;
    count: number;
  }> = [
    { key: 'cancelled', label: 'Pesanan BATAL', count: counts.cancelled },
    { key: 'active', label: 'Aktif', count: counts.active },
    { key: 'completed', label: 'Transaksi Kasir', count: counts.completed },
    { key: 'all', label: 'Semua', count: counts.all },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/55 backdrop-blur-xs p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Pengelolaan Pesanan Batal Owner"
      onClick={onClose}
    >
      <div
        className="w-full max-w-4xl max-h-[90vh] bg-white rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4 bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">
                Kelola Pesanan Batal (Owner)
              </h2>
              <p className="text-xs text-slate-500">
                Bersihkan pesanan tamu berstatus BATAL tanpa mengubah transaksi Kasir atau laporan keuangan.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user && (
              <button
                type="button"
                onClick={handleOwnerSignOut}
                className="min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Keluar</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Tutup panel Owner"
              className="w-10 h-10 flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-200/60"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {feedback && (
            <div
              role="alert"
              className={`p-3.5 rounded-2xl border text-sm flex items-start gap-2.5 ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              )}
              <span>{feedback.message}</span>
            </div>
          )}

          {!user ? (
            <div className="py-10 px-4 text-center max-w-md mx-auto space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Verifikasi Akun Owner Diperlukan
                </h3>
                <p className="mt-1.5 text-sm text-slate-600 leading-relaxed">
                  Pelanggan umum tidak memerlukan login. Fitur pembersihan pesanan batal ini khusus untuk Owner ADEAMIN SHOP menggunakan akun Google pemilik toko.
                </p>
              </div>
              <button
                type="button"
                onClick={handleOwnerSignIn}
                disabled={authLoading}
                className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold inline-flex items-center gap-2 shadow-sm shadow-blue-600/20"
              >
                <LogIn className="w-4 h-4" />
                <span>
                  {authLoading
                    ? 'Menghubungkan...'
                    : 'Login Google sebagai Owner'}
                </span>
              </button>
            </div>
          ) : (
            <>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex flex-wrap gap-2">
                  {filterTabs.map((tab) => {
                    const active = filter === tab.key;
                    return (
                      <button
                        key={tab.key}
                        type="button"
                        onClick={() => setFilter(tab.key)}
                        className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold border transition-colors inline-flex items-center gap-1.5 ${
                          active
                            ? 'bg-blue-600 border-blue-600 text-white'
                            : 'bg-white border-slate-200 text-slate-700 hover:border-blue-300'
                        }`}
                      >
                        <span>{tab.label}</span>
                        <span
                          className={`px-1.5 py-0.5 rounded-md font-mono text-[11px] ${
                            active
                              ? 'bg-white/20 text-white'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {tab.count}
                        </span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative flex-1 sm:w-56">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Cari order / nama..."
                      className="w-full min-h-[38px] pl-8 pr-3 py-1.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => loadOrders(user, filter)}
                    disabled={isLoadingOrders}
                    aria-label="Muat ulang daftar pesanan"
                    className="min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <RefreshCw
                      className={`w-3.5 h-3.5 ${
                        isLoadingOrders ? 'animate-spin' : ''
                      }`}
                    />
                    <span className="hidden sm:inline">Muat Ulang</span>
                  </button>
                </div>
              </div>

              {isLoadingOrders ? (
                <div className="py-12 text-center text-sm text-slate-500">
                  Memuat daftar pesanan dari database Owner...
                </div>
              ) : filteredBySearch.length === 0 ? (
                <div className="py-12 px-4 rounded-2xl border border-dashed border-slate-200 bg-slate-50/50 text-center">
                  <p className="text-sm font-semibold text-slate-800">
                    {filter === 'cancelled'
                      ? 'Tidak ada pesanan berstatus BATAL'
                      : 'Tidak ada pesanan pada filter ini'}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Pesanan tamu yang dibatalkan atau ditolak akan muncul di filter Pesanan BATAL untuk dibersihkan.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredBySearch.map((ord) => {
                    const cancelled = isCancelledStatus(ord.status);
                    const isBusy = actionOrderId === ord.id;
                    const canCancel =
                      !cancelled &&
                      !ord.linkedToCashierTransaction &&
                      ord.status.toUpperCase() !== 'COMPLETED';

                    return (
                      <div
                        key={ord.id}
                        className="p-4 rounded-2xl border border-slate-200 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="space-y-1.5 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono text-sm font-bold text-slate-900">
                              {ord.orderNumber}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-md text-[11px] font-semibold ${
                                cancelled
                                  ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                  : ord.linkedToCashierTransaction
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-blue-50 text-blue-700 border border-blue-200'
                              }`}
                            >
                              {formatOwnerStatusLabel(ord.status)}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              {ord.stockDeducted
                                ? ord.stockRestored
                                  ? 'Stok sudah dikembalikan'
                                  : 'Stok sempat dipotong'
                                : 'Stok belum dipotong'}
                            </span>
                          </div>

                          <p className="text-sm text-slate-800 font-medium">
                            {ord.customerName}{' '}
                            <span className="text-xs font-mono text-slate-500">
                              ({ord.customerPhone})
                            </span>
                          </p>

                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                            <span className="font-mono font-bold text-blue-700">
                              {formatRupiah(ord.totalAmount)}
                            </span>
                            <span>{ord.items.length} jenis barang</span>
                            <span>{formatDateTimeID(ord.createdAt)}</span>
                          </div>

                          {ord.linkedToCashierTransaction && (
                            <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-2.5 py-1.5 inline-flex items-center gap-1.5">
                              <Lock className="w-3.5 h-3.5 shrink-0" />
                              <span>
                                {ord.deleteBlockedReason ||
                                  'Terhubung transaksi Kasir — dilindungi dari penghapusan.'}
                              </span>
                            </p>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-2 shrink-0">
                          {canCancel && (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => handleCancelOrder(ord)}
                              className="min-h-[38px] px-3.5 py-1.5 rounded-xl border border-amber-300 bg-amber-50 hover:bg-amber-100 disabled:opacity-60 text-amber-900 text-xs font-semibold inline-flex items-center gap-1.5"
                            >
                              <Ban className="w-3.5 h-3.5" />
                              <span>Batalkan</span>
                            </button>
                          )}

                          {ord.canDelete ? (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => setConfirmDeleteOrder(ord)}
                              className="min-h-[38px] px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Hapus Permanen</span>
                            </button>
                          ) : (
                            <span
                              title={ord.deleteBlockedReason}
                              className="min-h-[38px] px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-400 text-xs font-medium inline-flex items-center gap-1.5 cursor-not-allowed"
                            >
                              <Lock className="w-3.5 h-3.5" />
                              <span>Terkunci</span>
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {confirmDeleteOrder && (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/60 p-4"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="confirm-delete-title"
          onClick={() => setConfirmDeleteOrder(null)}
        >
          <div
            className="w-full max-w-md bg-white rounded-2xl border border-slate-200 shadow-2xl p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3
                  id="confirm-delete-title"
                  className="text-base font-bold text-slate-900"
                >
                  Yakin ingin menghapus pesanan ini secara permanen?
                </h3>
                <p className="mt-1 text-xs text-slate-500">
                  Hanya dokumen pesanan batal ini yang akan dihapus. Riwayat transaksi Kasir, laporan keuangan, dan data produk tidak akan dihapus.
                </p>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between gap-2">
                <span className="text-slate-500">Nomor Order</span>
                <span className="font-mono font-bold text-slate-900">
                  {confirmDeleteOrder.orderNumber}
                </span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-slate-500">Nama Pelanggan</span>
                <span className="font-semibold text-slate-900">
                  {confirmDeleteOrder.customerName}
                </span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-slate-500">Total Pesanan</span>
                <span className="font-mono font-bold text-blue-700">
                  {formatRupiah(confirmDeleteOrder.totalAmount)}
                </span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-slate-500">Status</span>
                <span className="font-semibold text-rose-700">
                  {formatOwnerStatusLabel(confirmDeleteOrder.status)}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setConfirmDeleteOrder(null)}
                className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold"
              >
                Batal
              </button>
              <button
                type="button"
                disabled={actionOrderId === confirmDeleteOrder.id}
                onClick={handleConfirmDeleteOrder}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>
                  {actionOrderId === confirmDeleteOrder.id
                    ? 'Menghapus...'
                    : 'Ya, Hapus Permanen'}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
