import assert from 'node:assert/strict';
import test from 'node:test';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { createServer as createViteServer } from 'vite';
import type { GuestOrder, ShippingStatus } from '../types/pos.ts';
import {
  copyTrackingNumberText,
  getJntShippingViewModel,
} from './orderShippingView.ts';

const vite = await createViteServer({
  server: { middlewareMode: true },
  appType: 'custom',
});

const { OrderStatusPage } = (await vite.ssrLoadModule(
  '/src/components/OrderStatusPage.tsx'
)) as typeof import('../components/OrderStatusPage.tsx');

test.after(async () => {
  await vite.close();
});

function makeBaseOrder(overrides: Partial<GuestOrder> = {}): GuestOrder {
  return {
    id: 'gord_123',
    orderNumber: 'SPG-261120-ABC123',
    customerName: 'Budi Santoso',
    customerPhone: '********7890',
    fulfillmentType: 'delivery',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 15 Ponorogo',
    notes: 'Taruh di teras',
    items: [
      {
        productId: 'prod_1',
        sku: 'SKU-1',
        name: 'My Baby Lotion 100ml',
        unitPrice: 20000,
        quantity: 2,
        subtotal: 40000,
        weightGrams: 200,
        imageUrl: '',
      },
    ],
    itemsSubtotal: 40000,
    totalAmount: 40000,
    status: 'ACCEPTED',
    stockDeducted: false,
    createdAt: '2026-11-20T10:00:00.000Z',
    updatedAt: '2026-11-20T10:05:00.000Z',
    ...overrides,
  };
}

function renderOrderPage(order: GuestOrder): string {
  return renderToStaticMarkup(
    React.createElement(OrderStatusPage, {
      activeOrder: order,
      recentOrders: [order],
      onOrderLoaded: () => {},
      onBackToCatalog: () => {},
    })
  );
}

test('renders J&T Express unconfirmed fee, empty AWB, and incomplete weight indicator cleanly', () => {
  const order = makeBaseOrder({
    shipping: {
      provider: 'JNT_EXPRESS',
      status: 'PENDING_RATE',
      totalWeightGrams: 400,
      hasUnweighedItems: true,
      shippingFee: 0,
      shippingFeeConfirmed: false,
    },
  });

  const vm = getJntShippingViewModel(order);
  assert.ok(vm);
  assert.equal(vm.isShippingFeeConfirmed, false);
  assert.equal(vm.hasTrackingNumber, false);
  assert.equal(vm.hasIncompleteWeightWarning, true);
  assert.equal(vm.totalLabel, 'Total Sementara');

  const html = renderOrderPage(order);
  assert.match(html, /J&amp;T Express|J&T Express/);
  assert.match(html, /Menunggu konfirmasi ongkir/);
  assert.match(html, /Ongkos kirim sedang menunggu konfirmasi Owner\./);
  assert.match(html, /Nomor resi belum tersedia/);
  assert.match(html, /400 g/);
  assert.match(html, /Sebagian produk belum memiliki data berat lengkap/);
  assert.match(html, /Total Sementara/);
  assert.doesNotMatch(html, /Salin Resi/);
});

test('renders confirmed J&T shipping fee, AWB with copy button, weight in kg, and shipping statuses', () => {
  const expectedLabels: Record<
    Exclude<ShippingStatus, 'PENDING_RATE' | 'FAILED'>,
    string
  > = {
    READY_TO_SHIP: 'Menunggu pengiriman',
    PICKED_UP: 'Paket telah diambil kurir',
    IN_TRANSIT: 'Paket sedang dalam perjalanan',
    DELIVERED: 'Paket telah diterima',
  };

  for (const [status, label] of Object.entries(expectedLabels)) {
    const order = makeBaseOrder({
      itemsSubtotal: 40000,
      totalAmount: 54000,
      shipping: {
        provider: 'JNT_EXPRESS',
        serviceCode: 'EZ',
        status: status as ShippingStatus,
        totalWeightGrams: 1400,
        hasUnweighedItems: false,
        shippingFee: 14000,
        shippingFeeConfirmed: true,
        trackingNumber: 'JP9988776655',
        shippedAt: status === 'READY_TO_SHIP' ? undefined : '2026-11-20T11:00:00.000Z',
        deliveredAt: status === 'DELIVERED' ? '2026-11-21T14:00:00.000Z' : undefined,
      },
    });

    const html = renderOrderPage(order);
    assert.match(html, new RegExp(label));
    assert.match(html, /J&amp;T Express · EZ|J&T Express · EZ/);
    assert.match(html, /JP9988776655/);
    assert.match(html, /Salin Resi/);
    assert.match(html, /1\.400 g \(1,4 kg\)/);
    assert.match(html, /Subtotal Barang/);
    assert.match(html, /14\.000/);
    assert.match(html, /Total Pembayaran/);
    assert.match(html, /54\.000/);
  }
});

test('renders neutral FAILED shipping state without breaking main order status progress bar', () => {
  const order = makeBaseOrder({
    status: 'READY',
    itemsSubtotal: 40000,
    totalAmount: 54000,
    shipping: {
      provider: 'JNT_EXPRESS',
      status: 'FAILED',
      totalWeightGrams: 400,
      shippingFee: 14000,
      shippingFeeConfirmed: true,
      trackingNumber: 'JP9988776655',
    },
  });

  const vm = getJntShippingViewModel(order);
  assert.ok(vm);
  assert.equal(vm.isFailed, true);
  assert.equal(vm.statusLabel, 'Pengiriman mengalami kendala');

  const html = renderOrderPage(order);
  assert.match(html, /Pengiriman mengalami kendala/);
  // Main 4-step order progress stays intact
  assert.match(html, /Menunggu/);
  assert.match(html, /Diproses/);
  assert.match(html, /Dikirim/);
  assert.match(html, /Selesai/);
});

test('preserves legacy display for pickup, STORE_COURIER, and legacy delivery without shipping', () => {
  const pickupOrder = makeBaseOrder({
    fulfillmentType: 'pickup',
    deliveryAddress: '',
    shipping: undefined,
  });
  assert.equal(getJntShippingViewModel(pickupOrder), null);
  const pickupHtml = renderOrderPage(pickupOrder);
  assert.match(pickupHtml, /Ambil di Toko/);
  assert.doesNotMatch(pickupHtml, /Informasi Pengiriman/);

  const storeCourierOrder = makeBaseOrder({
    fulfillmentType: 'delivery',
    shipping: {
      provider: 'STORE_COURIER',
      totalWeightGrams: 400,
      shippingFee: 0,
      shippingFeeConfirmed: true,
    },
  });
  assert.equal(getJntShippingViewModel(storeCourierOrder), null);
  const storeCourierHtml = renderOrderPage(storeCourierOrder);
  assert.match(storeCourierHtml, /Kirim ke Alamat/);
  assert.doesNotMatch(storeCourierHtml, /J&amp;T Express|J&T Express/);

  const legacyDeliveryOrder = makeBaseOrder({
    fulfillmentType: 'delivery',
    itemsSubtotal: undefined,
    shipping: undefined,
  });
  assert.equal(getJntShippingViewModel(legacyDeliveryOrder), null);
  const legacyHtml = renderOrderPage(legacyDeliveryOrder);
  assert.match(legacyHtml, /Kirim ke Alamat/);
  assert.match(legacyHtml, /Total Pembayaran/);
  assert.doesNotMatch(legacyHtml, /Informasi Pengiriman/);
});

test('copyTrackingNumberText copies tracking number cleanly via Clipboard API', async () => {
  let copiedValue = '';
  const originalNavigator = globalThis.navigator;
  Object.defineProperty(globalThis, 'navigator', {
    configurable: true,
    value: {
      clipboard: {
        writeText: async (text: string) => {
          copiedValue = text;
        },
      },
    },
  });

  try {
    const ok = await copyTrackingNumberText(' JP1234567890 ');
    assert.equal(ok, true);
    assert.equal(copiedValue, 'JP1234567890');
  } finally {
    Object.defineProperty(globalThis, 'navigator', {
      configurable: true,
      value: originalNavigator,
    });
  }
});

test('renders Tahap 6 server-verified automatic J&T Express order cleanly without OrderStatusPage changes', () => {
  const verifiedOrder = makeBaseOrder({
    status: 'PENDING',
    itemsSubtotal: 40000,
    totalAmount: 58000,
    shipping: {
      provider: 'JNT_EXPRESS',
      serviceCode: 'EZ',
      destinationDistrictId: 5507,
      status: 'READY_TO_SHIP',
      totalWeightGrams: 1400,
      hasUnweighedItems: false,
      shippingFee: 18000,
      shippingFeeConfirmed: true,
    },
  });

  const vm = getJntShippingViewModel(verifiedOrder);
  assert.ok(vm);
  assert.equal(vm.isShippingFeeConfirmed, true);
  assert.equal(vm.statusLabel, 'Menunggu pengiriman');
  assert.equal(vm.totalLabel, 'Total Pembayaran');

  const html = renderOrderPage(verifiedOrder);
  assert.match(html, /J&amp;T Express · EZ|J&T Express · EZ/);
  assert.match(html, /Menunggu pengiriman/);
  assert.match(html, /18\.000/);
  assert.match(html, /Total Pembayaran/);
  assert.match(html, /58\.000/);
  assert.match(html, /Nomor resi belum tersedia/);
});
