export const STORE_INFO = {
  name: 'SmartPOS Mart',
  tagline:
    'Belanja kebutuhan harian dan produk toko langsung tanpa registrasi atau login.',
  address: 'Terhubung dengan SmartPOS Owner',
  hours: 'Layanan Tamu Online',
  heroImage: '/src/assets/images/hero_smartpos_store_1794970211085.jpg',
};
