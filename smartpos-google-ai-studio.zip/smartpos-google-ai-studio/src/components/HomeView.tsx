import {
  AlertCircle,
  ArrowRight,
  Clock,
  RefreshCw,
  ShieldCheck,
  Store,
  Truck,
} from 'lucide-react';
import { STORE_INFO } from '../config/storeDisplay';
import type { CartItem, Category, Product } from '../types/pos';
import { ProductCard } from './ProductCard';
import { SmartImage } from './SmartImage';

interface HomeViewProps {
  products: Product[];
  categories: Category[];
  cartItems: CartItem[];
  isLoading: boolean;
  catalogError: string | null;
  onRetryCatalog: () => void;
  onGoToCatalog: (categoryId?: string) => void;
  onGoToStatus: () => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onUpdateCartQty: (productId: string, nextQty: number) => void;
}

export function HomeView({
  products,
  categories,
  cartItems,
  isLoading,
  catalogError,
  onRetryCatalog,
  onGoToCatalog,
  onGoToStatus,
  onSelectProduct,
  onAddToCart,
  onUpdateCartQty,
}: HomeViewProps) {
  const featuredProducts = products.filter((p) => p.featured).slice(0, 4);
  const displayFeatured =
    featuredProducts.length > 0 ? featuredProducts : products.slice(0, 4);

  function getCartQty(productId: string): number {
    return cartItems.find((c) => c.product.id === productId)?.quantity ?? 0;
  }

  return (
    <div className="space-y-12 md:space-y-16 pb-12">
      <section className="bg-gradient-to-b from-blue-50/80 via-white to-slate-50 border-b border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-14 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
          <div className="lg:col-span-6 flex flex-col justify-center space-y-5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-blue-700">
              <span>{STORE_INFO.name}</span>
              <span aria-hidden="true">·</span>
              <span>Mode Belanja Tamu</span>
              <span aria-hidden="true">·</span>
              <span>{STORE_INFO.hours}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-[1.12] text-balance">
              Belanja kebutuhan toko langsung tanpa daftar akun
            </h1>

            <p className="text-base md:text-lg text-slate-600 leading-relaxed max-w-xl">
              {STORE_INFO.tagline} Stok dan harga diambil langsung dari SmartPOS Owner.
            </p>

            <div className="pt-1 flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onGoToCatalog()}
                className="min-h-[48px] px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white text-sm font-semibold inline-flex items-center gap-2 shadow-sm shadow-blue-600/20 transition-all"
              >
                <span>Lihat Semua Produk</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onGoToStatus}
                className="min-h-[48px] px-5 py-3 rounded-xl bg-white hover:bg-blue-50 text-slate-800 border border-slate-200 text-sm font-semibold transition-colors"
              >
                Cek Status Pesanan
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="h-full min-h-[240px] sm:min-h-[320px] rounded-3xl overflow-hidden border border-slate-200 bg-white shadow-sm">
              <SmartImage
                src={STORE_INFO.heroImage}
                alt="Konter toko SmartPOS Mart bernuansa biru dan putih"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-5 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Tanpa Registrasi</h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
                Cukup isi nama dan nomor WhatsApp saat mengirim pesanan.
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Ambil atau Antar</h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
                Pilih ambil langsung di meja kasir atau diantar ke alamat Anda.
              </p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Nomor Pesanan Otomatis</h2>
              <p className="mt-1 text-xs sm:text-sm text-slate-600 leading-relaxed">
                Lacak status konfirmasi kasir secara langsung dari halaman pesanan.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight">
              Produk Toko Tersedia
            </h2>
            <p className="mt-1 text-sm text-slate-600">
              Stok dan harga diperiksa langsung dari database SmartPOS Owner.
            </p>
          </div>

          <button
            type="button"
            onClick={() => onGoToCatalog()}
            className="self-start sm:self-auto text-sm font-semibold text-blue-700 hover:text-blue-800 inline-flex items-center gap-1.5 whitespace-nowrap"
          >
            <span>Buka Katalog Lengkap</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {categories.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => onGoToCatalog(cat.id)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-white border border-slate-200 hover:border-blue-300 hover:text-blue-700 text-xs sm:text-sm font-medium text-slate-700 whitespace-nowrap shrink-0 transition-colors"
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}

        {isLoading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {Array.from({ length: 4 }).map((_, idx) => (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden animate-pulse"
              >
                <div className="aspect-[4/3] bg-slate-200" />
                <div className="p-4 space-y-3">
                  <div className="h-3 w-24 bg-slate-200 rounded" />
                  <div className="h-4 w-full bg-slate-200 rounded" />
                  <div className="h-9 w-full bg-slate-100 rounded-xl" />
                </div>
              </div>
            ))}
          </div>
        ) : catalogError ? (
          <div className="bg-white border border-amber-200 rounded-3xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Katalog Owner Belum Siap
                </h3>
                <p className="mt-1 text-sm text-slate-600">{catalogError}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={onRetryCatalog}
              className="self-start sm:self-auto min-h-[44px] px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Muat Ulang</span>
            </button>
          </div>
        ) : displayFeatured.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center">
            <p className="text-base font-semibold text-slate-900">
              Belum ada produk aktif pada toko ini
            </p>
            <p className="mt-1 text-sm text-slate-500">
              Produk yang ditambahkan melalui SmartPOS Owner akan tampil otomatis di sini.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {displayFeatured.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                cartQuantity={getCartQty(product.id)}
                onSelect={onSelectProduct}
                onAdd={onAddToCart}
                onUpdateQty={onUpdateCartQty}
              />
            ))}
          </div>
        )}
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-blue-700 text-white rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 text-xs font-medium text-blue-100">
              <Truck className="w-4 h-4" />
              <span>{STORE_INFO.address}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-balance">
              Siap memesan untuk diambil di kasir atau dikirim?
            </h2>
            <p className="text-sm text-blue-100">
              Semua produk pada katalog siap dipesan dalam hitungan detik tanpa login.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onGoToCatalog()}
            className="self-start md:self-auto min-h-[48px] px-6 py-3 rounded-xl bg-white hover:bg-blue-50 text-blue-700 text-sm font-bold whitespace-nowrap shrink-0 transition-colors"
          >
            Mulai Belanja Sekarang
          </button>
        </div>
      </section>
    </div>
  );
}
