import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Check,
  Info,
  Loader2,
  MapPin,
  Minus,
  Package,
  Plus,
  Search,
  ShoppingBag,
  Store,
  Trash2,
  Truck,
  X,
} from 'lucide-react';
import { FormEvent, useEffect, useRef, useState } from 'react';
import { STORE_INFO } from '../config/storeDisplay';
import { apiUrl } from '../lib/api';
import type {
  CartItem,
  FulfillmentType,
  GuestOrder,
  JntRateOption,
  RegionOption,
  ShippingLocationOption,
  ShippingRateChangedConflict,
} from '../types/pos';
import {
  buildCheckoutIdempotencySignature,
  buildCreateGuestOrderPayload,
  calculateCartWeightSummary,
  formatStructuredDeliveryAddress,
  formatWeightDisplay,
} from '../utils/checkout';
import { formatRupiah, isValidWhatsAppNumber } from '../utils/format';
import {
  applyCascadingRegionSelection,
  fetchRegionCities,
  fetchRegionDistricts,
  fetchRegionProvinces,
  fetchRegionVillages,
} from '../utils/regionClient';
import {
  formatEtdLabel,
  quoteJntShippingRates,
  sanitizeJntRates,
  searchShippingLocations,
  selectDefaultJntRate,
} from '../utils/shippingClient';
import { SearchableRegionSelect } from './SearchableRegionSelect';
import { SmartImage } from './SmartImage';

interface CartCheckoutDrawerProps {
  isOpen: boolean;
  items: CartItem[];
  onClose: () => void;
  onUpdateQty: (productId: string, nextQty: number) => void;
  onRemoveItem: (productId: string) => void;
  onOrderCreated: (order: GuestOrder) => void;
}

const LOCATION_SEARCH_DEBOUNCE_MS = 400;

export function CartCheckoutDrawer({
  isOpen,
  items,
  onClose,
  onUpdateQty,
  onRemoveItem,
  onOrderCreated,
}: CartCheckoutDrawerProps) {
  const [step, setStep] = useState<'cart' | 'checkout'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [fulfillmentType, setFulfillmentType] = useState<FulfillmentType>('pickup');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const submitLockRef = useRef(false);

  // Administrative region dropdowns (LokaID — isolated from KiriminAja shipping)
  const [provinces, setProvinces] = useState<RegionOption[]>([]);
  const [selectedProvince, setSelectedProvince] = useState<RegionOption | null>(null);
  const [isLoadingProvinces, setIsLoadingProvinces] = useState(false);
  const [hasLoadedProvinces, setHasLoadedProvinces] = useState(false);
  const [provincesError, setProvincesError] = useState<string | null>(null);
  const [provincesRetryCount, setProvincesRetryCount] = useState(0);

  const [cities, setCities] = useState<RegionOption[]>([]);
  const [selectedCity, setSelectedCity] = useState<RegionOption | null>(null);
  const [isLoadingCities, setIsLoadingCities] = useState(false);
  const [hasLoadedCities, setHasLoadedCities] = useState(false);
  const [citiesError, setCitiesError] = useState<string | null>(null);
  const [citiesRetryCount, setCitiesRetryCount] = useState(0);

  const [districts, setDistricts] = useState<RegionOption[]>([]);
  const [selectedDistrict, setSelectedDistrict] = useState<RegionOption | null>(null);
  const [isLoadingDistricts, setIsLoadingDistricts] = useState(false);
  const [hasLoadedDistricts, setHasLoadedDistricts] = useState(false);
  const [districtsError, setDistrictsError] = useState<string | null>(null);
  const [districtsRetryCount, setDistrictsRetryCount] = useState(0);

  const [villages, setVillages] = useState<RegionOption[]>([]);
  const [selectedVillage, setSelectedVillage] = useState<RegionOption | null>(null);
  const [isLoadingVillages, setIsLoadingVillages] = useState(false);
  const [hasLoadedVillages, setHasLoadedVillages] = useState(false);
  const [villagesError, setVillagesError] = useState<string | null>(null);
  const [villagesRetryCount, setVillagesRetryCount] = useState(0);

  const [streetAddress, setStreetAddress] = useState('');
  const [useManualAddressFallback, setUseManualAddressFallback] = useState(false);

  // Automatic J&T location search & tariff state (delivery only)
  const [locationQuery, setLocationQuery] = useState('');
  const [locationResults, setLocationResults] = useState<ShippingLocationOption[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<ShippingLocationOption | null>(
    null
  );
  const [isSearchingLocations, setIsSearchingLocations] = useState(false);
  const [hasSearchedLocations, setHasSearchedLocations] = useState(false);
  const [locationSearchError, setLocationSearchError] = useState<string | null>(null);
  const [locationUnavailableReason, setLocationUnavailableReason] = useState<string | null>(
    null
  );

  const [jntRates, setJntRates] = useState<JntRateOption[]>([]);
  const [selectedServiceCode, setSelectedServiceCode] = useState<string | null>(null);
  const [isQuotingRates, setIsQuotingRates] = useState(false);
  const [rateQuoteError, setRateQuoteError] = useState<string | null>(null);
  const [rateQuoteStatusCode, setRateQuoteStatusCode] = useState<number | undefined>(
    undefined
  );
  const [rateFallbackReason, setRateFallbackReason] = useState<string | null>(null);
  const [rateHasUnweighedItems, setRateHasUnweighedItems] = useState(false);
  const [rateChangeConfirmation, setRateChangeConfirmation] = useState<{
    previousFee: number;
    nextFee: number | null;
    serviceCode?: string;
    message: string;
  } | null>(null);
  const [locationRetryCount, setLocationRetryCount] = useState(0);
  const [rateRetryCount, setRateRetryCount] = useState(0);

  const [idempotencyKey, setIdempotencyKey] = useState<string>(() =>
    typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
      ? crypto.randomUUID()
      : `idem_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
  );

  const activeSelectedRate =
    !isQuotingRates &&
    fulfillmentType === 'delivery' &&
    selectedLocation &&
    selectedServiceCode
      ? (jntRates.find((rate) => rate.serviceCode === selectedServiceCode) ?? null)
      : null;

  const checkoutSignature = buildCheckoutIdempotencySignature(
    items,
    fulfillmentType,
    'JNT_EXPRESS',
    {
      destinationDistrictId: selectedLocation?.districtId,
      selectedServiceCode: activeSelectedRate?.serviceCode,
    }
  );

  useEffect(() => {
    setIdempotencyKey(
      typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
        ? crypto.randomUUID()
        : `idem_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
    );
  }, [checkoutSignature]);

  useEffect(() => {
    if (!isOpen) {
      setStep('cart');
      setErrorMessage(null);
      setIsSearchingLocations(false);
      setIsQuotingRates(false);
      setRateChangeConfirmation(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isOpen, onClose]);

  // Fetch provinces when delivery checkout opens
  useEffect(() => {
    if (
      !isOpen ||
      step !== 'checkout' ||
      fulfillmentType !== 'delivery' ||
      useManualAddressFallback
    ) {
      setIsLoadingProvinces(false);
      return;
    }

    if (hasLoadedProvinces && !provincesError && provinces.length > 0 && provincesRetryCount === 0) {
      return;
    }

    const controller = new AbortController();
    setIsLoadingProvinces(true);
    setProvincesError(null);

    fetchRegionProvinces({ signal: controller.signal }).then((result) => {
      if (result.aborted || controller.signal.aborted) return;
      setIsLoadingProvinces(false);
      setHasLoadedProvinces(true);
      if (!result.ok) {
        setProvinces([]);
        setProvincesError(result.errorMessage || 'Gagal memuat daftar provinsi.');
        return;
      }
      setProvinces(result.regions);
    });

    return () => {
      controller.abort();
    };
  }, [
    isOpen,
    step,
    fulfillmentType,
    useManualAddressFallback,
    provincesRetryCount,
  ]);

  // Fetch cities/regencies when province changes
  useEffect(() => {
    if (
      !isOpen ||
      step !== 'checkout' ||
      fulfillmentType !== 'delivery' ||
      useManualAddressFallback ||
      !selectedProvince
    ) {
      setIsLoadingCities(false);
      return;
    }

    const controller = new AbortController();
    setIsLoadingCities(true);
    setCitiesError(null);

    fetchRegionCities(selectedProvince.code, { signal: controller.signal }).then(
      (result) => {
        if (result.aborted || controller.signal.aborted) return;
        setIsLoadingCities(false);
        setHasLoadedCities(true);
        if (!result.ok) {
          setCities([]);
          setCitiesError(
            result.errorMessage || 'Gagal memuat daftar kabupaten/kota.'
          );
          return;
        }
        setCities(result.regions);
      }
    );

    return () => {
      controller.abort();
    };
  }, [
    isOpen,
    step,
    fulfillmentType,
    useManualAddressFallback,
    selectedProvince?.code,
    citiesRetryCount,
  ]);

  // Fetch districts when city/regency changes
  useEffect(() => {
    if (
      !isOpen ||
      step !== 'checkout' ||
      fulfillmentType !== 'delivery' ||
      useManualAddressFallback ||
      !selectedCity
    ) {
      setIsLoadingDistricts(false);
      return;
    }

    const controller = new AbortController();
    setIsLoadingDistricts(true);
    setDistrictsError(null);

    fetchRegionDistricts(selectedCity.code, { signal: controller.signal }).then(
      (result) => {
        if (result.aborted || controller.signal.aborted) return;
        setIsLoadingDistricts(false);
        setHasLoadedDistricts(true);
        if (!result.ok) {
          setDistricts([]);
          setDistrictsError(result.errorMessage || 'Gagal memuat daftar kecamatan.');
          return;
        }
        setDistricts(result.regions);
      }
    );

    return () => {
      controller.abort();
    };
  }, [
    isOpen,
    step,
    fulfillmentType,
    useManualAddressFallback,
    selectedCity?.code,
    districtsRetryCount,
  ]);

  // Fetch villages when district changes
  useEffect(() => {
    if (
      !isOpen ||
      step !== 'checkout' ||
      fulfillmentType !== 'delivery' ||
      useManualAddressFallback ||
      !selectedDistrict
    ) {
      setIsLoadingVillages(false);
      return;
    }

    const controller = new AbortController();
    setIsLoadingVillages(true);
    setVillagesError(null);

    fetchRegionVillages(selectedDistrict.code, { signal: controller.signal }).then(
      (result) => {
        if (result.aborted || controller.signal.aborted) return;
        setIsLoadingVillages(false);
        setHasLoadedVillages(true);
        if (!result.ok) {
          setVillages([]);
          setVillagesError(
            result.errorMessage || 'Gagal memuat daftar kelurahan/desa.'
          );
          return;
        }
        setVillages(result.regions);
      }
    );

    return () => {
      controller.abort();
    };
  }, [
    isOpen,
    step,
    fulfillmentType,
    useManualAddressFallback,
    selectedDistrict?.code,
    villagesRetryCount,
  ]);

  // Debounced KiriminAja location search with AbortController
  useEffect(() => {
    if (
      !isOpen ||
      step !== 'checkout' ||
      fulfillmentType !== 'delivery' ||
      selectedLocation !== null
    ) {
      setIsSearchingLocations(false);
      return;
    }

    const cleanQuery = locationQuery.trim().replace(/\s+/g, ' ');
    if (cleanQuery.length < 3) {
      setLocationResults([]);
      setIsSearchingLocations(false);
      setHasSearchedLocations(false);
      setLocationSearchError(null);
      setLocationUnavailableReason(null);
      return;
    }

    const controller = new AbortController();
    setIsSearchingLocations(true);
    setLocationSearchError(null);
    setLocationUnavailableReason(null);

    const timerId = window.setTimeout(async () => {
      const result = await searchShippingLocations({
        search: cleanQuery,
        limit: 10,
        signal: controller.signal,
      });

      if (result.aborted || controller.signal.aborted) {
        return;
      }

      setIsSearchingLocations(false);
      setHasSearchedLocations(true);

      if (!result.ok) {
        setLocationResults([]);
        setLocationSearchError(
          result.errorMessage ||
            'Gagal mencari kecamatan tujuan. Pesanan tetap dapat dikirim untuk dikonfirmasi Owner.'
        );
        return;
      }

      if (!result.available) {
        setLocationResults([]);
        setLocationUnavailableReason(
          result.reason ||
            'Pencarian kecamatan otomatis belum tersedia. Anda tetap dapat mengirim pesanan untuk dikonfirmasi Owner.'
        );
        return;
      }

      setLocationResults(result.locations);
      if (result.locations.length === 0) {
        setLocationUnavailableReason(
          result.reason ||
            'Kecamatan tidak ditemukan. Coba kata kunci lain atau lanjutkan dengan konfirmasi ongkir oleh Owner.'
        );
      }
    }, LOCATION_SEARCH_DEBOUNCE_MS);

    return () => {
      window.clearTimeout(timerId);
      controller.abort();
    };
  }, [
    isOpen,
    step,
    fulfillmentType,
    selectedLocation,
    locationQuery,
    locationRetryCount,
  ]);

  const cartQuoteKey = items
    .map((item) => `${item.product.id}:${item.quantity}`)
    .sort()
    .join('|');

  // Automatic J&T rate quote whenever destination location is chosen or cart items change
  useEffect(() => {
    if (
      !isOpen ||
      step !== 'checkout' ||
      fulfillmentType !== 'delivery' ||
      selectedLocation === null ||
      items.length === 0
    ) {
      setIsQuotingRates(false);
      if (items.length === 0) {
        setJntRates([]);
        setSelectedServiceCode(null);
      }
      return;
    }

    const controller = new AbortController();
    setIsQuotingRates(true);
    setJntRates([]);
    setRateQuoteError(null);
    setRateQuoteStatusCode(undefined);
    setRateFallbackReason(null);
    setRateChangeConfirmation(null);

    quoteJntShippingRates({
      destinationDistrictId: selectedLocation.districtId,
      items,
      signal: controller.signal,
    }).then((result) => {
      if (result.aborted || controller.signal.aborted) {
        return;
      }

      setIsQuotingRates(false);

      if (!result.ok) {
        setJntRates([]);
        setSelectedServiceCode(null);
        setRateHasUnweighedItems(false);
        setRateQuoteStatusCode(result.statusCode);
        setRateQuoteError(
          result.errorMessage ||
            'Gagal menghitung tarif J&T. Ongkos kirim akan dikonfirmasi Owner.'
        );
        return;
      }

      setRateHasUnweighedItems(result.hasUnweighedItems);

      if (result.available && !result.fallbackToManual && result.rates.length > 0) {
        setJntRates(result.rates);
        setRateFallbackReason(null);
        setSelectedServiceCode(
          (prevCode) => selectDefaultJntRate(result.rates, prevCode)?.serviceCode ?? null
        );
      } else {
        setJntRates([]);
        setSelectedServiceCode(null);
        setRateFallbackReason(
          result.reason ||
            'Tarif J&T otomatis belum tersedia untuk tujuan ini. Ongkos kirim akan dikonfirmasi Owner.'
        );
      }
    });

    return () => {
      controller.abort();
    };
  }, [
    isOpen,
    step,
    fulfillmentType,
    selectedLocation?.districtId,
    cartQuoteKey,
    rateRetryCount,
  ]);

  if (!isOpen) return null;

  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const totalQty = items.reduce((sum, item) => sum + item.quantity, 0);
  const weightSummary = calculateCartWeightSummary(items);
  const isJntDelivery = fulfillmentType === 'delivery';
  const hasAnyUnweighedItems = weightSummary.hasUnweighedItems || rateHasUnweighedItems;
  const estimatedTotal = activeSelectedRate
    ? Math.round((subtotal + activeSelectedRate.cost) * 100) / 100
    : subtotal;

  const hasRegionFailureOrEmpty = Boolean(
    provincesError ||
      citiesError ||
      districtsError ||
      villagesError ||
      (hasLoadedProvinces && provinces.length === 0) ||
      (hasLoadedCities && cities.length === 0) ||
      (hasLoadedDistricts && districts.length === 0) ||
      (hasLoadedVillages && villages.length === 0)
  );

  const formattedStructuredAddress = formatStructuredDeliveryAddress({
    province: selectedProvince,
    city: selectedCity,
    district: selectedDistrict,
    village: selectedVillage,
    streetAddress,
    manualFallbackAddress: deliveryAddress,
  });

  function applySelectionTransition(
    level: 'provinces' | 'cities' | 'districts' | 'villages',
    option: RegionOption
  ) {
    const next = applyCascadingRegionSelection(
      {
        province: selectedProvince,
        city: selectedCity,
        district: selectedDistrict,
        village: selectedVillage,
      },
      level,
      option
    );
    setSelectedProvince(next.province);
    setSelectedCity(next.city);
    setSelectedDistrict(next.district);
    setSelectedVillage(next.village);
  }

  function handleSelectProvince(province: RegionOption) {
    applySelectionTransition('provinces', province);
    setCities([]);
    setHasLoadedCities(false);
    setCitiesError(null);
    setDistricts([]);
    setHasLoadedDistricts(false);
    setDistrictsError(null);
    setVillages([]);
    setHasLoadedVillages(false);
    setVillagesError(null);
  }

  function handleSelectCity(city: RegionOption) {
    applySelectionTransition('cities', city);
    setDistricts([]);
    setHasLoadedDistricts(false);
    setDistrictsError(null);
    setVillages([]);
    setHasLoadedVillages(false);
    setVillagesError(null);
  }

  function handleSelectDistrict(district: RegionOption) {
    applySelectionTransition('districts', district);
    setVillages([]);
    setHasLoadedVillages(false);
    setVillagesError(null);
  }

  function handleSelectVillage(village: RegionOption) {
    applySelectionTransition('villages', village);
  }

  function clearRateQuoteState() {
    setJntRates([]);
    setSelectedServiceCode(null);
    setIsQuotingRates(false);
    setRateQuoteError(null);
    setRateQuoteStatusCode(undefined);
    setRateFallbackReason(null);
    setRateHasUnweighedItems(false);
    setRateChangeConfirmation(null);
  }

  function handleLocationInputChange(nextValue: string) {
    setLocationQuery(nextValue);
    setSelectedLocation(null);
    setLocationSearchError(null);
    setLocationUnavailableReason(null);
    setHasSearchedLocations(false);
    clearRateQuoteState();
  }

  function handleSelectLocation(loc: ShippingLocationOption) {
    setSelectedLocation(loc);
    setLocationQuery(loc.label);
    setLocationResults([]);
    setLocationSearchError(null);
    setLocationUnavailableReason(null);
    setHasSearchedLocations(false);
    clearRateQuoteState();
  }

  function handleClearSelectedLocation() {
    setSelectedLocation(null);
    setLocationQuery('');
    setLocationResults([]);
    setLocationSearchError(null);
    setLocationUnavailableReason(null);
    setHasSearchedLocations(false);
    clearRateQuoteState();
  }

  async function handleSubmitOrder(e: FormEvent) {
    e.preventDefault();
    if (submitLockRef.current || isSubmitting) return;
    setErrorMessage(null);

    const trimmedName = customerName.trim();
    const trimmedPhone = customerPhone.trim();

    if (trimmedName.length < 2) {
      setErrorMessage('Mohon masukkan nama lengkap Anda (minimal 2 karakter).');
      return;
    }

    if (!isValidWhatsAppNumber(trimmedPhone)) {
      setErrorMessage(
        'Nomor WhatsApp tidak valid. Contoh yang benar: 081234567890.'
      );
      return;
    }

    let resolvedAddress = '';
    if (fulfillmentType === 'delivery') {
      if (useManualAddressFallback) {
        resolvedAddress = deliveryAddress.trim().slice(0, 360);
        if (resolvedAddress.length < 8) {
          setErrorMessage(
            'Mohon isi alamat pengiriman lengkap (nama jalan, kelurahan/kecamatan, kota/kabupaten).'
          );
          return;
        }
      } else {
        if (
          !selectedProvince ||
          !selectedCity ||
          !selectedDistrict ||
          !selectedVillage
        ) {
          setErrorMessage(
            'Mohon pilih Provinsi, Kabupaten/Kota, Kecamatan, hingga Kelurahan/Desa tujuan pengiriman.'
          );
          return;
        }
        if (streetAddress.trim().length < 3) {
          setErrorMessage('Mohon isi nama jalan pengiriman (minimal 3 karakter).');
          return;
        }
        resolvedAddress = formattedStructuredAddress;
        if (resolvedAddress.length < 8) {
          setErrorMessage('Mohon lengkapi detail alamat pengiriman Anda.');
          return;
        }
      }
    }

    if (items.length === 0) {
      setErrorMessage('Keranjang belanja Anda masih kosong.');
      return;
    }

    const payload = buildCreateGuestOrderPayload({
      customerName: trimmedName,
      customerPhone: trimmedPhone,
      fulfillmentType,
      deliveryAddress: resolvedAddress,
      destinationDistrictId:
        fulfillmentType === 'delivery' ? selectedLocation?.districtId : undefined,
      selectedServiceCode:
        fulfillmentType === 'delivery' ? activeSelectedRate?.serviceCode : undefined,
      expectedShippingFee:
        fulfillmentType === 'delivery' && activeSelectedRate
          ? activeSelectedRate.cost
          : undefined,
      notes,
      idempotencyKey,
      items,
    });

    try {
      submitLockRef.current = true;
      setIsSubmitting(true);
      const response = await fetch(apiUrl('/api/guest-orders'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json().catch(() => ({}));
      if (response.status === 409 && data?.code === 'SHIPPING_RATE_CHANGED') {
        const conflict = data as Partial<ShippingRateChangedConflict>;
        const prevFee =
          typeof conflict.expectedShippingFee === 'number'
            ? conflict.expectedShippingFee
            : (activeSelectedRate?.cost ?? 0);

        setIdempotencyKey(
          typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
            ? crypto.randomUUID()
            : `idem_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`
        );

        if (conflict.fallbackToManual) {
          setJntRates([]);
          setSelectedServiceCode(null);
          setRateHasUnweighedItems(Boolean(conflict.hasUnweighedItems));
          setRateFallbackReason(
            conflict.error ||
              'Tarif J&T otomatis tidak dapat diverifikasi saat ini. Ongkos kirim akan dikonfirmasi Owner.'
          );
          setRateChangeConfirmation({
            previousFee: prevFee,
            nextFee: null,
            message:
              conflict.error ||
              'Tarif J&T otomatis tidak lagi tersedia. Silakan konfirmasi untuk melanjutkan dengan ongkos kirim manual oleh Owner.',
          });
        } else {
          const refreshedRates = sanitizeJntRates(conflict.rates);
          const nextSelected = selectDefaultJntRate(
            refreshedRates,
            conflict.selectedServiceCode ?? selectedServiceCode
          );
          setJntRates(refreshedRates);
          setSelectedServiceCode(nextSelected?.serviceCode ?? null);
          setRateFallbackReason(null);
          setRateChangeConfirmation({
            previousFee: prevFee,
            nextFee:
              typeof conflict.verifiedShippingFee === 'number'
                ? conflict.verifiedShippingFee
                : (nextSelected?.cost ?? 0),
            serviceCode: nextSelected?.serviceCode ?? conflict.selectedServiceCode,
            message:
              conflict.error ||
              'Tarif J&T telah diperbarui oleh server. Silakan periksa dan konfirmasi nominal terbaru.',
          });
        }
        return;
      }

      if (!response.ok) {
        setErrorMessage(
          data?.error || 'Gagal mengirim pesanan. Silakan periksa kembali stok produk.'
        );
        return;
      }

      setRateChangeConfirmation(null);
      onOrderCreated(data.order as GuestOrder);
    } catch {
      setErrorMessage(
        'Koneksi ke server terganggu. Periksa jaringan Anda lalu coba lagi.'
      );
    } finally {
      submitLockRef.current = false;
      setIsSubmitting(false);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/50 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Keranjang dan Formulir Pesanan"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white h-full flex flex-col shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2.5">
            {step === 'checkout' && (
              <button
                type="button"
                onClick={() => {
                  setErrorMessage(null);
                  setStep('cart');
                }}
                aria-label="Kembali ke keranjang"
                className="w-9 h-9 flex items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {step === 'cart' ? 'Keranjang Belanja' : 'Data Pemesan Tamu'}
              </h2>
              <p className="text-xs text-slate-500">
                {step === 'cart'
                  ? `${totalQty} barang dipilih`
                  : 'Tanpa daftar · Konfirmasi lewat WhatsApp'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup panel keranjang"
            className="w-10 h-10 flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
            <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <ShoppingBag className="w-7 h-7" strokeWidth={1.7} />
            </div>
            <h3 className="text-base font-semibold text-slate-900">
              Keranjang masih kosong
            </h3>
            <p className="mt-1.5 text-sm text-slate-500 max-w-xs">
              Pilih minuman, roti, atau kebutuhan harian dari katalog untuk mulai memesan.
            </p>
            <button
              type="button"
              onClick={onClose}
              className="mt-6 min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors"
            >
              Jelajahi Katalog
            </button>
          </div>
        ) : step === 'cart' ? (
          <>
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100 px-5">
              {items.map(({ product, quantity }) => (
                <div key={product.id} className="py-4 flex gap-3.5">
                  <div className="w-20 h-16 rounded-xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200/70">
                    <SmartImage
                      src={product.imageUrl}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-slate-900 leading-snug line-clamp-2">
                        {product.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(product.id)}
                        aria-label={`Hapus ${product.name}`}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg transition-colors shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
                      {formatRupiah(product.price)} / {product.unit}
                    </p>

                    <div className="mt-2.5 flex items-center justify-between gap-2">
                      <div className="inline-flex items-center gap-1 bg-slate-100 rounded-lg p-0.5">
                        <button
                          type="button"
                          onClick={() => onUpdateQty(product.id, quantity - 1)}
                          aria-label={`Kurangi ${product.name}`}
                          className="w-8 h-8 flex items-center justify-center rounded-md bg-white text-slate-700 hover:text-blue-700 shadow-2xs"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="w-7 text-center font-mono tabular-nums text-xs font-bold text-slate-900">
                          {quantity}
                        </span>
                        <button
                          type="button"
                          disabled={quantity >= product.stock}
                          onClick={() => onUpdateQty(product.id, quantity + 1)}
                          aria-label={`Tambah ${product.name}`}
                          className="w-8 h-8 flex items-center justify-center rounded-md bg-white text-slate-700 hover:text-blue-700 disabled:opacity-40 shadow-2xs"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <span className="font-mono tabular-nums text-sm font-bold text-blue-700">
                        {formatRupiah(product.price * quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-5 border-t border-slate-200 bg-slate-50/70 space-y-4 shrink-0">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Total Sementara</span>
                <span className="font-mono tabular-nums text-lg font-bold text-slate-900">
                  {formatRupiah(subtotal)}
                </span>
              </div>

              <button
                type="button"
                onClick={() => setStep('checkout')}
                className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-sm shadow-blue-600/20 transition-all"
              >
                <span>Lanjut ke Pengiriman & Data</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </>
        ) : (
          <form onSubmit={handleSubmitOrder} className="flex-1 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {errorMessage && (
                <div
                  role="alert"
                  className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm"
                >
                  {errorMessage}
                </div>
              )}

              <div>
                <label
                  htmlFor="guest-name"
                  className="block text-sm font-semibold text-slate-800 mb-1.5"
                >
                  Nama Lengkap <span className="text-rose-600">*</span>
                </label>
                <input
                  id="guest-name"
                  type="text"
                  required
                  maxLength={80}
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Contoh: Budi Santoso"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                />
              </div>

              <div>
                <label
                  htmlFor="guest-whatsapp"
                  className="block text-sm font-semibold text-slate-800 mb-1.5"
                >
                  Nomor WhatsApp <span className="text-rose-600">*</span>
                </label>
                <input
                  id="guest-whatsapp"
                  type="tel"
                  required
                  maxLength={18}
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="Contoh: 081234567890"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                />
                <p className="mt-1 text-xs text-slate-500">
                  Digunakan kasir untuk mengonfirmasi ketersediaan pesanan Anda.
                </p>
              </div>

              <div>
                <span className="block text-sm font-semibold text-slate-800 mb-2">
                  Metode Penerimaan
                </span>
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => {
                      setFulfillmentType('pickup');
                      setRateChangeConfirmation(null);
                      setErrorMessage(null);
                    }}
                    className={`min-h-[56px] p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 ${
                      fulfillmentType === 'pickup'
                        ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-1 ring-blue-600'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Store
                      className={`w-4 h-4 mt-0.5 shrink-0 ${
                        fulfillmentType === 'pickup' ? 'text-blue-600' : 'text-slate-400'
                      }`}
                    />
                    <div>
                      <p className="text-xs font-bold">Ambil di Toko</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Ambil di kasir
                      </p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setFulfillmentType('delivery');
                      setRateChangeConfirmation(null);
                      setErrorMessage(null);
                    }}
                    className={`min-h-[56px] p-3 rounded-xl border text-left transition-all flex items-start gap-2.5 ${
                      fulfillmentType === 'delivery'
                        ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-1 ring-blue-600'
                        : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <Truck
                      className={`w-4 h-4 mt-0.5 shrink-0 ${
                        fulfillmentType === 'delivery' ? 'text-blue-600' : 'text-slate-400'
                      }`}
                    />
                    <div>
                      <p className="text-xs font-bold">Kirim ke Alamat</p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        J&T Express
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {fulfillmentType === 'pickup' ? (
                <div className="p-3.5 rounded-xl bg-blue-50/60 border border-blue-100 flex items-start gap-2.5 text-xs text-slate-700">
                  <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-semibold text-slate-900">{STORE_INFO.name}</p>
                    <p className="mt-0.5 text-slate-600">{STORE_INFO.address}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* District / Location Search for Automatic J&T Rate */}
                  <div className="space-y-2">
                    <label
                      htmlFor="guest-location-search"
                      className="block text-sm font-semibold text-slate-800"
                    >
                      Kecamatan / Kota Tujuan{' '}
                      <span className="font-normal text-xs text-slate-500">
                        (untuk cek ongkir J&T otomatis)
                      </span>
                    </label>

                    {selectedLocation ? (
                      <div className="p-3 rounded-xl border border-blue-200 bg-blue-50/50 flex items-center justify-between gap-3">
                        <div className="min-w-0 flex items-start gap-2.5">
                          <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                          <div className="min-w-0">
                            <p className="text-xs font-semibold text-slate-900 leading-snug">
                              {selectedLocation.label}
                            </p>
                            {selectedLocation.postalCode && (
                              <p className="text-[11px] text-slate-500 mt-0.5 font-mono tabular-nums">
                                Kode Pos {selectedLocation.postalCode}
                              </p>
                            )}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={handleClearSelectedLocation}
                          className="min-h-[36px] px-3 py-1.5 rounded-lg border border-blue-200 bg-white hover:bg-blue-50 text-xs font-semibold text-blue-700 whitespace-nowrap shrink-0 transition-colors"
                        >
                          Ubah
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="relative">
                          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                          <input
                            id="guest-location-search"
                            type="text"
                            maxLength={60}
                            value={locationQuery}
                            onChange={(e) => handleLocationInputChange(e.target.value)}
                            placeholder="Ketik nama kecamatan atau kota (min. 3 huruf)..."
                            aria-describedby="guest-location-hint"
                            className="w-full min-h-[44px] pl-10 pr-9 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                          />
                          {isSearchingLocations && (
                            <Loader2
                              aria-label="Mencari lokasi"
                              className="w-4 h-4 text-blue-600 animate-spin absolute right-3.5 top-1/2 -translate-y-1/2"
                            />
                          )}
                        </div>

                        <p id="guest-location-hint" className="text-xs text-slate-500">
                          {locationQuery.trim().length > 0 &&
                          locationQuery.trim().length < 3
                            ? 'Ketik minimal 3 huruf untuk menampilkan daftar kecamatan.'
                            : 'Opsional: pilih kecamatan untuk melihat tarif J&T otomatis, atau kosongkan untuk konfirmasi manual Owner.'}
                        </p>

                        {locationSearchError && (
                          <div
                            role="status"
                            className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start justify-between gap-2"
                          >
                            <div className="flex items-start gap-2 min-w-0">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                              <span>{locationSearchError}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => setLocationRetryCount((c) => c + 1)}
                              className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 hover:bg-amber-100 text-[11px] font-semibold text-amber-900 shrink-0 transition-colors"
                            >
                              Coba lagi
                            </button>
                          </div>
                        )}

                        {!locationSearchError &&
                          locationUnavailableReason &&
                          (hasSearchedLocations || locationResults.length === 0) && (
                            <div
                              role="status"
                              className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-xs flex items-start gap-2"
                            >
                              <Info className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                              <span>{locationUnavailableReason}</span>
                            </div>
                          )}

                        {locationResults.length > 0 && (
                          <div
                            role="listbox"
                            aria-label="Hasil pencarian kecamatan tujuan"
                            className="max-h-48 overflow-y-auto rounded-xl border border-slate-200 bg-white divide-y divide-slate-100"
                          >
                            {locationResults.map((loc) => (
                              <button
                                key={loc.districtId}
                                type="button"
                                role="option"
                                aria-selected={false}
                                onClick={() => handleSelectLocation(loc)}
                                className="w-full min-h-[44px] px-3.5 py-2.5 text-left hover:bg-blue-50/70 transition-colors flex items-center justify-between gap-2"
                              >
                                <span className="text-xs font-medium text-slate-900 leading-snug">
                                  {loc.label}
                                </span>
                                {loc.postalCode && (
                                  <span className="text-[11px] font-mono tabular-nums text-slate-500 shrink-0">
                                    {loc.postalCode}
                                  </span>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* J&T Express Rate Summary & Service Selector */}
                  <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-3 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-bold text-slate-900 inline-flex items-center gap-1.5">
                        <Package className="w-3.5 h-3.5 text-blue-600" />
                        <span>Pengiriman: J&T Express</span>
                      </span>
                      <span
                        className={`font-semibold text-[11px] ${
                          isQuotingRates
                            ? 'text-blue-700'
                            : activeSelectedRate
                            ? 'text-blue-700'
                            : 'text-amber-800'
                        }`}
                      >
                        {isQuotingRates
                          ? 'Menghitung Tarif...'
                          : activeSelectedRate
                          ? 'Estimasi Otomatis'
                          : 'Ongkir Manual'}
                      </span>
                    </div>

                    {selectedLocation && (
                      <div className="space-y-2 pt-2 border-t border-blue-200/70">
                        {isQuotingRates ? (
                          <div className="py-2 flex items-center gap-2 text-slate-700">
                            <Loader2 className="w-4 h-4 text-blue-600 animate-spin shrink-0" />
                            <span>Mengambil estimasi tarif J&T Express...</span>
                          </div>
                        ) : jntRates.length > 0 ? (
                          <div className="space-y-1.5">
                            <p className="font-semibold text-slate-800">
                              Pilih Layanan J&T Express
                            </p>
                            <div
                              role="radiogroup"
                              aria-label="Pilihan layanan J&T Express"
                              className="space-y-1.5"
                            >
                              {jntRates.map((rate) => {
                                const isSelected =
                                  activeSelectedRate?.serviceCode === rate.serviceCode;
                                const etdText = formatEtdLabel(rate.etd);
                                return (
                                  <button
                                    key={rate.serviceCode}
                                    type="button"
                                    role="radio"
                                    aria-checked={isSelected}
                                    onClick={() => {
                                      setSelectedServiceCode(rate.serviceCode);
                                      setRateChangeConfirmation(null);
                                    }}
                                    className={`w-full min-h-[48px] px-3 py-2.5 rounded-xl border text-left transition-all flex items-center justify-between gap-3 ${
                                      isSelected
                                        ? 'border-blue-600 bg-white ring-1 ring-blue-600 text-slate-900'
                                        : 'border-blue-200/80 bg-white/75 hover:bg-white text-slate-700'
                                    }`}
                                  >
                                    <div className="min-w-0 flex items-start gap-2">
                                      <span
                                        className={`mt-0.5 w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                                          isSelected
                                            ? 'border-blue-600 bg-blue-600 text-white'
                                            : 'border-slate-300 bg-white'
                                        }`}
                                      >
                                        {isSelected && <Check className="w-2.5 h-2.5" />}
                                      </span>
                                      <div className="min-w-0">
                                        <p className="text-xs font-semibold text-slate-900 leading-snug">
                                          <span>{rate.serviceName}</span>
                                          <span className="text-slate-400 mx-1" aria-hidden="true">
                                            ·
                                          </span>
                                          <span className="font-mono text-slate-700">
                                            {rate.serviceCode}
                                          </span>
                                        </p>
                                        {etdText && (
                                          <p className="text-[11px] text-slate-500 mt-0.5 tabular-nums">
                                            {etdText}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                    <span className="font-mono tabular-nums text-xs font-bold text-blue-700 whitespace-nowrap shrink-0">
                                      {formatRupiah(rate.cost)}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        ) : rateQuoteError ? (
                          <div
                            role="status"
                            className={`p-2.5 rounded-lg border flex items-start justify-between gap-2 leading-relaxed ${
                              rateQuoteStatusCode === 404 ||
                              rateQuoteStatusCode === 409
                                ? 'bg-rose-50 border-rose-200 text-rose-800'
                                : 'bg-amber-50 border-amber-200 text-amber-900'
                            }`}
                          >
                            <div className="flex items-start gap-2 min-w-0">
                              <AlertTriangle
                                className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                                  rateQuoteStatusCode === 404 ||
                                  rateQuoteStatusCode === 409
                                    ? 'text-rose-600'
                                    : 'text-amber-600'
                                }`}
                              />
                              <span>{rateQuoteError}</span>
                            </div>
                            {rateQuoteStatusCode !== 404 &&
                              rateQuoteStatusCode !== 409 && (
                                <button
                                  type="button"
                                  onClick={() => setRateRetryCount((c) => c + 1)}
                                  className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 hover:bg-amber-100 text-[11px] font-semibold text-amber-900 shrink-0 transition-colors"
                                >
                                  Coba lagi
                                </button>
                              )}
                          </div>
                        ) : rateFallbackReason ? (
                          <div
                            role="status"
                            className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-2 leading-relaxed"
                          >
                            <Info className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                            <span>{rateFallbackReason}</span>
                          </div>
                        ) : null}
                      </div>
                    )}

                    <div className="space-y-1.5 pt-2 border-t border-blue-200/70">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-600">Estimasi Berat Paket</span>
                        <span className="font-mono tabular-nums font-semibold text-slate-900">
                          {weightSummary.allItemsUnweighed
                            ? 'Belum diketahui'
                            : formatWeightDisplay(weightSummary.totalWeightGrams)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-600">Subtotal Barang</span>
                        <span className="font-mono tabular-nums font-semibold text-slate-900">
                          {formatRupiah(subtotal)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-600">
                          {activeSelectedRate
                            ? `Estimasi Ongkir J&T (${activeSelectedRate.serviceCode})`
                            : 'Ongkos Kirim J&T'}
                        </span>
                        {isQuotingRates ? (
                          <span className="font-medium text-blue-700">
                            Menghitung...
                          </span>
                        ) : activeSelectedRate ? (
                          <span className="font-mono tabular-nums font-semibold text-slate-900">
                            {formatRupiah(activeSelectedRate.cost)}
                          </span>
                        ) : (
                          <span className="font-medium text-amber-800">
                            Dikonfirmasi Owner
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-between gap-2 pt-1 border-t border-blue-200/70">
                        <span className="font-semibold text-slate-800">
                          {activeSelectedRate ? 'Estimasi Total' : 'Total Sementara'}
                        </span>
                        <span className="font-mono tabular-nums font-bold text-blue-700">
                          {formatRupiah(estimatedTotal)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2 text-slate-700 leading-relaxed pt-0.5">
                      <Info className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                      <span>
                        {activeSelectedRate
                          ? 'Tarif J&T Express masih berupa estimasi dan diverifikasi ulang oleh server sebelum pesanan disimpan.'
                          : 'Pengiriman ke alamat menggunakan J&T Express. Jika tarif otomatis belum terpilih, ongkos kirim akan dikonfirmasi Owner toko sebelum paket dikirim.'}
                      </span>
                    </div>

                    {hasAnyUnweighedItems && (
                      <div
                        role="note"
                        className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-2 leading-relaxed"
                      >
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span>
                          {weightSummary.allItemsUnweighed
                            ? 'Berat produk pada pesanan ini belum tersedia di katalog. Pesanan tetap dapat dibuat dan berat paket akan ditimbang oleh Owner.'
                            : weightSummary.unweighedItemNames.length > 0
                            ? `Sebagian produk (${weightSummary.unweighedItemNames.slice(0, 2).join(', ')}${weightSummary.unweighedItemNames.length > 2 ? ', dll.' : ''}) belum memiliki data berat valid. Total berat akhir akan dipastikan Owner.`
                            : 'Sebagian produk pada pesanan ini belum memiliki data berat valid. Total berat akhir akan dipastikan Owner.'}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3 pt-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="block text-sm font-semibold text-slate-800">
                        Alamat Pengiriman Lengkap <span className="text-rose-600">*</span>
                      </span>
                      {(hasRegionFailureOrEmpty || useManualAddressFallback) && (
                        <button
                          type="button"
                          onClick={() =>
                            setUseManualAddressFallback((prev) => !prev)
                          }
                          className="text-xs font-semibold text-blue-700 hover:underline shrink-0"
                        >
                          {useManualAddressFallback
                            ? 'Pakai pilihan wilayah'
                            : 'Isi alamat manual'}
                        </button>
                      )}
                    </div>

                    {useManualAddressFallback ? (
                      <div className="space-y-1.5">
                        <label
                          htmlFor="guest-address"
                          className="block text-xs font-semibold text-slate-700"
                        >
                          Alamat Lengkap Manual <span className="text-rose-600">*</span>
                        </label>
                        <textarea
                          id="guest-address"
                          rows={3}
                          required
                          maxLength={360}
                          value={deliveryAddress}
                          onChange={(e) => setDeliveryAddress(e.target.value)}
                          placeholder="Nama jalan, kelurahan/desa, kecamatan, kota/kabupaten, provinsi..."
                          className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                        />
                      </div>
                    ) : (
                      <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3">
                        <SearchableRegionSelect
                          id="region-province"
                          label="Provinsi"
                          placeholder="Pilih Provinsi"
                          searchPlaceholder="Cari nama atau kode provinsi..."
                          options={provinces}
                          value={selectedProvince}
                          isLoading={isLoadingProvinces}
                          hasLoaded={hasLoadedProvinces}
                          errorMessage={provincesError}
                          onSelect={handleSelectProvince}
                          onRetry={() => setProvincesRetryCount((c) => c + 1)}
                        />

                        <SearchableRegionSelect
                          id="region-city"
                          label="Kabupaten / Kota"
                          placeholder={
                            selectedProvince
                              ? 'Pilih Kabupaten / Kota'
                              : 'Pilih Provinsi dahulu'
                          }
                          searchPlaceholder="Cari nama atau kode kabupaten/kota..."
                          options={cities}
                          value={selectedCity}
                          disabled={!selectedProvince}
                          isLoading={isLoadingCities}
                          hasLoaded={hasLoadedCities}
                          errorMessage={citiesError}
                          onSelect={handleSelectCity}
                          onRetry={() => setCitiesRetryCount((c) => c + 1)}
                        />

                        <SearchableRegionSelect
                          id="region-district"
                          label="Kecamatan"
                          placeholder={
                            selectedCity
                              ? 'Pilih Kecamatan'
                              : 'Pilih Kabupaten / Kota dahulu'
                          }
                          searchPlaceholder="Cari nama atau kode kecamatan..."
                          options={districts}
                          value={selectedDistrict}
                          disabled={!selectedCity}
                          isLoading={isLoadingDistricts}
                          hasLoaded={hasLoadedDistricts}
                          errorMessage={districtsError}
                          onSelect={handleSelectDistrict}
                          onRetry={() => setDistrictsRetryCount((c) => c + 1)}
                        />

                        <SearchableRegionSelect
                          id="region-village"
                          label="Kelurahan / Desa"
                          placeholder={
                            selectedDistrict
                              ? 'Pilih Kelurahan / Desa'
                              : 'Pilih Kecamatan dahulu'
                          }
                          searchPlaceholder="Cari nama atau kode kelurahan/desa..."
                          options={villages}
                          value={selectedVillage}
                          disabled={!selectedDistrict}
                          isLoading={isLoadingVillages}
                          hasLoaded={hasLoadedVillages}
                          errorMessage={villagesError}
                          onSelect={handleSelectVillage}
                          onRetry={() => setVillagesRetryCount((c) => c + 1)}
                        />

                        {selectedVillage ? (
                          <div className="space-y-3 pt-2 border-t border-slate-200">
                            <div>
                              <label
                                htmlFor="guest-street-address"
                                className="block text-xs font-semibold text-slate-700 mb-1"
                              >
                                Nama Jalan <span className="text-rose-600">*</span>
                              </label>
                              <input
                                id="guest-street-address"
                                type="text"
                                required
                                maxLength={90}
                                value={streetAddress}
                                onChange={(e) => setStreetAddress(e.target.value)}
                                placeholder="Contoh: Jl. Jenderal Sudirman"
                                className="w-full min-h-[42px] px-3.5 py-2 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                              />
                            </div>

                            {formattedStructuredAddress && (
                              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-[11px] text-slate-600 leading-relaxed break-words">
                                <span className="font-semibold text-slate-700">
                                  Ringkasan alamat:{' '}
                                </span>
                                {formattedStructuredAddress}
                              </div>
                            )}
                          </div>
                        ) : (
                          <p className="text-[11px] text-slate-500 pt-1">
                            Pilih Provinsi hingga Kelurahan/Desa untuk mengisi nama jalan pengiriman.
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div>
                <label
                  htmlFor="guest-notes"
                  className="block text-sm font-semibold text-slate-800 mb-1.5"
                >
                  Catatan Pesanan <span className="text-slate-400 font-normal">(opsional)</span>
                </label>
                <input
                  id="guest-notes"
                  type="text"
                  maxLength={200}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Contoh: Kurangi es / kantong kertas terpisah"
                  className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
                />
              </div>
            </div>

            <div className="p-5 border-t border-slate-200 bg-slate-50/80 space-y-3 shrink-0">
              {isJntDelivery && rateChangeConfirmation && (
                <div
                  role="alert"
                  className="p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-950 text-xs space-y-1.5"
                >
                  <div className="flex items-start gap-2 font-semibold">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>Konfirmasi Perubahan Ongkos Kirim</span>
                  </div>
                  <p className="leading-relaxed text-amber-900">
                    {rateChangeConfirmation.message}
                  </p>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-amber-200/80 font-mono text-[11px]">
                    <span>
                      Estimasi awal: {formatRupiah(rateChangeConfirmation.previousFee)}
                    </span>
                    <span className="font-bold">
                      {rateChangeConfirmation.nextFee !== null
                        ? `Tarif server: ${formatRupiah(rateChangeConfirmation.nextFee)}`
                        : 'Status: Dikonfirmasi Owner'}
                    </span>
                  </div>
                </div>
              )}

              {isJntDelivery ? (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>Subtotal ({totalQty} barang)</span>
                    <span className="font-mono tabular-nums font-medium text-slate-800">
                      {formatRupiah(subtotal)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-600">
                    <span>
                      {activeSelectedRate
                        ? `Estimasi Ongkir J&T (${activeSelectedRate.serviceCode})`
                        : 'Ongkir J&T Express'}
                    </span>
                    {isQuotingRates ? (
                      <span className="font-medium text-blue-700">
                        Menghitung...
                      </span>
                    ) : activeSelectedRate ? (
                      <span className="font-mono tabular-nums font-semibold text-slate-900">
                        {formatRupiah(activeSelectedRate.cost)}
                      </span>
                    ) : (
                      <span className="font-medium text-amber-800">
                        Menunggu konfirmasi Owner
                      </span>
                    )}
                  </div>
                  <div className="flex items-center justify-between text-sm pt-1 border-t border-slate-200/80">
                    <span className="font-semibold text-slate-800">
                      {activeSelectedRate ? 'Estimasi Total' : 'Total Sementara'}
                    </span>
                    <span className="font-mono tabular-nums text-lg font-bold text-blue-700">
                      {formatRupiah(estimatedTotal)}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-600">
                    Total ({totalQty} barang)
                  </span>
                  <span className="font-mono tabular-nums text-lg font-bold text-blue-700">
                    {formatRupiah(subtotal)}
                  </span>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting || (isJntDelivery && isQuotingRates)}
                className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 active:scale-[0.99] text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-sm shadow-blue-600/20 transition-all"
              >
                {isSubmitting
                  ? 'Mengirim Pesanan...'
                  : isJntDelivery && isQuotingRates
                  ? 'Menghitung Tarif J&T...'
                  : rateChangeConfirmation
                  ? rateChangeConfirmation.nextFee !== null
                    ? 'Setuju Tarif Baru & Kirim Pesanan'
                    : 'Lanjutkan Ongkir Manual & Kirim Pesanan'
                  : 'Kirim Pesanan'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
