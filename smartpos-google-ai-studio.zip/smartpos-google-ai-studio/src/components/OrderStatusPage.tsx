import {
  AlertTriangle,
  Check,
  CheckCircle2,
  Clock,
  Copy,
  Package,
  PackageCheck,
  RefreshCw,
  Search,
  Store,
  Truck,
  XCircle,
} from 'lucide-react';
import { FormEvent, useEffect, useState } from 'react';
import { apiUrl } from '../lib/api';
import type { GuestOrder, GuestOrderStatus } from '../types/pos';
import { formatDateTimeID, formatRupiah } from '../utils/format';
import {
  copyTrackingNumberText,
  getJntShippingViewModel,
} from '../utils/orderShippingView';
import { SmartImage } from './SmartImage';

interface OrderStatusPageProps {
  activeOrder: GuestOrder | null;
  recentOrders: GuestOrder[];
  onOrderLoaded: (order: GuestOrder) => void;
  onBackToCatalog: () => void;
}

type NormalizedOrderStatus =
  | 'PENDING'
  | 'ACCEPTED'
  | 'READY'
  | 'COMPLETED'
  | 'REJECTED'
  | 'CANCELLED';

function normalizeStatus(status: GuestOrderStatus): NormalizedOrderStatus {
  const upper = status.toUpperCase();
  if (
    upper === 'PENDING' ||
    upper === 'ACCEPTED' ||
    upper === 'READY' ||
    upper === 'COMPLETED' ||
    upper === 'REJECTED' ||
    upper === 'CANCELLED'
  ) {
    return upper;
  }
  return 'PENDING';
}

const STATUS_LABEL: Record<NormalizedOrderStatus, string> = {
  PENDING: 'Menunggu Konfirmasi Kasir',
  ACCEPTED: 'Pesanan Diterima & Disiapkan',
  READY: 'Siap Diambil / Sedang Dikirim',
  COMPLETED: 'Pesanan Selesai',
  REJECTED: 'Pesanan Ditolak Kasir',
  CANCELLED: 'Pesanan Dibatalkan',
};

const STATUS_DESC: Record<NormalizedOrderStatus, string> = {
  PENDING:
    'Pesanan Anda telah masuk ke antrean SmartPOS Kasir dan menunggu konfirmasi stok serta harga.',
  ACCEPTED:
    'Kasir telah mengonfirmasi pesanan Anda. Barang sedang disiapkan di toko.',
  READY:
    'Pesanan Anda telah siap diambil di konter kasir atau sedang dalam pengantaran.',
  COMPLETED: 'Transaksi selesai. Terima kasih telah berbelanja di toko kami.',
  REJECTED:
    'Mohon maaf, pesanan tidak dapat diproses oleh kasir. Silakan hubungi toko atau buat pesanan baru.',
  CANCELLED:
    'Pesanan ini telah dibatalkan. Silakan buat pesanan baru apabila masih membutuhkan produk.',
};

export function OrderStatusPage({
  activeOrder,
  recentOrders,
  onOrderLoaded,
  onBackToCatalog,
}: OrderStatusPageProps) {
  const [lookupInput, setLookupInput] = useState(activeOrder?.orderNumber ?? '');
  const [phoneLast4Input, setPhoneLast4Input] = useState(() =>
    activeOrder?.customerPhone ? activeOrder.customerPhone.replace(/\D/g, '').slice(-4) : ''
  );
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState<'idle' | 'copied' | 'failed'>('idle');

  useEffect(() => {
    if (activeOrder?.orderNumber) {
      setLookupInput(activeOrder.orderNumber);
    }
    if (activeOrder?.customerPhone) {
      setPhoneLast4Input(activeOrder.customerPhone.replace(/\D/g, '').slice(-4));
    }
    setCopyFeedback('idle');
  }, [activeOrder?.orderNumber, activeOrder?.customerPhone, activeOrder?.shipping?.trackingNumber]);

  async function fetchOrderStatus(
    orderNumber: string,
    phoneLast4: string,
    silent = false
  ) {
    const cleanNumber = orderNumber.trim().toUpperCase();
    const cleanLast4 = phoneLast4.replace(/\D/g, '').slice(-4);
    if (!cleanNumber) return;

    if (!/^\d{4}$/.test(cleanLast4)) {
      if (!silent) {
        setLookupError(
          'Masukkan 4 digit terakhir nomor WhatsApp untuk verifikasi keamanan pesanan.'
        );
      }
      return;
    }

    try {
      if (!silent) {
        setIsLoading(true);
        setLookupError(null);
      }
      const res = await fetch(
        apiUrl(
          `/api/guest-orders/${encodeURIComponent(cleanNumber)}?phoneLast4=${encodeURIComponent(cleanLast4)}`
        ),
        { cache: 'no-store' }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (!silent) {
          setLookupError(data?.error || 'Nomor pesanan atau verifikasi tidak cocok.');
        }
        return;
      }
      onOrderLoaded(data.order as GuestOrder);
    } catch {
      if (!silent) {
        setLookupError('Gagal memeriksa status pesanan. Coba beberapa saat lagi.');
      }
    } finally {
      if (!silent) setIsLoading(false);
    }
  }

  const normalizedStatus: NormalizedOrderStatus | null = activeOrder
    ? normalizeStatus(activeOrder.status)
    : null;

  // Poll active non-terminal orders every 10 seconds to reflect cashier updates
  useEffect(() => {
    if (
      !activeOrder ||
      normalizedStatus === 'COMPLETED' ||
      normalizedStatus === 'REJECTED' ||
      normalizedStatus === 'CANCELLED'
    ) {
      return;
    }

    const activeLast4 = activeOrder.customerPhone.replace(/\D/g, '').slice(-4);
    if (!/^\d{4}$/.test(activeLast4)) return;

    const timer = window.setInterval(() => {
      fetchOrderStatus(activeOrder.orderNumber, activeLast4, true);
    }, 10000);

    return () => window.clearInterval(timer);
  }, [activeOrder?.orderNumber, activeOrder?.customerPhone, normalizedStatus]);

  function handleSearchSubmit(e: FormEvent) {
    e.preventDefault();
    fetchOrderStatus(lookupInput, phoneLast4Input, false);
  }

  async function handleCopyTrackingNumber(trackingNumber: string) {
    const ok = await copyTrackingNumberText(trackingNumber);
    setCopyFeedback(ok ? 'copied' : 'failed');
    window.setTimeout(() => {
      setCopyFeedback('idle');
    }, 2200);
  }

  const jntView = activeOrder ? getJntShippingViewModel(activeOrder) : null;

  const steps: Array<{ key: NormalizedOrderStatus; label: string }> = [
    { key: 'PENDING', label: 'Menunggu' },
    { key: 'ACCEPTED', label: 'Diproses' },
    { key: 'READY', label: activeOrder?.fulfillmentType === 'delivery' ? 'Dikirim' : 'Siap' },
    { key: 'COMPLETED', label: 'Selesai' },
  ];

  const currentStepIndex = normalizedStatus
    ? steps.findIndex((s) => s.key === normalizedStatus)
    : -1;

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 space-y-8">
      <div className="space-y-2">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-900 tracking-tight text-balance">
          Status Pesanan Pelanggan
        </h1>
        <p className="text-sm md:text-base text-slate-600">
          Pantau konfirmasi dari SmartPOS Owner menggunakan nomor pesanan dan 4 digit akhir WhatsApp Anda.
        </p>
      </div>

      <form
        onSubmit={handleSearchSubmit}
        className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row gap-3"
      >
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={lookupInput}
            onChange={(e) => setLookupInput(e.target.value)}
            placeholder="Nomor pesanan, contoh: SPG-261118-A1B2C3"
            aria-label="Cari nomor pesanan"
            className="w-full min-h-[44px] pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
          />
        </div>
        <div className="sm:w-44">
          <input
            type="text"
            inputMode="numeric"
            maxLength={4}
            value={phoneLast4Input}
            onChange={(e) =>
              setPhoneLast4Input(e.target.value.replace(/\D/g, '').slice(0, 4))
            }
            placeholder="4 digit akhir WA"
            aria-label="4 digit terakhir nomor WhatsApp"
            className="w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 focus:bg-white font-mono text-sm text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading || !lookupInput.trim() || phoneLast4Input.length !== 4}
          className="min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold whitespace-nowrap shrink-0 transition-colors"
        >
          {isLoading ? 'Memeriksa...' : 'Cek Pesanan'}
        </button>
      </form>

      {lookupError && (
        <div
          role="alert"
          className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-sm"
        >
          {lookupError}
        </div>
      )}

      {recentOrders.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs font-medium text-slate-500">
            Pesanan tersimpan di perangkat ini
          </p>
          <div className="flex flex-wrap gap-2">
            {recentOrders.map((ord) => {
              const isSelected = activeOrder?.orderNumber === ord.orderNumber;
              const ordLast4 = ord.customerPhone.replace(/\D/g, '').slice(-4);
              return (
                <button
                  key={ord.orderNumber}
                  type="button"
                  onClick={() => {
                    setLookupInput(ord.orderNumber);
                    setPhoneLast4Input(ordLast4);
                    fetchOrderStatus(ord.orderNumber, ordLast4, false);
                  }}
                  className={`min-h-[40px] px-3.5 py-2 rounded-xl border text-xs font-mono font-medium transition-colors whitespace-nowrap ${
                    isSelected
                      ? 'bg-blue-600 border-blue-600 text-white'
                      : 'bg-white border-slate-200 text-slate-700 hover:border-blue-300 hover:text-blue-700'
                  }`}
                >
                  {ord.orderNumber}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {activeOrder ? (
        <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-xs">
          <div className="px-5 sm:px-6 py-5 bg-blue-50/70 border-b border-blue-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <p className="text-xs font-medium text-blue-700">
                Nomor Pesanan Otomatis
              </p>
              <p className="mt-1 font-mono tabular-nums text-xl sm:text-2xl font-bold text-slate-900">
                {activeOrder.orderNumber}
              </p>
              <p className="mt-1 text-xs text-slate-500">
                Dibuat {formatDateTimeID(activeOrder.createdAt)}
              </p>
            </div>

            <button
              type="button"
              onClick={() =>
                fetchOrderStatus(
                  activeOrder.orderNumber,
                  activeOrder.customerPhone.replace(/\D/g, '').slice(-4),
                  false
                )
              }
              disabled={isLoading}
              className="self-start sm:self-auto min-h-[40px] px-3.5 py-2 rounded-xl bg-white border border-blue-200 hover:bg-blue-50 text-blue-700 text-xs font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Perbarui Status</span>
            </button>
          </div>

          <div className="p-5 sm:p-6 space-y-6">
            <div
              className={`p-4 rounded-2xl border flex items-start gap-3 ${
                normalizedStatus === 'REJECTED' || normalizedStatus === 'CANCELLED'
                  ? 'bg-rose-50 border-rose-200 text-rose-900'
                  : normalizedStatus === 'COMPLETED'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-blue-50/50 border-blue-100 text-slate-900'
              }`}
            >
              {normalizedStatus === 'REJECTED' || normalizedStatus === 'CANCELLED' ? (
                <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              ) : normalizedStatus === 'COMPLETED' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : normalizedStatus === 'READY' ? (
                <PackageCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              ) : (
                <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              )}

              <div>
                <h2 className="text-sm sm:text-base font-bold">
                  {normalizedStatus ? STATUS_LABEL[normalizedStatus] : ''}
                </h2>
                <p className="mt-1 text-xs sm:text-sm opacity-85 leading-relaxed">
                  {activeOrder.rejectionReason ||
                    (normalizedStatus ? STATUS_DESC[normalizedStatus] : '')}
                </p>
              </div>
            </div>

            {normalizedStatus !== 'REJECTED' && normalizedStatus !== 'CANCELLED' && (
              <div className="grid grid-cols-4 gap-2 pt-1">
                {steps.map((step, idx) => {
                  const isDone = currentStepIndex >= idx;
                  return (
                    <div key={step.key} className="space-y-2">
                      <div
                        className={`h-1.5 rounded-full transition-colors ${
                          isDone ? 'bg-blue-600' : 'bg-slate-200'
                        }`}
                      />
                      <p
                        className={`text-xs font-medium truncate ${
                          isDone ? 'text-blue-700 font-semibold' : 'text-slate-400'
                        }`}
                      >
                        {step.label}
                      </p>
                    </div>
                  );
                })}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100 text-sm">
              <div>
                <p className="text-xs text-slate-500">Pemesan</p>
                <p className="mt-0.5 font-semibold text-slate-900">
                  {activeOrder.customerName}
                </p>
                <p className="font-mono text-xs text-slate-600 mt-0.5">
                  +{activeOrder.customerPhone}
                </p>
              </div>

              <div>
                <p className="text-xs text-slate-500">Metode Penerimaan</p>
                <div className="mt-0.5 flex flex-wrap items-center gap-2">
                  <p className="font-semibold text-slate-900 inline-flex items-center gap-1.5">
                    {activeOrder.fulfillmentType === 'delivery' ? (
                      <>
                        <Truck className="w-4 h-4 text-blue-600" />
                        <span>Kirim ke Alamat</span>
                      </>
                    ) : (
                      <>
                        <Store className="w-4 h-4 text-blue-600" />
                        <span>Ambil di Toko</span>
                      </>
                    )}
                  </p>
                  {jntView && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-xs font-bold">
                      <Package className="w-3 h-3" />
                      <span>{jntView.serviceLabel}</span>
                    </span>
                  )}
                </div>
                {activeOrder.deliveryAddress && (
                  <p className="text-xs text-slate-600 mt-1">
                    {activeOrder.deliveryAddress}
                  </p>
                )}
                {activeOrder.notes && (
                  <p className="text-xs text-slate-500 mt-1">
                    Catatan: {activeOrder.notes}
                  </p>
                )}
              </div>
            </div>

            {jntView && (
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
                      <Package className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">
                        Informasi Pengiriman {jntView.serviceLabel}
                      </h3>
                      <p className="text-xs text-slate-500">
                        Status kurir dikelola oleh Owner toko
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${
                      jntView.isFailed
                        ? 'bg-rose-100 text-rose-800 border border-rose-200'
                        : jntView.shippingStatus === 'DELIVERED'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : jntView.shippingStatus === 'PENDING_RATE'
                        ? 'bg-amber-100 text-amber-900 border border-amber-200'
                        : 'bg-blue-100 text-blue-800 border border-blue-200'
                    }`}
                  >
                    {jntView.statusLabel}
                  </span>
                </div>

                <div
                  className={`p-3.5 rounded-xl border text-xs sm:text-sm flex items-start gap-2.5 ${
                    jntView.isFailed
                      ? 'bg-amber-50 border-amber-200 text-amber-950'
                      : 'bg-white border-slate-200 text-slate-700'
                  }`}
                >
                  {jntView.isFailed ? (
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  ) : (
                    <Truck className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-1">
                    <p className="font-semibold text-slate-900">
                      {jntView.statusLabel}
                    </p>
                    <p className="text-xs leading-relaxed opacity-90">
                      {jntView.statusDescription}
                    </p>
                    {jntView.shippingNotes && (
                      <p className="text-xs text-slate-600 pt-0.5">
                        Catatan pengiriman: {jntView.shippingNotes}
                      </p>
                    )}
                  </div>
                </div>

                {!jntView.isFailed && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                    {jntView.progressSteps.map((step, idx) => {
                      const isDone = jntView.currentProgressIndex >= idx;
                      return (
                        <div key={step.key} className="space-y-1.5">
                          <div
                            className={`h-1.5 rounded-full transition-colors ${
                              isDone ? 'bg-blue-600' : 'bg-slate-200'
                            }`}
                          />
                          <p
                            className={`text-[11px] sm:text-xs font-medium leading-tight ${
                              isDone ? 'text-blue-700 font-semibold' : 'text-slate-400'
                            }`}
                          >
                            {step.label}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200/80 text-xs">
                  <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-1.5">
                    <p className="text-slate-500">Nomor Resi / AWB</p>
                    {jntView.hasTrackingNumber && jntView.trackingNumber ? (
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <span className="font-mono text-sm font-bold text-slate-900 select-all break-all">
                          {jntView.trackingNumber}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            handleCopyTrackingNumber(jntView.trackingNumber!)
                          }
                          aria-label="Salin nomor resi J&T"
                          className="min-h-[34px] px-2.5 py-1.5 rounded-lg border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs font-semibold inline-flex items-center gap-1.5 transition-colors shrink-0"
                        >
                          {copyFeedback === 'copied' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Tersalin</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>Salin Resi</span>
                            </>
                          )}
                        </button>
                      </div>
                    ) : (
                      <p className="text-slate-600 font-medium">
                        Nomor resi belum tersedia
                      </p>
                    )}
                    {copyFeedback === 'failed' && (
                      <p className="text-[11px] text-rose-600">
                        Gagal menyalin otomatis. Silakan salin nomor resi secara manual.
                      </p>
                    )}
                  </div>

                  <div className="p-3 rounded-xl bg-white border border-slate-200 space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-slate-500">Total Berat Paket</span>
                      <span className="font-mono font-semibold text-slate-900">
                        {jntView.weightLabel ?? 'Belum tersedia'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-slate-500">Status Ongkir</span>
                      {jntView.isShippingFeeConfirmed &&
                      jntView.confirmedShippingFee !== null ? (
                        <span className="font-mono font-semibold text-emerald-700">
                          {formatRupiah(jntView.confirmedShippingFee)} (Terkonfirmasi)
                        </span>
                      ) : (
                        <span className="font-medium text-amber-800 text-right">
                          Menunggu konfirmasi Owner
                        </span>
                      )}
                    </div>
                    {jntView.shippedAt && (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500">Waktu Kirim</span>
                        <span className="text-slate-700">
                          {formatDateTimeID(jntView.shippedAt)}
                        </span>
                      </div>
                    )}
                    {jntView.deliveredAt && (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-500">Waktu Diterima</span>
                        <span className="text-emerald-700 font-medium">
                          {formatDateTimeID(jntView.deliveredAt)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {jntView.hasIncompleteWeightWarning && jntView.incompleteWeightMessage && (
                  <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>{jntView.incompleteWeightMessage}</span>
                  </div>
                )}
              </div>
            )}

            <div className="pt-4 border-t border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 mb-3">
                Rincian Barang
              </h3>
              <div className="divide-y divide-slate-100">
                {activeOrder.items.map((item) => (
                  <div
                    key={item.productId}
                    className="py-3 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-12 h-10 rounded-lg overflow-hidden bg-slate-100 shrink-0">
                        <SmartImage
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">
                          {item.name}
                        </p>
                        <p className="text-xs text-slate-500 font-mono tabular-nums">
                          {item.quantity} × {formatRupiah(item.unitPrice)}
                        </p>
                      </div>
                    </div>

                    <p className="font-mono tabular-nums text-sm font-semibold text-slate-900 shrink-0">
                      {formatRupiah(item.subtotal)}
                    </p>
                  </div>
                ))}
              </div>

              {jntView ? (
                <div className="mt-4 pt-4 border-t border-slate-200 space-y-2">
                  <div className="flex items-center justify-between text-xs sm:text-sm text-slate-600">
                    <span>Subtotal Barang</span>
                    <span className="font-mono tabular-nums font-medium text-slate-900">
                      {formatRupiah(jntView.itemsSubtotal)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs sm:text-sm text-slate-600 gap-3">
                    <span>Ongkos Kirim (J&T Express)</span>
                    {jntView.isShippingFeeConfirmed &&
                    jntView.confirmedShippingFee !== null ? (
                      <span className="font-mono tabular-nums font-semibold text-slate-900">
                        {formatRupiah(jntView.confirmedShippingFee)}
                      </span>
                    ) : (
                      <span className="text-xs font-medium text-amber-800 text-right">
                        {jntView.shippingFeePendingText}
                      </span>
                    )}
                  </div>
                  <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between gap-3">
                    <span className="text-sm font-semibold text-slate-800">
                      {jntView.totalLabel}
                    </span>
                    <span className="font-mono tabular-nums text-lg font-bold text-blue-700">
                      {formatRupiah(jntView.totalAmount)}
                    </span>
                  </div>
                  {!jntView.isShippingFeeConfirmed && (
                    <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-3 py-2">
                      {jntView.shippingFeePendingText}
                    </p>
                  )}
                </div>
              ) : (
                <div className="mt-4 pt-4 border-t border-slate-200 flex items-center justify-between">
                  <span className="text-sm font-semibold text-slate-700">
                    Total Pembayaran
                  </span>
                  <span className="font-mono tabular-nums text-lg font-bold text-blue-700">
                    {formatRupiah(activeOrder.totalAmount)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-3xl p-8 text-center">
          <p className="text-base font-semibold text-slate-900">
            Belum ada pesanan yang dipilih
          </p>
          <p className="mt-1.5 text-sm text-slate-500 max-w-md mx-auto">
            Masukkan nomor pesanan di kolom pencarian di atas, atau mulai belanja dari katalog produk tanpa login.
          </p>
          <button
            type="button"
            onClick={onBackToCatalog}
            className="mt-5 min-h-[44px] px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors"
          >
            Buka Katalog Produk
          </button>
        </div>
      )}
    </section>
  );
}
