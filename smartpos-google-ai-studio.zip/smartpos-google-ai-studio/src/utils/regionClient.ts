import { apiUrl } from '../lib/api';
import type { RegionLevel, RegionListResponse, RegionOption } from '../types/pos';

export interface RegionFetchResult {
  ok: boolean;
  aborted: boolean;
  statusCode?: number;
  level: RegionLevel;
  parentCode?: string;
  regions: RegionOption[];
  errorMessage?: string;
}

export interface CascadingRegionSelection {
  province: RegionOption | null;
  city: RegionOption | null;
  district: RegionOption | null;
  village: RegionOption | null;
}

export function applyCascadingRegionSelection(
  current: CascadingRegionSelection,
  level: RegionLevel,
  option: RegionOption | null
): CascadingRegionSelection {
  if (level === 'provinces') {
    return { province: option, city: null, district: null, village: null };
  }
  if (level === 'cities') {
    return {
      province: current.province,
      city: option,
      district: null,
      village: null,
    };
  }
  if (level === 'districts') {
    return {
      province: current.province,
      city: current.city,
      district: option,
      village: null,
    };
  }
  return {
    province: current.province,
    city: current.city,
    district: current.district,
    village: option,
  };
}

function isAbortError(err: unknown): boolean {
  return (
    err instanceof Error &&
    (err.name === 'AbortError' || err.message.toLowerCase().includes('aborted'))
  );
}

export function sanitizeRegionOptions(rawRegions: unknown): {
  valid: boolean;
  regions: RegionOption[];
} {
  if (!Array.isArray(rawRegions)) {
    return { valid: false, regions: [] };
  }

  if (rawRegions.length === 0) {
    return { valid: true, regions: [] };
  }

  const deduped = new Map<string, RegionOption>();
  for (const entry of rawRegions) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
    const item = entry as Partial<RegionOption>;
    const code = typeof item.code === 'string' ? item.code.trim() : '';
    const name = typeof item.name === 'string' ? item.name.trim() : '';
    if (!/^[0-9.]{2,20}$/.test(code) || !name) {
      continue;
    }
    if (!deduped.has(code)) {
      deduped.set(code, { code, name });
    }
  }

  if (deduped.size === 0) {
    return { valid: false, regions: [] };
  }

  return {
    valid: true,
    regions: Array.from(deduped.values()),
  };
}

function mapRegionHttpError(status: number, serverMessage?: string): string {
  const cleanMsg =
    typeof serverMessage === 'string' && serverMessage.trim()
      ? serverMessage.trim()
      : undefined;

  if (status === 400) {
    return cleanMsg || 'Kode wilayah tidak valid.';
  }
  if (status === 404) {
    return cleanMsg || 'Data wilayah tidak ditemukan.';
  }
  if (status === 429) {
    return (
      cleanMsg ||
      'Terlalu banyak permintaan daftar wilayah. Tunggu sebentar lalu coba lagi.'
    );
  }
  if (status === 504) {
    return (
      cleanMsg ||
      'Koneksi ke layanan wilayah habis waktu. Silakan coba lagi.'
    );
  }
  return cleanMsg || 'Gagal memuat data wilayah. Silakan coba lagi.';
}

async function fetchRegionLevel(params: {
  level: RegionLevel;
  endpointPath: string;
  parentCode?: string;
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
}): Promise<RegionFetchResult> {
  const fetchFn = params.fetchImpl ?? fetch;

  try {
    const response = await fetchFn(apiUrl(params.endpointPath), {
      method: 'GET',
      cache: 'no-store',
      headers: { Accept: 'application/json' },
      signal: params.signal,
    });

    const json = (await response.json().catch(() => null)) as
      | (Partial<RegionListResponse> & { error?: string })
      | null;

    if (!response.ok) {
      return {
        ok: false,
        aborted: false,
        statusCode: response.status,
        level: params.level,
        parentCode: params.parentCode,
        regions: [],
        errorMessage: mapRegionHttpError(response.status, json?.error),
      };
    }

    if (!json || typeof json !== 'object') {
      return {
        ok: false,
        aborted: false,
        statusCode: response.status,
        level: params.level,
        parentCode: params.parentCode,
        regions: [],
        errorMessage: 'Format data wilayah dari server tidak valid.',
      };
    }

    const sanitized = sanitizeRegionOptions(json.regions);
    if (!sanitized.valid) {
      return {
        ok: false,
        aborted: false,
        statusCode: response.status,
        level: params.level,
        parentCode: params.parentCode,
        regions: [],
        errorMessage: 'Data wilayah yang diterima tidak valid.',
      };
    }

    return {
      ok: true,
      aborted: false,
      statusCode: response.status,
      level: params.level,
      parentCode: params.parentCode,
      regions: sanitized.regions,
    };
  } catch (err) {
    if (isAbortError(err) || params.signal?.aborted) {
      return {
        ok: false,
        aborted: true,
        level: params.level,
        parentCode: params.parentCode,
        regions: [],
      };
    }
    return {
      ok: false,
      aborted: false,
      level: params.level,
      parentCode: params.parentCode,
      regions: [],
      errorMessage: 'Koneksi terganggu saat memuat data wilayah. Silakan coba lagi.',
    };
  }
}

export async function fetchRegionProvinces(options?: {
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
}): Promise<RegionFetchResult> {
  return fetchRegionLevel({
    level: 'provinces',
    endpointPath: '/api/regions/provinces',
    signal: options?.signal,
    fetchImpl: options?.fetchImpl,
  });
}

export async function fetchRegionCities(
  stateCode: string,
  options?: {
    signal?: AbortSignal;
    fetchImpl?: typeof fetch;
  }
): Promise<RegionFetchResult> {
  const cleanCode = stateCode.trim();
  if (!/^\d{2}$/.test(cleanCode)) {
    return {
      ok: false,
      aborted: false,
      statusCode: 400,
      level: 'cities',
      parentCode: cleanCode,
      regions: [],
      errorMessage: 'Kode provinsi tidak valid.',
    };
  }
  return fetchRegionLevel({
    level: 'cities',
    endpointPath: `/api/regions/provinces/${encodeURIComponent(cleanCode)}/cities`,
    parentCode: cleanCode,
    signal: options?.signal,
    fetchImpl: options?.fetchImpl,
  });
}

export async function fetchRegionDistricts(
  cityCode: string,
  options?: {
    signal?: AbortSignal;
    fetchImpl?: typeof fetch;
  }
): Promise<RegionFetchResult> {
  const cleanCode = cityCode.trim();
  if (!/^\d{2}\.\d{2}$/.test(cleanCode)) {
    return {
      ok: false,
      aborted: false,
      statusCode: 400,
      level: 'districts',
      parentCode: cleanCode,
      regions: [],
      errorMessage: 'Kode kabupaten/kota tidak valid.',
    };
  }
  return fetchRegionLevel({
    level: 'districts',
    endpointPath: `/api/regions/cities/${encodeURIComponent(cleanCode)}/districts`,
    parentCode: cleanCode,
    signal: options?.signal,
    fetchImpl: options?.fetchImpl,
  });
}

export async function fetchRegionVillages(
  districtCode: string,
  options?: {
    signal?: AbortSignal;
    fetchImpl?: typeof fetch;
  }
): Promise<RegionFetchResult> {
  const cleanCode = districtCode.trim();
  if (!/^\d{2}\.\d{2}\.\d{2}$/.test(cleanCode)) {
    return {
      ok: false,
      aborted: false,
      statusCode: 400,
      level: 'villages',
      parentCode: cleanCode,
      regions: [],
      errorMessage: 'Kode kecamatan tidak valid.',
    };
  }
  return fetchRegionLevel({
    level: 'villages',
    endpointPath: `/api/regions/districts/${encodeURIComponent(cleanCode)}/villages`,
    parentCode: cleanCode,
    signal: options?.signal,
    fetchImpl: options?.fetchImpl,
  });
}
