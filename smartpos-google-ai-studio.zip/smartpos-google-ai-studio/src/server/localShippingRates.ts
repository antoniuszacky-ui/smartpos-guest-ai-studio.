import type { Request, Response } from 'express';
import crypto from 'node:crypto';
import type { DocumentData } from 'firebase-admin/firestore';
import type {
  LocalShippingRate,
  LocalShippingRateInput,
  LocalShippingRateQuoteOption,
  LocalShippingRateQuoteRequest,
  LocalShippingRateQuoteResponse,
} from '../types/pos.ts';

export const LOCAL_SHIPPING_RATES_COLLECTION = 'local_shipping_rates';
export const LOCAL_SHIPPING_RATE_LOCKS_COLLECTION = 'local_shipping_rate_locks';
export const MAX_LOCAL_SHIPPING_FEE = 50_000_000;
export const MAX_LOCAL_SHIPPING_WEIGHT_GRAMS = 10_000_000;

export class LocalShippingRateError extends Error {
  statusCode: number;
  code: string;

  constructor(statusCode: number, code: string, message: string) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

export interface LocalRateDocSnapshotLike {
  id: string;
  exists: boolean;
  data(): DocumentData | undefined;
}

export interface LocalRateQuerySnapshotLike {
  empty: boolean;
  docs: LocalRateDocSnapshotLike[];
}

export interface LocalRateDocRefLike {
  id: string;
  get(): Promise<LocalRateDocSnapshotLike>;
  set(data: Record<string, unknown>, options?: { merge?: boolean }): Promise<unknown>;
  delete(): Promise<unknown>;
}

export interface LocalRateQueryLike {
  where(fieldPath: string, opStr: '==', value: unknown): LocalRateQueryLike;
  get(): Promise<LocalRateQuerySnapshotLike>;
}

export interface LocalRateCollectionRefLike extends LocalRateQueryLike {
  doc(docId: string): LocalRateDocRefLike;
}

export interface LocalRateStoreRefLike {
  collection(name: string): LocalRateCollectionRefLike;
}

export interface LocalRateTxLike {
  get(ref: LocalRateDocRefLike): Promise<LocalRateDocSnapshotLike>;
  get(query: LocalRateQueryLike): Promise<LocalRateQuerySnapshotLike>;
  set(
    ref: LocalRateDocRefLike,
    data: Record<string, unknown>,
    options?: { merge?: boolean }
  ): unknown;
  delete(ref: LocalRateDocRefLike): unknown;
}

export type LocalRateRunTransactionFn = <T>(
  updateFunction: (tx: LocalRateTxLike) => Promise<T>
) => Promise<T>;

function toIsoTimestamp(value: unknown): string {
  if (
    value &&
    typeof (value as { toDate?: () => Date }).toDate === 'function'
  ) {
    return (value as { toDate: () => Date }).toDate().toISOString();
  }
  if (typeof value === 'number' && Number.isFinite(value)) {
    return new Date(value).toISOString();
  }
  if (typeof value === 'string' && value.trim()) {
    const parsed = Date.parse(value.trim());
    if (!Number.isNaN(parsed)) {
      return new Date(parsed).toISOString();
    }
  }
  return new Date().toISOString();
}

function parseStrictNonNegativeInt(
  value: unknown,
  maxValue: number
): number | null {
  if (
    typeof value === 'boolean' ||
    value === null ||
    value === undefined ||
    (typeof value === 'string' && !/^\d+$/.test(value.trim()))
  ) {
    return null;
  }
  const num = typeof value === 'number' ? value : Number(String(value).trim());
  if (!Number.isSafeInteger(num) || num < 0 || num > maxValue) {
    return null;
  }
  return num;
}

function parseStrictNonNegativeFee(value: unknown): number | null {
  if (
    typeof value === 'boolean' ||
    value === null ||
    value === undefined ||
    (typeof value === 'string' && value.trim() === '') ||
    (typeof value !== 'number' && typeof value !== 'string')
  ) {
    return null;
  }
  const num = typeof value === 'number' ? value : Number(value.trim());
  if (
    !Number.isFinite(num) ||
    num < 0 ||
    num > MAX_LOCAL_SHIPPING_FEE
  ) {
    return null;
  }
  return Math.round(num);
}

function normalizeLabel(value: unknown, minLen: number, maxLen: number): string | null {
  if (typeof value !== 'string') return null;
  const cleaned = value.trim().replace(/\s+/g, ' ');
  if (cleaned.length < minLen || cleaned.length > maxLen) {
    return null;
  }
  return cleaned;
}

export function isValidLocalRateId(rawId: unknown): rawId is string {
  return (
    typeof rawId === 'string' &&
    /^[a-zA-Z0-9_-]{1,128}$/.test(rawId.trim())
  );
}

export function validateLocalRateRegionHierarchy(raw: {
  provinceCode: unknown;
  provinceName: unknown;
  cityCode: unknown;
  cityName: unknown;
  districtCode: unknown;
  districtName: unknown;
}):
  | {
      ok: true;
      value: {
        provinceCode: string;
        provinceName: string;
        cityCode: string;
        cityName: string;
        districtCode: string;
        districtName: string;
      };
    }
  | { ok: false; code: string; error: string } {
  const provinceCode =
    typeof raw.provinceCode === 'string' ? raw.provinceCode.trim() : '';
  const cityCode = typeof raw.cityCode === 'string' ? raw.cityCode.trim() : '';
  const districtCode =
    typeof raw.districtCode === 'string' ? raw.districtCode.trim() : '';

  if (!/^\d{2}$/.test(provinceCode)) {
    return {
      ok: false,
      code: 'INVALID_PROVINCE_CODE',
      error: 'Kode provinsi harus mengikuti format 2 digit (contoh: 35).',
    };
  }
  if (!/^\d{2}\.\d{2}$/.test(cityCode)) {
    return {
      ok: false,
      code: 'INVALID_CITY_CODE',
      error: 'Kode kabupaten/kota harus mengikuti format XX.YY (contoh: 35.02).',
    };
  }
  if (!cityCode.startsWith(`${provinceCode}.`)) {
    return {
      ok: false,
      code: 'REGION_HIERARCHY_MISMATCH',
      error: `Kode kabupaten/kota (${cityCode}) tidak berada di bawah provinsi (${provinceCode}).`,
    };
  }
  if (!/^\d{2}\.\d{2}\.\d{2}$/.test(districtCode)) {
    return {
      ok: false,
      code: 'INVALID_DISTRICT_CODE',
      error: 'Kode kecamatan harus mengikuti format XX.YY.ZZ (contoh: 35.02.17).',
    };
  }
  if (!districtCode.startsWith(`${cityCode}.`)) {
    return {
      ok: false,
      code: 'REGION_HIERARCHY_MISMATCH',
      error: `Kode kecamatan (${districtCode}) tidak berada di bawah kabupaten/kota (${cityCode}).`,
    };
  }

  const provinceName = normalizeLabel(raw.provinceName, 2, 120);
  if (!provinceName) {
    return {
      ok: false,
      code: 'INVALID_PROVINCE_NAME',
      error: 'Nama provinsi wajib diisi (2–120 karakter).',
    };
  }
  const cityName = normalizeLabel(raw.cityName, 2, 120);
  if (!cityName) {
    return {
      ok: false,
      code: 'INVALID_CITY_NAME',
      error: 'Nama kabupaten/kota wajib diisi (2–120 karakter).',
    };
  }
  const districtName = normalizeLabel(raw.districtName, 2, 120);
  if (!districtName) {
    return {
      ok: false,
      code: 'INVALID_DISTRICT_NAME',
      error: 'Nama kecamatan wajib diisi (2–120 karakter).',
    };
  }

  return {
    ok: true,
    value: {
      provinceCode,
      provinceName,
      cityCode,
      cityName,
      districtCode,
      districtName,
    },
  };
}

export function parseLocalShippingRateInput(
  rawBody: unknown
):
  | { ok: true; value: LocalShippingRateInput }
  | { ok: false; statusCode: number; code: string; error: string } {
  if (!rawBody || typeof rawBody !== 'object' || Array.isArray(rawBody)) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_LOCAL_RATE_PAYLOAD',
      error: 'Payload tarif pengiriman lokal harus berupa objek JSON yang valid.',
    };
  }

  const body = rawBody as Record<string, unknown>;

  let id: string | undefined;
  if (body.id !== undefined && body.id !== null && String(body.id).trim() !== '') {
    if (!isValidLocalRateId(body.id)) {
      return {
        ok: false,
        statusCode: 400,
        code: 'INVALID_RATE_ID',
        error: 'ID tarif lokal hanya boleh berisi huruf, angka, garis bawah, atau tanda hubung (maks 128 karakter).',
      };
    }
    id = body.id.trim();
  }

  const regionCheck = validateLocalRateRegionHierarchy({
    provinceCode: body.provinceCode,
    provinceName: body.provinceName,
    cityCode: body.cityCode,
    cityName: body.cityName,
    districtCode: body.districtCode,
    districtName: body.districtName,
  });
  if (!regionCheck.ok) {
    return {
      ok: false,
      statusCode: 400,
      code: regionCheck.code,
      error: regionCheck.error,
    };
  }

  const courierName = normalizeLabel(body.courierName, 2, 64);
  if (!courierName) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_COURIER_NAME',
      error: 'Nama kurir lokal wajib diisi (2–64 karakter).',
    };
  }

  const serviceName = normalizeLabel(body.serviceName, 1, 80);
  if (!serviceName) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_SERVICE_NAME',
      error: 'Nama layanan pengiriman lokal wajib diisi (1–80 karakter).',
    };
  }

  const weightMinGram = parseStrictNonNegativeInt(
    body.weightMinGram,
    MAX_LOCAL_SHIPPING_WEIGHT_GRAMS
  );
  if (weightMinGram === null) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_WEIGHT_RANGE',
      error: 'Berat minimum (weightMinGram) harus berupa bilangan bulat >= 0 gram.',
    };
  }

  const weightMaxGram = parseStrictNonNegativeInt(
    body.weightMaxGram,
    MAX_LOCAL_SHIPPING_WEIGHT_GRAMS
  );
  if (weightMaxGram === null || weightMaxGram < 1) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_WEIGHT_RANGE',
      error: 'Berat maksimum (weightMaxGram) harus berupa bilangan bulat >= 1 gram.',
    };
  }

  if (weightMaxGram < weightMinGram) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_WEIGHT_RANGE',
      error: 'Berat maksimum tidak boleh lebih kecil daripada berat minimum.',
    };
  }

  const shippingFee = parseStrictNonNegativeFee(body.shippingFee);
  if (shippingFee === null) {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_SHIPPING_FEE',
      error: 'Biaya pengiriman (shippingFee) harus berupa angka Rupiah >= 0.',
    };
  }

  if (typeof body.isActive !== 'boolean') {
    return {
      ok: false,
      statusCode: 400,
      code: 'INVALID_ACTIVE_STATUS',
      error: 'Status aktif tarif (isActive) wajib berupa boolean (true/false).',
    };
  }

  return {
    ok: true,
    value: {
      ...(id ? { id } : {}),
      ...regionCheck.value,
      courierName,
      serviceName,
      weightMinGram,
      weightMaxGram,
      shippingFee,
      isActive: body.isActive,
    },
  };
}

export function parseStoredLocalShippingRateDocument(
  docId: string,
  rawDoc: unknown
): { ok: true; rate: LocalShippingRate } | { ok: false; error: string } {
  if (!isValidLocalRateId(docId)) {
    return { ok: false, error: 'ID dokumen tarif lokal tidak valid.' };
  }
  if (!rawDoc || typeof rawDoc !== 'object' || Array.isArray(rawDoc)) {
    return { ok: false, error: 'Dokumen tarif lokal bukan objek yang valid.' };
  }

  const data = rawDoc as Record<string, unknown>;
  const parsed = parseLocalShippingRateInput({
    ...data,
    id: typeof data.id === 'string' && data.id.trim() ? data.id.trim() : docId,
  });
  if (!parsed.ok) {
    return { ok: false, error: parsed.error };
  }

  return {
    ok: true,
    rate: {
      id: parsed.value.id ?? docId.trim(),
      provinceCode: parsed.value.provinceCode,
      provinceName: parsed.value.provinceName,
      cityCode: parsed.value.cityCode,
      cityName: parsed.value.cityName,
      districtCode: parsed.value.districtCode,
      districtName: parsed.value.districtName,
      courierName: parsed.value.courierName,
      serviceName: parsed.value.serviceName,
      weightMinGram: parsed.value.weightMinGram,
      weightMaxGram: parsed.value.weightMaxGram,
      shippingFee: parsed.value.shippingFee,
      isActive: parsed.value.isActive,
      updatedAt: toIsoTimestamp(data.updatedAt),
    },
  };
}

export function buildLocalRateDuplicateSignature(rate: {
  districtCode: string;
  courierName: string;
  serviceName: string;
  weightMinGram: number;
  weightMaxGram: number;
}): string {
  return [
    rate.districtCode.trim(),
    rate.courierName.trim().toLowerCase(),
    rate.serviceName.trim().toLowerCase(),
    rate.weightMinGram,
    rate.weightMaxGram,
  ].join('|');
}

export function rangesOverlap(
  minA: number,
  maxA: number,
  minB: number,
  maxB: number
): boolean {
  return minA <= maxB && minB <= maxA;
}

export function assertNoDuplicateOrOverlappingLocalRate(
  candidate: LocalShippingRateInput,
  existingRates: LocalShippingRate[],
  editingRateId?: string
): void {
  const candidateSig = buildLocalRateDuplicateSignature(candidate);
  const candidateCourier = candidate.courierName.trim().toLowerCase();
  const candidateService = candidate.serviceName.trim().toLowerCase();

  for (const existing of existingRates) {
    if (editingRateId && existing.id === editingRateId) {
      continue;
    }

    if (buildLocalRateDuplicateSignature(existing) === candidateSig) {
      throw new LocalShippingRateError(
        409,
        'DUPLICATE_LOCAL_SHIPPING_RATE',
        `Tarif duplikat sudah ada untuk ${candidate.districtName} (${candidate.courierName} - ${candidate.serviceName}, ${candidate.weightMinGram}–${candidate.weightMaxGram} g).`
      );
    }

    if (
      candidate.isActive &&
      existing.isActive &&
      existing.districtCode === candidate.districtCode &&
      existing.courierName.trim().toLowerCase() === candidateCourier &&
      existing.serviceName.trim().toLowerCase() === candidateService &&
      rangesOverlap(
        candidate.weightMinGram,
        candidate.weightMaxGram,
        existing.weightMinGram,
        existing.weightMaxGram
      )
    ) {
      throw new LocalShippingRateError(
        409,
        'OVERLAPPING_LOCAL_SHIPPING_RATE',
        `Rentang berat (${candidate.weightMinGram}–${candidate.weightMaxGram} g) bertumpukan dengan tarif aktif ${existing.courierName} - ${existing.serviceName} (${existing.weightMinGram}–${existing.weightMaxGram} g).`
      );
    }
  }
}

export function deduplicateAndSortLocalRates(
  rates: LocalShippingRate[]
): LocalShippingRate[] {
  const bySignature = new Map<string, LocalShippingRate>();

  for (const rate of rates) {
    const sig = buildLocalRateDuplicateSignature(rate);
    const existing = bySignature.get(sig);
    if (!existing) {
      bySignature.set(sig, rate);
      continue;
    }
    const existingTime = Date.parse(existing.updatedAt) || 0;
    const candidateTime = Date.parse(rate.updatedAt) || 0;
    if (candidateTime > existingTime) {
      bySignature.set(sig, rate);
    }
  }

  return Array.from(bySignature.values()).sort((a, b) => {
    if (a.shippingFee !== b.shippingFee) return a.shippingFee - b.shippingFee;
    const districtCmp = a.districtCode.localeCompare(b.districtCode);
    if (districtCmp !== 0) return districtCmp;
    const courierCmp = a.courierName.localeCompare(b.courierName, 'id-ID');
    if (courierCmp !== 0) return courierCmp;
    const serviceCmp = a.serviceName.localeCompare(b.serviceName, 'id-ID');
    if (serviceCmp !== 0) return serviceCmp;
    return a.weightMinGram - b.weightMinGram;
  });
}

export function toLocalShippingRateQuoteOption(
  rate: LocalShippingRate
): LocalShippingRateQuoteOption {
  return {
    id: rate.id,
    provinceCode: rate.provinceCode,
    provinceName: rate.provinceName,
    cityCode: rate.cityCode,
    cityName: rate.cityName,
    districtCode: rate.districtCode,
    districtName: rate.districtName,
    courierName: rate.courierName,
    serviceName: rate.serviceName,
    weightMinGram: rate.weightMinGram,
    weightMaxGram: rate.weightMaxGram,
    shippingFee: rate.shippingFee,
    updatedAt: rate.updatedAt,
  };
}

export function matchActiveLocalRatesForDistrictAndWeight(
  rawRates: unknown[],
  districtCode: string,
  weightGrams: number
): LocalShippingRateQuoteOption[] {
  if (!/^\d{2}\.\d{2}\.\d{2}$/.test(districtCode.trim())) {
    return [];
  }
  if (!Number.isFinite(weightGrams) || weightGrams <= 0) {
    return [];
  }

  const normalizedDistrict = districtCode.trim();
  const validActiveRates: LocalShippingRate[] = [];

  for (const entry of rawRates) {
    const rawId =
      entry &&
      typeof entry === 'object' &&
      typeof (entry as { id?: unknown }).id === 'string'
        ? (entry as { id: string }).id
        : '';
    const parsed = parseStoredLocalShippingRateDocument(rawId, entry);
    if (!parsed.ok) continue;

    const rate = parsed.rate;
    if (!rate.isActive) continue;
    if (rate.districtCode !== normalizedDistrict) continue;
    if (weightGrams < rate.weightMinGram || weightGrams > rate.weightMaxGram) {
      continue;
    }

    validActiveRates.push(rate);
  }

  return deduplicateAndSortLocalRates(validActiveRates).map(
    toLocalShippingRateQuoteOption
  );
}

export interface LocalShippingRateRepository {
  listAllRates(): Promise<LocalShippingRate[]>;
  listActiveRatesByDistrict(districtCode: string): Promise<LocalShippingRate[]>;
  getRateById(rateId: string): Promise<LocalShippingRate | null>;
  saveRate(input: LocalShippingRateInput): Promise<LocalShippingRate>;
  patchRate(rateId: string, rawBody: unknown): Promise<LocalShippingRate>;
  deleteRate(rateId: string): Promise<boolean>;
}

function extractValidDistrictCode(rawData: unknown): string | null {
  if (!rawData || typeof rawData !== 'object' || Array.isArray(rawData)) {
    return null;
  }
  const rawCode = (rawData as { districtCode?: unknown }).districtCode;
  if (typeof rawCode !== 'string') return null;
  const trimmed = rawCode.trim();
  return /^\d{2}\.\d{2}\.\d{2}$/.test(trimmed) ? trimmed : null;
}

function mergeAndValidatePatchInput(
  rateId: string,
  existing: LocalShippingRate,
  rawBody: unknown
): LocalShippingRateInput {
  if (!rawBody || typeof rawBody !== 'object' || Array.isArray(rawBody)) {
    throw new LocalShippingRateError(
      400,
      'INVALID_LOCAL_RATE_PAYLOAD',
      'Payload pembaruan tarif lokal harus berupa objek JSON yang valid.'
    );
  }

  const body = rawBody as Record<string, unknown>;
  const mergedCandidate = {
    id: rateId,
    provinceCode:
      body.provinceCode !== undefined ? body.provinceCode : existing.provinceCode,
    provinceName:
      body.provinceName !== undefined ? body.provinceName : existing.provinceName,
    cityCode: body.cityCode !== undefined ? body.cityCode : existing.cityCode,
    cityName: body.cityName !== undefined ? body.cityName : existing.cityName,
    districtCode:
      body.districtCode !== undefined ? body.districtCode : existing.districtCode,
    districtName:
      body.districtName !== undefined ? body.districtName : existing.districtName,
    courierName:
      body.courierName !== undefined ? body.courierName : existing.courierName,
    serviceName:
      body.serviceName !== undefined ? body.serviceName : existing.serviceName,
    weightMinGram:
      body.weightMinGram !== undefined
        ? body.weightMinGram
        : existing.weightMinGram,
    weightMaxGram:
      body.weightMaxGram !== undefined
        ? body.weightMaxGram
        : existing.weightMaxGram,
    shippingFee:
      body.shippingFee !== undefined ? body.shippingFee : existing.shippingFee,
    isActive: body.isActive !== undefined ? body.isActive : existing.isActive,
  };

  const parsed = parseLocalShippingRateInput(mergedCandidate);
  if (!parsed.ok) {
    throw new LocalShippingRateError(parsed.statusCode, parsed.code, parsed.error);
  }
  return { ...parsed.value, id: rateId };
}

interface LockStateSnapshot {
  districtCode: string;
  ref: LocalRateDocRefLike;
  prevRevision: number;
}

async function readDistrictLocksInSortedOrder(
  tx: LocalRateTxLike,
  lockCol: LocalRateCollectionRefLike,
  districtCodes: Array<string | null | undefined>
): Promise<LockStateSnapshot[]> {
  const sortedUnique = Array.from(
    new Set(
      districtCodes.filter(
        (code): code is string =>
          typeof code === 'string' && /^\d{2}\.\d{2}\.\d{2}$/.test(code)
      )
    )
  ).sort();

  const states: LockStateSnapshot[] = [];
  // Sequential sorted lock reads guarantee consistent lock acquisition order
  // across multi-district moves and ensure all reads finish before any write.
  for (const districtCode of sortedUnique) {
    const ref = lockCol.doc(districtCode);
    const snap = await tx.get(ref);
    const prevRevRaw = snap.exists ? snap.data()?.revision : 0;
    const prevRevision =
      typeof prevRevRaw === 'number' && Number.isFinite(prevRevRaw)
        ? prevRevRaw
        : 0;
    states.push({ districtCode, ref, prevRevision });
  }
  return states;
}

export class FirestoreLocalShippingRateRepository
  implements LocalShippingRateRepository
{
  private readonly storeRef: LocalRateStoreRefLike;
  private readonly runTransaction?: LocalRateRunTransactionFn;
  private fallbackMutationQueue: Promise<unknown> = Promise.resolve();

  constructor(
    storeRef: LocalRateStoreRefLike,
    runTransaction?: LocalRateRunTransactionFn
  ) {
    this.storeRef = storeRef;
    this.runTransaction = runTransaction;
  }

  private get col(): LocalRateCollectionRefLike {
    return this.storeRef.collection(LOCAL_SHIPPING_RATES_COLLECTION);
  }

  private get lockCol(): LocalRateCollectionRefLike {
    return this.storeRef.collection(LOCAL_SHIPPING_RATE_LOCKS_COLLECTION);
  }

  private withFallbackMutationQueue<T>(task: () => Promise<T>): Promise<T> {
    const run = this.fallbackMutationQueue.catch(() => undefined).then(task);
    this.fallbackMutationQueue = run.then(
      () => undefined,
      () => undefined
    );
    return run;
  }

  async listAllRates(): Promise<LocalShippingRate[]> {
    const snap = await this.col.get();
    const parsedRates: LocalShippingRate[] = [];
    for (const docSnap of snap.docs) {
      const parsed = parseStoredLocalShippingRateDocument(
        docSnap.id,
        docSnap.data()
      );
      if (parsed.ok) {
        parsedRates.push(parsed.rate);
      }
    }
    return deduplicateAndSortLocalRates(parsedRates);
  }

  async listActiveRatesByDistrict(
    districtCode: string
  ): Promise<LocalShippingRate[]> {
    const cleanDistrict = districtCode.trim();
    if (!/^\d{2}\.\d{2}\.\d{2}$/.test(cleanDistrict)) {
      return [];
    }

    const snap = await this.col
      .where('districtCode', '==', cleanDistrict)
      .where('isActive', '==', true)
      .get();

    const parsedRates: LocalShippingRate[] = [];
    for (const docSnap of snap.docs) {
      const parsed = parseStoredLocalShippingRateDocument(
        docSnap.id,
        docSnap.data()
      );
      if (
        parsed.ok &&
        parsed.rate.isActive &&
        parsed.rate.districtCode === cleanDistrict
      ) {
        parsedRates.push(parsed.rate);
      }
    }
    return deduplicateAndSortLocalRates(parsedRates);
  }

  async getRateById(rateId: string): Promise<LocalShippingRate | null> {
    if (!isValidLocalRateId(rateId)) return null;
    const snap = await this.col.doc(rateId.trim()).get();
    if (!snap.exists) return null;
    const parsed = parseStoredLocalShippingRateDocument(snap.id, snap.data());
    return parsed.ok ? parsed.rate : null;
  }

  async saveRate(input: LocalShippingRateInput): Promise<LocalShippingRate> {
    const rateId =
      input.id && isValidLocalRateId(input.id)
        ? input.id.trim()
        : `lrate_${crypto.randomBytes(8).toString('hex')}`;

    const buildDocPayload = (updatedAt: string): LocalShippingRate => ({
      id: rateId,
      provinceCode: input.provinceCode,
      provinceName: input.provinceName,
      cityCode: input.cityCode,
      cityName: input.cityName,
      districtCode: input.districtCode,
      districtName: input.districtName,
      courierName: input.courierName,
      serviceName: input.serviceName,
      weightMinGram: input.weightMinGram,
      weightMaxGram: input.weightMaxGram,
      shippingFee: input.shippingFee,
      isActive: input.isActive,
      updatedAt,
    });

    if (this.runTransaction) {
      return this.runTransaction(async (tx) => {
        const targetRateRef = this.col.doc(rateId);
        // Read target doc first so upserts that move an existing ID across districts
        // acquire deterministic locks on both origin and destination districts.
        const existingTargetSnap = await tx.get(targetRateRef);
        const existingDistrict = existingTargetSnap.exists
          ? extractValidDistrictCode(existingTargetSnap.data())
          : null;

        const lockStates = await readDistrictLocksInSortedOrder(
          tx,
          this.lockCol,
          [existingDistrict, input.districtCode]
        );
        const existingForDistrict = await tx.get(
          this.col.where('districtCode', '==', input.districtCode)
        );

        const existingRates: LocalShippingRate[] = [];
        for (const docSnap of existingForDistrict.docs) {
          const parsed = parseStoredLocalShippingRateDocument(
            docSnap.id,
            docSnap.data()
          );
          if (parsed.ok) existingRates.push(parsed.rate);
        }

        assertNoDuplicateOrOverlappingLocalRate(input, existingRates, rateId);

        const nowIso = new Date().toISOString();
        const docPayload = buildDocPayload(nowIso);

        tx.set(targetRateRef, { ...docPayload } as Record<string, unknown>, {
          merge: false,
        });
        for (const lockState of lockStates) {
          tx.set(
            lockState.ref,
            {
              districtCode: lockState.districtCode,
              lastRateId: rateId,
              revision: lockState.prevRevision + 1,
              updatedAt: nowIso,
            },
            { merge: true }
          );
        }
        return docPayload;
      });
    }

    // Fallback serialization when repository is instantiated without runTransaction
    return this.withFallbackMutationQueue(async () => {
      const existingForDistrict = await this.col
        .where('districtCode', '==', input.districtCode)
        .get();
      const existingRates: LocalShippingRate[] = [];
      for (const docSnap of existingForDistrict.docs) {
        const parsed = parseStoredLocalShippingRateDocument(
          docSnap.id,
          docSnap.data()
        );
        if (parsed.ok) existingRates.push(parsed.rate);
      }

      assertNoDuplicateOrOverlappingLocalRate(input, existingRates, rateId);

      const docPayload = buildDocPayload(new Date().toISOString());
      await this.col.doc(rateId).set(
        { ...docPayload } as Record<string, unknown>,
        { merge: false }
      );
      return docPayload;
    });
  }

  async patchRate(rateId: string, rawBody: unknown): Promise<LocalShippingRate> {
    if (!isValidLocalRateId(rateId)) {
      throw new LocalShippingRateError(
        400,
        'INVALID_RATE_ID',
        'ID tarif lokal tidak valid.'
      );
    }
    if (!rawBody || typeof rawBody !== 'object' || Array.isArray(rawBody)) {
      throw new LocalShippingRateError(
        400,
        'INVALID_LOCAL_RATE_PAYLOAD',
        'Payload pembaruan tarif lokal harus berupa objek JSON yang valid.'
      );
    }

    const cleanRateId = rateId.trim();

    if (this.runTransaction) {
      return this.runTransaction(async (tx) => {
        const targetRateRef = this.col.doc(cleanRateId);
        const targetRateSnap = await tx.get(targetRateRef);
        if (!targetRateSnap.exists) {
          throw new LocalShippingRateError(
            404,
            'LOCAL_RATE_NOT_FOUND',
            'Tarif pengiriman lokal tidak ditemukan.'
          );
        }

        const parsedExisting = parseStoredLocalShippingRateDocument(
          targetRateSnap.id,
          targetRateSnap.data()
        );
        if (!parsedExisting.ok) {
          throw new LocalShippingRateError(
            404,
            'LOCAL_RATE_NOT_FOUND',
            'Tarif pengiriman lokal tidak ditemukan.'
          );
        }

        const existing = parsedExisting.rate;
        const validatedInput = mergeAndValidatePatchInput(
          cleanRateId,
          existing,
          rawBody
        );

        const lockStates = await readDistrictLocksInSortedOrder(
          tx,
          this.lockCol,
          [existing.districtCode, validatedInput.districtCode]
        );
        const existingForTargetDistrict = await tx.get(
          this.col.where('districtCode', '==', validatedInput.districtCode)
        );

        const existingRates: LocalShippingRate[] = [];
        for (const docSnap of existingForTargetDistrict.docs) {
          const parsed = parseStoredLocalShippingRateDocument(
            docSnap.id,
            docSnap.data()
          );
          if (parsed.ok) existingRates.push(parsed.rate);
        }

        assertNoDuplicateOrOverlappingLocalRate(
          validatedInput,
          existingRates,
          cleanRateId
        );

        const nowIso = new Date().toISOString();
        const docPayload: LocalShippingRate = {
          id: cleanRateId,
          provinceCode: validatedInput.provinceCode,
          provinceName: validatedInput.provinceName,
          cityCode: validatedInput.cityCode,
          cityName: validatedInput.cityName,
          districtCode: validatedInput.districtCode,
          districtName: validatedInput.districtName,
          courierName: validatedInput.courierName,
          serviceName: validatedInput.serviceName,
          weightMinGram: validatedInput.weightMinGram,
          weightMaxGram: validatedInput.weightMaxGram,
          shippingFee: validatedInput.shippingFee,
          isActive: validatedInput.isActive,
          updatedAt: nowIso,
        };

        tx.set(targetRateRef, { ...docPayload } as Record<string, unknown>, {
          merge: false,
        });
        for (const lockState of lockStates) {
          tx.set(
            lockState.ref,
            {
              districtCode: lockState.districtCode,
              lastRateId: cleanRateId,
              revision: lockState.prevRevision + 1,
              updatedAt: nowIso,
            },
            { merge: true }
          );
        }
        return docPayload;
      });
    }

    return this.withFallbackMutationQueue(async () => {
      const targetRateRef = this.col.doc(cleanRateId);
      const targetRateSnap = await targetRateRef.get();
      if (!targetRateSnap.exists) {
        throw new LocalShippingRateError(
          404,
          'LOCAL_RATE_NOT_FOUND',
          'Tarif pengiriman lokal tidak ditemukan.'
        );
      }

      const parsedExisting = parseStoredLocalShippingRateDocument(
        targetRateSnap.id,
        targetRateSnap.data()
      );
      if (!parsedExisting.ok) {
        throw new LocalShippingRateError(
          404,
          'LOCAL_RATE_NOT_FOUND',
          'Tarif pengiriman lokal tidak ditemukan.'
        );
      }

      const validatedInput = mergeAndValidatePatchInput(
        cleanRateId,
        parsedExisting.rate,
        rawBody
      );

      const existingForTargetDistrict = await this.col
        .where('districtCode', '==', validatedInput.districtCode)
        .get();
      const existingRates: LocalShippingRate[] = [];
      for (const docSnap of existingForTargetDistrict.docs) {
        const parsed = parseStoredLocalShippingRateDocument(
          docSnap.id,
          docSnap.data()
        );
        if (parsed.ok) existingRates.push(parsed.rate);
      }

      assertNoDuplicateOrOverlappingLocalRate(
        validatedInput,
        existingRates,
        cleanRateId
      );

      const docPayload: LocalShippingRate = {
        id: cleanRateId,
        provinceCode: validatedInput.provinceCode,
        provinceName: validatedInput.provinceName,
        cityCode: validatedInput.cityCode,
        cityName: validatedInput.cityName,
        districtCode: validatedInput.districtCode,
        districtName: validatedInput.districtName,
        courierName: validatedInput.courierName,
        serviceName: validatedInput.serviceName,
        weightMinGram: validatedInput.weightMinGram,
        weightMaxGram: validatedInput.weightMaxGram,
        shippingFee: validatedInput.shippingFee,
        isActive: validatedInput.isActive,
        updatedAt: new Date().toISOString(),
      };
      await targetRateRef.set(
        { ...docPayload } as Record<string, unknown>,
        { merge: false }
      );
      return docPayload;
    });
  }

  async deleteRate(rateId: string): Promise<boolean> {
    if (!isValidLocalRateId(rateId)) return false;
    const cleanRateId = rateId.trim();

    if (this.runTransaction) {
      return this.runTransaction(async (tx) => {
        const ref = this.col.doc(cleanRateId);
        const snap = await tx.get(ref);
        if (!snap.exists) return false;

        const existingDistrict = extractValidDistrictCode(snap.data());
        const lockStates = await readDistrictLocksInSortedOrder(
          tx,
          this.lockCol,
          [existingDistrict]
        );

        tx.delete(ref);
        const nowIso = new Date().toISOString();
        for (const lockState of lockStates) {
          tx.set(
            lockState.ref,
            {
              districtCode: lockState.districtCode,
              lastRateId: cleanRateId,
              revision: lockState.prevRevision + 1,
              updatedAt: nowIso,
            },
            { merge: true }
          );
        }
        return true;
      });
    }

    return this.withFallbackMutationQueue(async () => {
      const ref = this.col.doc(cleanRateId);
      const snap = await ref.get();
      if (!snap.exists) return false;
      await ref.delete();
      return true;
    });
  }
}

export class InMemoryLocalShippingRateRepository
  implements LocalShippingRateRepository
{
  private readonly records = new Map<string, LocalShippingRate>();

  // Starts empty by default; never seeds fake or unverified tariffs.
  constructor(initialRates: LocalShippingRate[] = []) {
    for (const item of initialRates) {
      const parsed = parseStoredLocalShippingRateDocument(item.id, item);
      if (parsed.ok) {
        this.records.set(parsed.rate.id, parsed.rate);
      }
    }
  }

  async listAllRates(): Promise<LocalShippingRate[]> {
    return deduplicateAndSortLocalRates(Array.from(this.records.values()));
  }

  async listActiveRatesByDistrict(
    districtCode: string
  ): Promise<LocalShippingRate[]> {
    const cleanDistrict = districtCode.trim();
    if (!/^\d{2}\.\d{2}\.\d{2}$/.test(cleanDistrict)) {
      return [];
    }
    const matching = Array.from(this.records.values()).filter(
      (r) => r.isActive && r.districtCode === cleanDistrict
    );
    return deduplicateAndSortLocalRates(matching);
  }

  async getRateById(rateId: string): Promise<LocalShippingRate | null> {
    if (!isValidLocalRateId(rateId)) return null;
    return this.records.get(rateId.trim()) ?? null;
  }

  async saveRate(input: LocalShippingRateInput): Promise<LocalShippingRate> {
    const rateId =
      input.id && isValidLocalRateId(input.id)
        ? input.id.trim()
        : `lrate_${crypto.randomBytes(6).toString('hex')}`;
    const allExisting = Array.from(this.records.values());
    assertNoDuplicateOrOverlappingLocalRate(input, allExisting, rateId);

    const saved: LocalShippingRate = {
      id: rateId,
      provinceCode: input.provinceCode,
      provinceName: input.provinceName,
      cityCode: input.cityCode,
      cityName: input.cityName,
      districtCode: input.districtCode,
      districtName: input.districtName,
      courierName: input.courierName,
      serviceName: input.serviceName,
      weightMinGram: input.weightMinGram,
      weightMaxGram: input.weightMaxGram,
      shippingFee: input.shippingFee,
      isActive: input.isActive,
      updatedAt: new Date().toISOString(),
    };
    this.records.set(rateId, saved);
    return saved;
  }

  async patchRate(rateId: string, rawBody: unknown): Promise<LocalShippingRate> {
    if (!isValidLocalRateId(rateId)) {
      throw new LocalShippingRateError(
        400,
        'INVALID_RATE_ID',
        'ID tarif lokal tidak valid.'
      );
    }
    const cleanRateId = rateId.trim();
    const existing = this.records.get(cleanRateId);
    if (!existing) {
      throw new LocalShippingRateError(
        404,
        'LOCAL_RATE_NOT_FOUND',
        'Tarif pengiriman lokal tidak ditemukan.'
      );
    }
    const validated = mergeAndValidatePatchInput(cleanRateId, existing, rawBody);
    return this.saveRate(validated);
  }

  async deleteRate(rateId: string): Promise<boolean> {
    if (!isValidLocalRateId(rateId)) return false;
    return this.records.delete(rateId.trim());
  }
}

export function parseLocalShippingRateQuoteRequest(
  rawBody: unknown
):
  | { ok: true; value: LocalShippingRateQuoteRequest }
  | { ok: false; statusCode: number; error: string } {
  if (!rawBody || typeof rawBody !== 'object' || Array.isArray(rawBody)) {
    return {
      ok: false,
      statusCode: 400,
      error: 'Payload permintaan cek tarif lokal harus berupa objek JSON yang valid.',
    };
  }

  const body = rawBody as Record<string, unknown>;
  const districtCode =
    typeof body.districtCode === 'string' ? body.districtCode.trim() : '';
  if (!/^\d{2}\.\d{2}\.\d{2}$/.test(districtCode)) {
    return {
      ok: false,
      statusCode: 400,
      error: 'Kode kecamatan tujuan (districtCode) harus mengikuti format XX.YY.ZZ.',
    };
  }

  const requestedItems = Array.isArray(body.items) ? body.items : [];
  if (requestedItems.length === 0 || requestedItems.length > 50) {
    return {
      ok: false,
      statusCode: 400,
      error: 'Daftar barang untuk cek tarif lokal tidak boleh kosong (maksimal 50 item).',
    };
  }

  const qtyByProduct = new Map<string, number>();
  for (const entry of requestedItems) {
    if (
      !entry ||
      typeof entry !== 'object' ||
      typeof (entry as { productId?: unknown }).productId !== 'string' ||
      !/^[a-zA-Z0-9_-]{1,128}$/.test(
        (entry as { productId: string }).productId
      )
    ) {
      return {
        ok: false,
        statusCode: 400,
        error: 'Format ID produk pada permintaan cek tarif lokal tidak valid.',
      };
    }

    const productId = (entry as { productId: string }).productId;
    const qty = Number((entry as { quantity?: unknown }).quantity);
    if (!Number.isInteger(qty) || qty < 1 || qty > 99) {
      return {
        ok: false,
        statusCode: 400,
        error: 'Jumlah setiap barang harus berupa bilangan bulat antara 1 dan 99.',
      };
    }

    const merged = (qtyByProduct.get(productId) ?? 0) + qty;
    if (merged > 99) {
      return {
        ok: false,
        statusCode: 400,
        error: 'Jumlah maksimal per produk adalah 99 per pesanan.',
      };
    }
    qtyByProduct.set(productId, merged);
  }

  return {
    ok: true,
    value: {
      districtCode,
      items: Array.from(qtyByProduct.entries()).map(([productId, quantity]) => ({
        productId,
        quantity,
      })),
    },
  };
}

export interface LocalQuoteProductSnapshot {
  id: string;
  exists: boolean;
  available: boolean;
  name: string;
  price: number;
  stock: number;
  unit: string;
  weightGrams?: number;
}

export async function quoteLocalShippingRatesForStore(params: {
  repository: LocalShippingRateRepository;
  fetchProductsByIds: (productIds: string[]) => Promise<LocalQuoteProductSnapshot[]>;
  rawBody: unknown;
}): Promise<{
  statusCode: number;
  body: LocalShippingRateQuoteResponse | { error: string };
}> {
  const parsed = parseLocalShippingRateQuoteRequest(params.rawBody);
  if (!parsed.ok) {
    return { statusCode: parsed.statusCode, body: { error: parsed.error } };
  }

  const qtyByProduct = new Map(
    parsed.value.items.map((item) => [item.productId, item.quantity])
  );
  const productSnaps = await params.fetchProductsByIds(
    Array.from(qtyByProduct.keys())
  );
  const snapMap = new Map(productSnaps.map((s) => [s.id, s]));

  let itemsSubtotal = 0;
  let totalWeightGrams = 0;
  let hasUnweighedItems = false;

  for (const [productId, requestedQty] of qtyByProduct.entries()) {
    const snap = snapMap.get(productId);
    if (!snap || !snap.exists || !snap.available) {
      return {
        statusCode: 404,
        body: {
          error: `Produk tidak ditemukan atau tidak tersedia (${productId}).`,
        },
      };
    }
    if (snap.stock < requestedQty) {
      return {
        statusCode: 409,
        body: {
          error:
            snap.stock === 0
              ? `Stok "${snap.name}" saat ini habis.`
              : `Stok "${snap.name}" tersisa ${snap.stock} ${snap.unit}. Kurangi jumlah pesanan.`,
        },
      };
    }

    itemsSubtotal += snap.price * requestedQty;
    if (
      typeof snap.weightGrams === 'number' &&
      Number.isFinite(snap.weightGrams) &&
      snap.weightGrams > 0
    ) {
      totalWeightGrams += snap.weightGrams * requestedQty;
    } else {
      hasUnweighedItems = true;
    }
  }

  const roundedSubtotal = Math.round(itemsSubtotal * 100) / 100;
  const roundedWeightGrams = Math.round(totalWeightGrams * 100) / 100;
  const normalizedWeightGrams =
    !hasUnweighedItems && roundedWeightGrams > 0
      ? Math.max(1, Math.ceil(roundedWeightGrams))
      : null;

  if (hasUnweighedItems || normalizedWeightGrams === null) {
    return {
      statusCode: 200,
      body: {
        available: false,
        districtCode: parsed.value.districtCode,
        totalWeightGrams: roundedWeightGrams,
        normalizedWeightGrams,
        hasUnweighedItems,
        itemsSubtotal: roundedSubtotal,
        rates: [],
        reason:
          'Sebagian atau seluruh produk belum memiliki data berat valid untuk perhitungan tarif lokal.',
      },
    };
  }

  const activeDistrictRates = await params.repository.listActiveRatesByDistrict(
    parsed.value.districtCode
  );
  const matchedRates = matchActiveLocalRatesForDistrictAndWeight(
    activeDistrictRates,
    parsed.value.districtCode,
    normalizedWeightGrams
  );

  if (matchedRates.length === 0) {
    return {
      statusCode: 200,
      body: {
        available: false,
        districtCode: parsed.value.districtCode,
        totalWeightGrams: roundedWeightGrams,
        normalizedWeightGrams,
        hasUnweighedItems: false,
        itemsSubtotal: roundedSubtotal,
        rates: [],
        reason:
          'Tarif pengiriman lokal belum tersedia untuk kecamatan dan berat paket ini.',
      },
    };
  }

  return {
    statusCode: 200,
    body: {
      available: true,
      districtCode: parsed.value.districtCode,
      totalWeightGrams: roundedWeightGrams,
      normalizedWeightGrams,
      hasUnweighedItems: false,
      itemsSubtotal: roundedSubtotal,
      rates: matchedRates,
    },
  };
}

export function createLocalShippingRateQuoteHandler(deps: {
  resolveDependencies: (
    req: Request,
    res: Response
  ) => Promise<{
    repository: LocalShippingRateRepository;
    fetchProductsByIds: (
      productIds: string[]
    ) => Promise<LocalQuoteProductSnapshot[]>;
  } | null>;
  checkRateLimit?: (req: Request) => boolean;
  onError?: (res: Response, err: unknown) => Response;
}) {
  return async (req: Request, res: Response) => {
    res.setHeader('Cache-Control', 'no-store');
    if (deps.checkRateLimit && !deps.checkRateLimit(req)) {
      return res.status(429).json({
        error:
          'Terlalu banyak permintaan cek tarif pengiriman lokal. Tunggu beberapa saat lalu coba lagi.',
      });
    }

    try {
      const resolved = await deps.resolveDependencies(req, res);
      if (!resolved) return;

      const result = await quoteLocalShippingRatesForStore({
        repository: resolved.repository,
        fetchProductsByIds: resolved.fetchProductsByIds,
        rawBody: req.body,
      });

      return res.status(result.statusCode).json(result.body);
    } catch (err) {
      if (deps.onError) {
        return deps.onError(res, err);
      }
      return res.status(500).json({
        code: 'LOCAL_SHIPPING_QUOTE_ERROR',
        error: 'Gagal menghitung tarif pengiriman lokal.',
      });
    }
  };
}

export function createOwnerLocalShippingRateHandlers(deps: {
  resolveOwnerRepository: (
    req: Request,
    res: Response
  ) => Promise<LocalShippingRateRepository | null>;
  onError?: (res: Response, err: unknown) => Response;
}) {
  const handleError = (res: Response, err: unknown) => {
    if (err instanceof LocalShippingRateError) {
      return res.status(err.statusCode).json({
        code: err.code,
        error: err.message,
      });
    }
    if (deps.onError) {
      return deps.onError(res, err);
    }
    return res.status(500).json({
      code: 'LOCAL_SHIPPING_REPO_ERROR',
      error: 'Gagal memproses data tarif pengiriman lokal.',
    });
  };

  return {
    list: async (req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-store');
      try {
        const repository = await deps.resolveOwnerRepository(req, res);
        if (!repository) return;

        const districtParam =
          typeof req.query.districtCode === 'string'
            ? req.query.districtCode.trim()
            : '';
        if (districtParam && !/^\d{2}\.\d{2}\.\d{2}$/.test(districtParam)) {
          return res.status(400).json({
            code: 'INVALID_DISTRICT_CODE',
            error:
              'Filter kode kecamatan (districtCode) harus mengikuti format XX.YY.ZZ.',
          });
        }

        const allRates = await repository.listAllRates();
        const filtered = districtParam
          ? allRates.filter((rate) => rate.districtCode === districtParam)
          : allRates;

        return res.status(200).json({
          rates: filtered,
          count: filtered.length,
        });
      } catch (err) {
        return handleError(res, err);
      }
    },

    create: async (req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-store');
      try {
        const repository = await deps.resolveOwnerRepository(req, res);
        if (!repository) return;

        const parsed = parseLocalShippingRateInput(req.body);
        if (!parsed.ok) {
          return res.status(parsed.statusCode).json({
            code: parsed.code,
            error: parsed.error,
          });
        }

        const saved = await repository.saveRate(parsed.value);
        return res.status(201).json({ rate: saved });
      } catch (err) {
        return handleError(res, err);
      }
    },

    update: async (req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-store');
      try {
        const repository = await deps.resolveOwnerRepository(req, res);
        if (!repository) return;

        const rateId = String(req.params.rateId || '').trim();
        if (!isValidLocalRateId(rateId)) {
          return res.status(400).json({
            code: 'INVALID_RATE_ID',
            error: 'ID tarif lokal tidak valid.',
          });
        }

        const saved = await repository.patchRate(rateId, req.body);
        return res.status(200).json({ rate: saved });
      } catch (err) {
        return handleError(res, err);
      }
    },

    remove: async (req: Request, res: Response) => {
      res.setHeader('Cache-Control', 'no-store');
      try {
        const repository = await deps.resolveOwnerRepository(req, res);
        if (!repository) return;

        const rateId = String(req.params.rateId || '').trim();
        if (!isValidLocalRateId(rateId)) {
          return res.status(400).json({
            code: 'INVALID_RATE_ID',
            error: 'ID tarif lokal tidak valid.',
          });
        }

        const deleted = await repository.deleteRate(rateId);
        if (!deleted) {
          return res.status(404).json({
            code: 'LOCAL_RATE_NOT_FOUND',
            error: 'Tarif pengiriman lokal tidak ditemukan.',
          });
        }

        return res.status(200).json({ deleted: true, id: rateId });
      } catch (err) {
        return handleError(res, err);
      }
    },
  };
}
