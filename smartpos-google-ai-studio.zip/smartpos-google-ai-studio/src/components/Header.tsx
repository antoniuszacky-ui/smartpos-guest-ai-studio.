import { ShoppingBag } from 'lucide-react';

export type AppView = 'home' | 'catalog' | 'status';

interface HeaderProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
  cartCount: number;
  onOpenCart: () => void;
}

export function Header({
  activeView,
  onNavigate,
  cartCount,
  onOpenCart,
}: HeaderProps) {
  const navItems: Array<{ id: AppView; label: string }> = [
    { id: 'home', label: 'Beranda' },
    { id: 'catalog', label: 'Katalog' },
    { id: 'status', label: 'Status Pesanan' },
  ];

  return (
    <header className="sticky top-0 z-30 h-14 md:h-16 bg-white/95 backdrop-blur-md border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="text-left text-lg md:text-xl font-bold tracking-tight text-blue-700 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600 rounded"
        >
          SmartPOS Guest
        </button>

        <nav
          aria-label="Navigasi utama"
          className="hidden md:flex items-center gap-7 text-sm font-medium"
        >
          {navItems.map((item) => {
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onNavigate(item.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-blue-600 ${
                  isActive
                    ? 'text-blue-700 border-blue-600 font-semibold'
                    : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onOpenCart}
            aria-label={`Buka keranjang belanja, ${cartCount} barang`}
            className="inline-flex items-center justify-center gap-2 min-h-[40px] md:min-h-[42px] px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white text-sm font-semibold transition-all whitespace-nowrap shrink-0 shadow-sm shadow-blue-600/15 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <ShoppingBag className="w-4 h-4 shrink-0" />
            <span>Keranjang</span>
            {cartCount > 0 && (
              <span className="font-mono tabular-nums text-xs bg-white/20 px-1.5 py-0.5 rounded-md">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
