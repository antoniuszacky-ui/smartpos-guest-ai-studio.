import {
  FieldValue,
  type CollectionReference,
  type DocumentData,
  type DocumentReference,
  type DocumentSnapshot,
  type Query,
  type QuerySnapshot,
} from 'firebase-admin/firestore';

export class OwnerOrderActionError extends Error {
  statusCode: number;
  code: string;

  constructor(statusCode: number, code: string, message: string) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
  }
}

export interface TxLike {
  get(ref: DocumentReference): Promise<DocumentSnapshot>;
  get(query: Query): Promise<QuerySnapshot>;
  getAll(...refs: DocumentReference[]): Promise<DocumentSnapshot[]>;
  update(ref: DocumentReference, data: Record<string, unknown>): unknown;
  delete(ref: DocumentReference): unknown;
}

export interface StoreRefLike {
  collection(name: string): CollectionReference;
}

export function normalizeOrderStatusUpper(status: unknown): string {
  return String(status ?? 'PENDING').trim().toUpperCase();
}

export function isCancelledOrderStatus(status: unknown): boolean {
  const upper = normalizeOrderStatusUpper(status);
  return upper === 'CANCELLED' || upper === 'REJECTED' || upper === 'BATAL';
}

export function isOrderLinkedToCashierTransaction(
  orderData: DocumentData,
  hasExternalSaleRef = false
): { linked: boolean; reason?: string } {
  const upperStatus = normalizeOrderStatusUpper(orderData.status);

  if (hasExternalSaleRef) {
    return {
      linked: true,
      reason:
        'Pesanan sudah terhubung dengan dokumen transaksi/penjualan Kasir dan tidak dapat dihapus demi menjaga integritas riwayat penjualan serta laporan keuangan.',
    };
  }

  if (upperStatus === 'COMPLETED') {
    return {
      linked: true,
      reason:
        'Pesanan berstatus selesai (COMPLETED) dan sudah menjadi transaksi Kasir, sehingga tidak dapat dihapus.',
    };
  }

  const linkKeys = [
    'transactionId',
    'saleId',
    'kasirTransactionId',
    'cashierTransactionId',
    'receiptNumber',
    'invoiceNumber',
  ] as const;

  for (const key of linkKeys) {
    const val = orderData[key];
    if (typeof val === 'string' && val.trim().length > 0) {
      return {
        linked: true,
        reason: `Pesanan sudah terhubung ke transaksi Kasir (${key}: ${val.trim()}) sehingga dilindungi dari penghapusan.`,
      };
    }
  }

  if (orderData.convertedToSale === true || orderData.isPaid === true) {
    return {
      linked: true,
      reason:
        'Pesanan sudah dikonversi menjadi transaksi penjualan Kasir sehingga tidak dapat dihapus.',
    };
  }

  const paymentStatus = String(orderData.paymentStatus ?? '')
    .trim()
    .toUpperCase();
  if (paymentStatus === 'PAID' || paymentStatus === 'SETTLED') {
    return {
      linked: true,
      reason:
        'Pesanan sudah tercatat lunas pada transaksi Kasir sehingga tidak dapat dihapus.',
    };
  }

  return { linked: false };
}

async function checkExternalSalesOrTransactionsLink(
  tx: TxLike,
  storeRef: StoreRefLike,
  orderId: string,
  orderNumber: string
): Promise<boolean> {
  const queries: Query[] = [
    storeRef.collection('sales').where('guestOrderId', '==', orderId).limit(1),
    storeRef
      .collection('transactions')
      .where('guestOrderId', '==', orderId)
      .limit(1),
  ];

  if (orderNumber) {
    queries.push(
      storeRef
        .collection('sales')
        .where('orderNumber', '==', orderNumber)
        .limit(1),
      storeRef
        .collection('transactions')
        .where('orderNumber', '==', orderNumber)
        .limit(1)
    );
  }

  const snapshots = await Promise.all(queries.map((q) => tx.get(q)));
  return snapshots.some((snap) => !snap.empty);
}

async function restoreStockOnceInTransaction(
  tx: TxLike,
  storeRef: StoreRefLike,
  orderData: DocumentData
): Promise<number> {
  const stockDeducted = Boolean(orderData.stockDeducted);
  const stockRestored = Boolean(orderData.stockRestored);

  // If stock was never deducted or was already restored earlier, never touch product stock.
  if (!stockDeducted || stockRestored) {
    return 0;
  }

  const rawItems = Array.isArray(orderData.items) ? orderData.items : [];
  const qtyByProduct = new Map<string, number>();

  for (const item of rawItems) {
    const productId = String(item?.productId ?? '').trim();
    const qty = Number(item?.quantity ?? 0);
    if (!productId || !Number.isFinite(qty) || qty <= 0) continue;
    qtyByProduct.set(productId, (qtyByProduct.get(productId) ?? 0) + qty);
  }

  if (qtyByProduct.size === 0) {
    return 0;
  }

  const productRefs = Array.from(qtyByProduct.keys()).map((pid) =>
    storeRef.collection('products').doc(pid)
  );
  const productSnaps = await tx.getAll(...productRefs);

  let updatedCount = 0;
  for (const prodSnap of productSnaps) {
    if (!prodSnap.exists) continue;
    const prodData = prodSnap.data();
    if (!prodData) continue;

    const restoreQty = qtyByProduct.get(prodSnap.id) ?? 0;
    if (restoreQty <= 0) continue;

    const currentStock = Number(prodData.stock ?? 0);
    const safeCurrentStock =
      Number.isFinite(currentStock) && currentStock >= 0 ? currentStock : 0;

    tx.update(prodSnap.ref, {
      stock: safeCurrentStock + restoreQty,
      updatedAt: FieldValue.serverTimestamp(),
    });
    updatedCount += 1;
  }

  return updatedCount;
}

export async function cancelGuestOrderInTransaction(
  tx: TxLike,
  storeRef: StoreRefLike,
  orderId: string,
  reason?: string
): Promise<{
  orderId: string;
  updatedData: DocumentData;
  alreadyCancelled: boolean;
  restoredProductCount: number;
}> {
  const orderRef = storeRef.collection('guest_orders').doc(orderId);
  const orderSnap = await tx.get(orderRef);

  if (!orderSnap.exists) {
    throw new OwnerOrderActionError(
      404,
      'ORDER_NOT_FOUND',
      'Pesanan tamu tidak ditemukan.'
    );
  }

  const orderData = orderSnap.data() || {};
  const orderNumber = String(orderData.orderNumber ?? '').trim();
  const hasExternalSaleRef = await checkExternalSalesOrTransactionsLink(
    tx,
    storeRef,
    orderId,
    orderNumber
  );
  const linkCheck = isOrderLinkedToCashierTransaction(
    orderData,
    hasExternalSaleRef
  );

  if (linkCheck.linked) {
    throw new OwnerOrderActionError(
      409,
      'ORDER_LINKED_TO_TRANSACTION',
      linkCheck.reason ||
        'Pesanan sudah menjadi transaksi Kasir dan tidak dapat dibatalkan melalui modul ini.'
    );
  }

  const alreadyCancelled = isCancelledOrderStatus(orderData.status);
  const needsStockRestore =
    Boolean(orderData.stockDeducted) && !Boolean(orderData.stockRestored);

  if (alreadyCancelled && !needsStockRestore) {
    return {
      orderId: orderSnap.id,
      updatedData: orderData,
      alreadyCancelled: true,
      restoredProductCount: 0,
    };
  }

  // All Firestore reads happen before writes inside restoreStockOnceInTransaction
  const restoredProductCount = await restoreStockOnceInTransaction(
    tx,
    storeRef,
    orderData
  );

  const nowIso = new Date().toISOString();
  const cleanReason =
    typeof reason === 'string' && reason.trim()
      ? reason.trim().slice(0, 200)
      : typeof orderData.rejectionReason === 'string'
      ? orderData.rejectionReason
      : 'Dibatalkan oleh Owner';

  const patch: Record<string, unknown> = {
    status: alreadyCancelled ? normalizeOrderStatusUpper(orderData.status) : 'CANCELLED',
    rejectionReason: cleanReason,
    updatedAt: FieldValue.serverTimestamp(),
  };

  if (Boolean(orderData.stockDeducted) && !Boolean(orderData.stockRestored)) {
    patch.stockRestored = true;
    patch.stockRestoredAt = FieldValue.serverTimestamp();
  }

  tx.update(orderRef, patch);

  return {
    orderId: orderSnap.id,
    updatedData: {
      ...orderData,
      ...patch,
      updatedAt: nowIso,
    },
    alreadyCancelled,
    restoredProductCount,
  };
}

export async function deleteCancelledGuestOrderInTransaction(
  tx: TxLike,
  storeRef: StoreRefLike,
  orderId: string
): Promise<{
  deletedOrderId: string;
  orderNumber: string;
  restoredProductCount: number;
}> {
  const orderRef = storeRef.collection('guest_orders').doc(orderId);
  const orderSnap = await tx.get(orderRef);

  if (!orderSnap.exists) {
    throw new OwnerOrderActionError(
      404,
      'ORDER_NOT_FOUND',
      'Pesanan tamu tidak ditemukan atau sudah dihapus.'
    );
  }

  const orderData = orderSnap.data() || {};
  const orderNumber = String(orderData.orderNumber ?? orderSnap.id).trim();

  // Check relationship with Cashier sales / transactions before allowing deletion
  const hasExternalSaleRef = await checkExternalSalesOrTransactionsLink(
    tx,
    storeRef,
    orderId,
    orderNumber
  );
  const linkCheck = isOrderLinkedToCashierTransaction(
    orderData,
    hasExternalSaleRef
  );

  if (linkCheck.linked) {
    throw new OwnerOrderActionError(
      409,
      'ORDER_LINKED_TO_TRANSACTION',
      linkCheck.reason ||
        'Pesanan sudah terhubung dengan transaksi Kasir sehingga tidak dapat dihapus.'
    );
  }

  if (!isCancelledOrderStatus(orderData.status)) {
    throw new OwnerOrderActionError(
      409,
      'ORDER_NOT_CANCELLED',
      'Hanya pesanan dengan status BATAL (Dibatalkan/Ditolak) yang dapat dihapus secara permanen.'
    );
  }

  // Idempotent safety: if stock had been deducted and wasn't restored yet,
  // restore stock exactly once inside the same transaction before deleting the order.
  // If stockDeducted is false, product stock is never touched.
  const restoredProductCount = await restoreStockOnceInTransaction(
    tx,
    storeRef,
    orderData
  );

  // Delete ONLY this selected guest_orders document.
  // Never touch sales, financial records, audit logs, or product documents' existence.
  tx.delete(orderRef);

  return {
    deletedOrderId: orderSnap.id,
    orderNumber,
    restoredProductCount,
  };
}
