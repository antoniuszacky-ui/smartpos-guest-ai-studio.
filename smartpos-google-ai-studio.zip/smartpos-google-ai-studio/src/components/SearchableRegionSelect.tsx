import {
  AlertTriangle,
  Check,
  ChevronDown,
  Info,
  Loader2,
  Search,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import type { RegionOption } from '../types/pos';

interface SearchableRegionSelectProps {
  id: string;
  label: string;
  placeholder: string;
  searchPlaceholder: string;
  options: RegionOption[];
  value: RegionOption | null;
  disabled?: boolean;
  isLoading?: boolean;
  hasLoaded?: boolean;
  errorMessage?: string | null;
  emptyMessage?: string;
  onSelect: (option: RegionOption) => void;
  onRetry?: () => void;
}

export function SearchableRegionSelect({
  id,
  label,
  placeholder,
  searchPlaceholder,
  options,
  value,
  disabled = false,
  isLoading = false,
  hasLoaded = false,
  errorMessage = null,
  emptyMessage = 'Data wilayah belum tersedia untuk pilihan ini.',
  onSelect,
  onRetry,
}: SearchableRegionSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (disabled || isLoading || errorMessage) {
      setIsOpen(false);
    }
  }, [disabled, isLoading, errorMessage]);

  useEffect(() => {
    setSearchQuery('');
  }, [options]);

  const normalizedQuery = searchQuery.trim().toLowerCase();
  const filteredOptions = normalizedQuery
    ? options.filter(
        (opt) =>
          opt.name.toLowerCase().includes(normalizedQuery) ||
          opt.code.toLowerCase().includes(normalizedQuery)
      )
    : options;

  const isEmptyUpstream =
    !disabled && !isLoading && !errorMessage && hasLoaded && options.length === 0;
  const canOpen = !disabled && !isLoading && !errorMessage && options.length > 0;

  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-xs font-semibold text-slate-700">
        {label} <span className="text-rose-600">*</span>
      </label>

      <button
        id={id}
        type="button"
        disabled={!canOpen}
        aria-haspopup="listbox"
        aria-expanded={isOpen && canOpen}
        onClick={() => {
          if (!canOpen) return;
          setIsOpen((prev) => !prev);
        }}
        className={`w-full min-h-[44px] px-3.5 py-2.5 rounded-xl border text-left text-sm flex items-center justify-between gap-2 transition-colors ${
          disabled
            ? 'border-slate-200 bg-slate-100 text-slate-400 cursor-not-allowed'
            : errorMessage
            ? 'border-amber-300 bg-amber-50/40 text-slate-700'
            : canOpen
            ? 'border-slate-300 bg-white hover:border-blue-400 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600/25 focus:border-blue-600'
            : 'border-slate-200 bg-slate-50 text-slate-500'
        }`}
      >
        <span className="min-w-0 truncate">
          {isLoading ? (
            <span className="inline-flex items-center gap-2 text-blue-700 font-medium">
              <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
              <span>Memuat {label.toLowerCase()}...</span>
            </span>
          ) : value ? (
            <span className="font-medium text-slate-900">{value.name}</span>
          ) : (
            <span className="text-slate-400">{placeholder}</span>
          )}
        </span>

        <div className="flex items-center gap-1.5 shrink-0">
          {value && !isLoading && (
            <span className="text-[11px] font-mono tabular-nums text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
              {value.code}
            </span>
          )}
          <ChevronDown
            className={`w-4 h-4 text-slate-400 transition-transform ${
              isOpen && canOpen ? 'rotate-180' : ''
            }`}
          />
        </div>
      </button>

      {isOpen && canOpen && (
        <div className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="p-2 border-b border-slate-100 bg-slate-50/70">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={searchPlaceholder}
                aria-label={`Cari ${label}`}
                className="w-full min-h-[36px] pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600/20 focus:border-blue-600"
              />
            </div>
          </div>

          {filteredOptions.length === 0 ? (
            <div className="px-3.5 py-3 text-xs text-slate-500 text-center">
              Tidak ada {label.toLowerCase()} yang cocok.
            </div>
          ) : (
            <div
              role="listbox"
              aria-label={`Daftar ${label}`}
              className="max-h-48 overflow-y-auto divide-y divide-slate-100"
            >
              {filteredOptions.map((opt) => {
                const isSelected = value?.code === opt.code;
                return (
                  <button
                    key={opt.code}
                    type="button"
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => {
                      onSelect(opt);
                      setIsOpen(false);
                      setSearchQuery('');
                    }}
                    className={`w-full min-h-[40px] px-3.5 py-2 text-left text-xs flex items-center justify-between gap-2 transition-colors ${
                      isSelected
                        ? 'bg-blue-50 text-blue-900 font-semibold'
                        : 'hover:bg-slate-50 text-slate-800'
                    }`}
                  >
                    <span className="min-w-0 break-words leading-snug">
                      {opt.name}
                    </span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span className="text-[11px] font-mono tabular-nums text-slate-400">
                        {opt.code}
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {errorMessage && (
        <div
          role="status"
          className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start justify-between gap-2"
        >
          <div className="flex items-start gap-2 min-w-0">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
            <span className="leading-snug">{errorMessage}</span>
          </div>
          {onRetry && (
            <button
              type="button"
              onClick={onRetry}
              className="px-2.5 py-1 rounded-lg bg-white border border-amber-300 hover:bg-amber-100 text-[11px] font-semibold text-amber-900 shrink-0 transition-colors"
            >
              Coba lagi
            </button>
          )}
        </div>
      )}

      {isEmptyUpstream && (
        <div
          role="status"
          className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-600 text-xs flex items-start gap-2"
        >
          <Info className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
          <span>{emptyMessage}</span>
        </div>
      )}
    </div>
  );
}
