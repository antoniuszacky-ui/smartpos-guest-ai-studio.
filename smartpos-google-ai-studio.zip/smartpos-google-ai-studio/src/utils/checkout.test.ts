import assert from 'node:assert/strict';
import test from 'node:test';
import type { CartItem, Product } from '../types/pos.ts';
import {
  buildCheckoutIdempotencySignature,
  buildCreateGuestOrderPayload,
  calculateCartWeightSummary,
  formatStructuredDeliveryAddress,
  formatWeightDisplay,
} from './checkout.ts';

function makeProduct(overrides: Partial<Product>): Product {
  return {
    id: 'prod_1',
    sku: 'SKU-1',
    name: 'My Baby Lotion 100ml',
    categoryId: 'bayi',
    categoryName: 'Bayi',
    price: 20000,
    stock: 10,
    unit: 'pcs',
    imageUrl: '',
    description: '',
    isActive: true,
    ...overrides,
  };
}

test('calculateCartWeightSummary computes weight accurately and flags missing/zero weights', () => {
  const weighedItems: CartItem[] = [
    { product: makeProduct({ id: 'p1', name: 'Item A', weightGrams: 200 }), quantity: 2 },
    { product: makeProduct({ id: 'p2', name: 'Item B', weightGrams: 500 }), quantity: 2 },
  ];
  const fullSummary = calculateCartWeightSummary(weighedItems);
  assert.equal(fullSummary.totalWeightGrams, 1400);
  assert.equal(fullSummary.hasUnweighedItems, false);
  assert.equal(fullSummary.allItemsUnweighed, false);
  assert.equal(formatWeightDisplay(fullSummary.totalWeightGrams), '1.400 g (1,4 kg)');

  // Zero or undefined weight must NOT be treated as valid weighed 0g
  const partialItems: CartItem[] = [
    { product: makeProduct({ id: 'p1', name: 'Item A', weightGrams: 300 }), quantity: 1 },
    { product: makeProduct({ id: 'p3', name: 'Item Tanpa Berat' }), quantity: 2 },
    { product: makeProduct({ id: 'p4', name: 'Item Nol', weightGrams: 0 }), quantity: 1 },
  ];
  const partialSummary = calculateCartWeightSummary(partialItems);
  assert.equal(partialSummary.totalWeightGrams, 300);
  assert.equal(partialSummary.hasUnweighedItems, true);
  assert.equal(partialSummary.allItemsUnweighed, false);
  assert.deepEqual(partialSummary.unweighedItemNames, ['Item Tanpa Berat', 'Item Nol']);
  assert.equal(formatWeightDisplay(300), '300 g');

  const allUnweighedSummary = calculateCartWeightSummary([
    { product: makeProduct({ id: 'p5', name: 'Kosong' }), quantity: 1 },
  ]);
  assert.equal(allUnweighedSummary.totalWeightGrams, 0);
  assert.equal(allUnweighedSummary.hasUnweighedItems, true);
  assert.equal(allUnweighedSummary.allItemsUnweighed, true);
});

test('buildCreateGuestOrderPayload keeps pickup clean and always uses JNT_EXPRESS for delivery', () => {
  const items: CartItem[] = [
    { product: makeProduct({ id: 'p1', weightGrams: 200 }), quantity: 2 },
  ];

  const pickupPayload = buildCreateGuestOrderPayload({
    customerName: ' Siti Aminah ',
    customerPhone: '081234567890',
    fulfillmentType: 'pickup',
    deliveryAddress: 'Jl. Seharusnya Dikosongkan',
    notes: ' Ambil sore ',
    idempotencyKey: 'idem-key-12345678',
    items,
  });
  assert.equal(pickupPayload.fulfillmentType, 'pickup');
  assert.equal(pickupPayload.deliveryAddress, '');
  assert.equal('shippingProvider' in pickupPayload, false);

  const jntPayload = buildCreateGuestOrderPayload({
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    notes: 'Tolong packing rapi',
    idempotencyKey: 'idem-key-jnt-1234',
    items,
  });
  assert.deepEqual(jntPayload, {
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    shippingProvider: 'JNT_EXPRESS',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    notes: 'Tolong packing rapi',
    idempotencyKey: 'idem-key-jnt-1234',
    items: [{ productId: 'p1', quantity: 2 }],
  });
  const jntAutoPayload = buildCreateGuestOrderPayload({
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    destinationDistrictId: 5507,
    selectedServiceCode: ' ez ',
    notes: 'Tolong packing rapi',
    idempotencyKey: 'idem-key-jnt-auto-1',
    items,
  });
  assert.deepEqual(jntAutoPayload, {
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    shippingProvider: 'JNT_EXPRESS',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    destinationDistrictId: 5507,
    selectedServiceCode: 'EZ',
    notes: 'Tolong packing rapi',
    idempotencyKey: 'idem-key-jnt-auto-1',
    items: [{ productId: 'p1', quantity: 2 }],
  });
  assert.equal('shippingFee' in jntAutoPayload, false);
  assert.equal('totalAmount' in jntAutoPayload, false);
  assert.equal('itemsSubtotal' in jntAutoPayload, false);
  assert.equal('weightGrams' in jntAutoPayload, false);

  const pickupIgnoringAutoPayload = buildCreateGuestOrderPayload({
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'pickup',
    deliveryAddress: 'Jl. Seharusnya Dikosongkan',
    destinationDistrictId: 5507,
    selectedServiceCode: 'EZ',
    notes: 'Ambil sore',
    idempotencyKey: 'idem-key-pickup-2',
    items,
  });
  assert.equal('destinationDistrictId' in pickupIgnoringAutoPayload, false);
  assert.equal('selectedServiceCode' in pickupIgnoringAutoPayload, false);
  assert.equal('shippingProvider' in pickupIgnoringAutoPayload, false);
  assert.equal('expectedShippingFee' in pickupIgnoringAutoPayload, false);

  const jntWithExpectedFee = buildCreateGuestOrderPayload({
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    destinationDistrictId: 5507,
    selectedServiceCode: 'EZ',
    expectedShippingFee: 15000.456,
    notes: '',
    idempotencyKey: 'idem-key-jnt-expected-fee',
    items,
  });
  assert.equal(jntWithExpectedFee.expectedShippingFee, 15000.46);

  const manualDeliveryIgnoringExpectedFee = buildCreateGuestOrderPayload({
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    expectedShippingFee: 15000,
    notes: '',
    idempotencyKey: 'idem-key-manual-no-expected',
    items,
  });
  assert.equal('expectedShippingFee' in manualDeliveryIgnoringExpectedFee, false);

  const invalidExpectedFee = buildCreateGuestOrderPayload({
    customerName: 'Siti Aminah',
    customerPhone: '081234567890',
    fulfillmentType: 'delivery',
    deliveryAddress: 'Jl. Jenderal Sudirman No. 45, Ponorogo',
    destinationDistrictId: 5507,
    selectedServiceCode: 'EZ',
    expectedShippingFee: -500,
    notes: '',
    idempotencyKey: 'idem-key-invalid-expected',
    items,
  });
  assert.equal('expectedShippingFee' in invalidExpectedFee, false);
});

test('buildCheckoutIdempotencySignature differentiates pickup, legacy delivery, and destination/service selections cleanly', () => {
  const items: CartItem[] = [
    { product: makeProduct({ id: 'p1' }), quantity: 1 },
  ];
  const sigPickup = buildCheckoutIdempotencySignature(items, 'pickup');
  const sigDelivery = buildCheckoutIdempotencySignature(items, 'delivery');
  const sigDeliveryWithAuto = buildCheckoutIdempotencySignature(
    items,
    'delivery',
    'JNT_EXPRESS',
    { destinationDistrictId: 5507, selectedServiceCode: 'ez' }
  );
  const sigDeliveryOtherSvc = buildCheckoutIdempotencySignature(
    items,
    'delivery',
    'JNT_EXPRESS',
    { destinationDistrictId: 5507, selectedServiceCode: 'JSD' }
  );

  assert.equal(sigPickup, 'pickup::p1:1');
  assert.equal(sigDelivery, 'delivery:JNT_EXPRESS::p1:1');
  assert.equal(sigDeliveryWithAuto, 'delivery:JNT_EXPRESS:dest=5507:svc=EZ::p1:1');
  assert.notEqual(sigPickup, sigDelivery);
  assert.notEqual(sigDelivery, sigDeliveryWithAuto);
  assert.notEqual(sigDeliveryWithAuto, sigDeliveryOtherSvc);
});

test('formatStructuredDeliveryAddress includes street, all 4 region codes/names without house number, RT/RW, or patokan, and supports fallback', () => {
  const kabAddress = formatStructuredDeliveryAddress({
    province: { code: '35', name: 'JAWA TIMUR' },
    city: { code: '35.02', name: 'KAB. PONOROGO' },
    district: { code: '35.02.17', name: 'PONOROGO' },
    village: { code: '35.02.17.1001', name: 'SURODIKRAMAN' },
    streetAddress: 'Jl. Jenderal Sudirman',
  });
  assert.equal(
    kabAddress,
    'Jl. Jenderal Sudirman, Kel./Desa SURODIKRAMAN (35.02.17.1001), Kec. PONOROGO (35.02.17), KAB. PONOROGO (35.02), Prov. JAWA TIMUR (35)'
  );

  // Non-prefixed city/regency name gets Kab./Kota prefix cleanly
  const cityAddress = formatStructuredDeliveryAddress({
    province: { code: '31', name: 'DKI JAKARTA' },
    city: { code: '31.74', name: 'JAKARTA SELATAN' },
    district: { code: '31.74.04', name: 'PASAR MINGGU' },
    village: { code: '31.74.04.1001', name: 'PEJATEN TIMUR' },
    streetAddress: 'Jl. Raya Pasar Minggu',
  });
  assert.equal(
    cityAddress,
    'Jl. Raya Pasar Minggu, Kel./Desa PEJATEN TIMUR (31.74.04.1001), Kec. PASAR MINGGU (31.74.04), Kab./Kota JAKARTA SELATAN (31.74), Prov. DKI JAKARTA (31)'
  );

  // Empty streetAddress falls back safely to manualFallbackAddress
  const emptyStreetFallback = formatStructuredDeliveryAddress({
    province: { code: '35', name: 'JAWA TIMUR' },
    city: { code: '35.02', name: 'KAB. PONOROGO' },
    district: { code: '35.02.17', name: 'PONOROGO' },
    village: { code: '35.02.17.1001', name: 'SURODIKRAMAN' },
    streetAddress: '   ',
    manualFallbackAddress: 'Jl. Alamat Fallback Manual',
  });
  assert.equal(emptyStreetFallback, 'Jl. Alamat Fallback Manual');

  // Fallback to legacy manual string if region dropdowns incomplete
  const fallback = formatStructuredDeliveryAddress({
    province: null,
    city: null,
    district: null,
    village: null,
    streetAddress: '',
    manualFallbackAddress: 'Jl. Alamat Lama Manual No. 12 Ponorogo',
  });
  assert.equal(fallback, 'Jl. Alamat Lama Manual No. 12 Ponorogo');
});

