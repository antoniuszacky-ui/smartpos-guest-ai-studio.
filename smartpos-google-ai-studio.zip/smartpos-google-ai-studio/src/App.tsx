/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { CartCheckoutDrawer } from './components/CartCheckoutDrawer';
import { CatalogView } from './components/CatalogView';
import { Header, type AppView } from './components/Header';
import { HomeView } from './components/HomeView';
import { MobileBottomNav } from './components/MobileBottomNav';
import { OrderStatusPage } from './components/OrderStatusPage';
import { OwnerCancelledOrdersModal } from './components/OwnerCancelledOrdersModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { STORE_INFO } from './config/storeDisplay';
import { apiUrl } from './lib/api';
import type { CartItem, Category, GuestOrder, Product } from './types/pos';

const CART_STORAGE_KEY = 'smartpos_guest_cart_v1';
const ORDERS_STORAGE_KEY = 'smartpos_guest_orders_v1';

export default function App() {
  const [activeView, setActiveView] = useState<AppView>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isCatalogLoading, setIsCatalogLoading] = useState<boolean>(true);
  const [catalogError, setCatalogError] = useState<string | null>(null);

  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  const [recentOrders, setRecentOrders] = useState<GuestOrder[]>(() => {
    try {
      const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as GuestOrder[]) : [];
    } catch {
      return [];
    }
  });

  const [activeOrder, setActiveOrder] = useState<GuestOrder | null>(() => {
    try {
      const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
      const parsed = saved ? (JSON.parse(saved) as GuestOrder[]) : [];
      return parsed[0] ?? null;
    } catch {
      return null;
    }
  });

  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isOwnerModalOpen, setIsOwnerModalOpen] = useState<boolean>(
    () => typeof window !== 'undefined' && window.location.hash === '#owner'
  );
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const loadCatalog = useCallback(async () => {
    try {
      setIsCatalogLoading(true);
      setCatalogError(null);
      const res = await fetch(apiUrl('/api/catalog'), { cache: 'no-store' });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setProducts([]);
        setCategories([]);
        setCatalogError(
          typeof data?.error === 'string' && data.error
            ? data.error
            : 'Katalog Owner belum tersedia. Periksa konfigurasi backend.'
        );
        return;
      }

      if (Array.isArray(data.products)) {
        setProducts(data.products);
      }
      if (Array.isArray(data.categories)) {
        setCategories(data.categories);
      }
    } catch {
      setProducts([]);
      setCategories([]);
      setCatalogError(
        'Gagal terhubung ke server SmartPOS Guest untuk memuat katalog Owner.'
      );
    } finally {
      setIsCatalogLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadCatalog();
  }, [loadCatalog]);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
    } catch {
      // Ignore storage quota errors
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(recentOrders));
    } catch {
      // Ignore storage quota errors
    }
  }, [recentOrders]);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = window.setTimeout(() => setToastMessage(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toastMessage]);

  function handleAddToCart(product: Product, addQty = 1) {
    if (product.stock <= 0) return;

    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        const nextQty = Math.min(product.stock, existing.quantity + addQty);
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, product, quantity: nextQty } : item
        );
      }
      return [...prev, { product, quantity: Math.min(product.stock, addQty) }];
    });

    setToastMessage(`Ditambahkan ke keranjang: ${product.name}`);
  }

  function handleUpdateCartQty(productId: string, nextQty: number) {
    if (nextQty <= 0) {
      handleRemoveCartItem(productId);
      return;
    }

    setCartItems((prev) =>
      prev.map((item) => {
        if (item.product.id !== productId) return item;
        const clamped = Math.min(item.product.stock, nextQty);
        return { ...item, quantity: clamped };
      })
    );
  }

  function handleRemoveCartItem(productId: string) {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  }

  function handleOrderCreated(order: GuestOrder) {
    setCartItems([]);
    setIsCartOpen(false);
    setActiveOrder(order);
    setRecentOrders((prev) => {
      const filtered = prev.filter((o) => o.orderNumber !== order.orderNumber);
      return [order, ...filtered].slice(0, 6);
    });
    setActiveView('status');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleOrderLoaded(order: GuestOrder) {
    setActiveOrder(order);
    setRecentOrders((prev) => {
      const filtered = prev.filter((o) => o.orderNumber !== order.orderNumber);
      return [order, ...filtered].slice(0, 6);
    });
  }

  function handleGoToCatalog(categoryId?: string) {
    if (categoryId) {
      setSelectedCategory(categoryId);
    } else {
      setSelectedCategory('all');
    }
    setActiveView('catalog');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleNavigate(view: AppView) {
    setActiveView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 pb-20 md:pb-0">
      <Header
        activeView={activeView}
        onNavigate={handleNavigate}
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {catalogError && (
        <div
          role="alert"
          className="bg-amber-50 border-b border-amber-200 px-4 py-2.5 text-center text-xs sm:text-sm text-amber-900"
        >
          {catalogError}
        </div>
      )}

      <main className="flex-1">
        {activeView === 'home' && (
          <HomeView
            products={products}
            categories={categories}
            cartItems={cartItems}
            isLoading={isCatalogLoading}
            catalogError={catalogError}
            onRetryCatalog={loadCatalog}
            onGoToCatalog={handleGoToCatalog}
            onGoToStatus={() => handleNavigate('status')}
            onSelectProduct={setSelectedProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onUpdateCartQty={handleUpdateCartQty}
          />
        )}

        {activeView === 'catalog' && (
          <CatalogView
            products={products}
            categories={categories}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            cartItems={cartItems}
            onSelectProduct={setSelectedProduct}
            onAddToCart={(p) => handleAddToCart(p, 1)}
            onUpdateCartQty={handleUpdateCartQty}
            isLoading={isCatalogLoading}
            catalogError={catalogError}
            onRetryCatalog={loadCatalog}
          />
        )}

        {activeView === 'status' && (
          <OrderStatusPage
            activeOrder={activeOrder}
            recentOrders={recentOrders}
            onOrderLoaded={handleOrderLoaded}
            onBackToCatalog={() => handleGoToCatalog()}
          />
        )}
      </main>

      <footer className="bg-white border-t border-slate-200 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs sm:text-sm text-slate-500">
          <div>
            <p className="font-semibold text-slate-800">SmartPOS Guest</p>
            <p className="mt-0.5">
              {STORE_INFO.name} · {STORE_INFO.address}
            </p>
          </div>
          <div className="flex items-center gap-5">
            <button
              type="button"
              onClick={() => handleNavigate('catalog')}
              className="hover:text-blue-700 transition-colors"
            >
              Katalog
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('status')}
              className="hover:text-blue-700 transition-colors"
            >
              Cek Status Pesanan
            </button>
            <button
              type="button"
              onClick={() => setIsOwnerModalOpen(true)}
              className="hover:text-blue-700 transition-colors"
            >
              Kelola Pesanan Batal (Owner)
            </button>
          </div>
        </div>
      </footer>

      <MobileBottomNav
        activeView={activeView}
        onNavigate={handleNavigate}
        hasActiveOrder={Boolean(
          activeOrder &&
            !['COMPLETED', 'REJECTED', 'CANCELLED'].includes(
              activeOrder.status.toUpperCase()
            )
        )}
      />

      <ProductDetailModal
        product={selectedProduct}
        existingCartQty={
          selectedProduct
            ? cartItems.find((c) => c.product.id === selectedProduct.id)?.quantity ?? 0
            : 0
        }
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      <CartCheckoutDrawer
        isOpen={isCartOpen}
        items={cartItems}
        onClose={() => setIsCartOpen(false)}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        onOrderCreated={handleOrderCreated}
      />

      <OwnerCancelledOrdersModal
        isOpen={isOwnerModalOpen}
        onClose={() => setIsOwnerModalOpen(false)}
      />

      {toastMessage && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-40 px-4 py-2.5 rounded-xl bg-slate-900 text-white text-xs sm:text-sm font-medium shadow-lg whitespace-nowrap max-w-[90vw] truncate"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
