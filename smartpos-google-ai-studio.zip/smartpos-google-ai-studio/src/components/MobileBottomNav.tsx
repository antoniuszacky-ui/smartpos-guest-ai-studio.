import { ClipboardList, Home, LayoutGrid } from 'lucide-react';
import type { AppView } from './Header';

interface MobileBottomNavProps {
  activeView: AppView;
  onNavigate: (view: AppView) => void;
  hasActiveOrder: boolean;
}

export function MobileBottomNav({
  activeView,
  onNavigate,
  hasActiveOrder,
}: MobileBottomNavProps) {
  const tabs: Array<{
    id: AppView;
    label: string;
    Icon: typeof Home;
  }> = [
    { id: 'home', label: 'Beranda', Icon: Home },
    { id: 'catalog', label: 'Katalog', Icon: LayoutGrid },
    { id: 'status', label: 'Pesanan', Icon: ClipboardList },
  ];

  return (
    <nav
      aria-label="Navigasi bawah seluler"
      className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-16 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-3 items-center"
    >
      {tabs.map(({ id, label, Icon }) => {
        const isActive = activeView === id;
        return (
          <button
            key={id}
            type="button"
            onClick={() => onNavigate(id)}
            className={`relative flex flex-col items-center justify-center min-h-[44px] h-full transition-colors focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-blue-600 ${
              isActive ? 'text-blue-700 font-semibold' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <div className="relative">
              <Icon className="w-5 h-5" strokeWidth={isActive ? 2.2 : 1.8} />
              {id === 'status' && hasActiveOrder && (
                <span
                  aria-label="Ada pesanan aktif"
                  className="absolute -top-0.5 -right-1 w-2 h-2 rounded-full bg-blue-600"
                />
              )}
            </div>
            <span className="text-[11px] mt-1 tracking-tight whitespace-nowrap">
              {label}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
