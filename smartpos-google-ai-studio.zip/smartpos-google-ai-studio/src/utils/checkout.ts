import type {
  CartItem,
  CreateGuestOrderPayload,
  DeliveryAddressDetails,
  FulfillmentType,
  ShippingProvider,
} from '../types/pos';

export interface CartWeightSummary {
  totalWeightGrams: number;
  weighedItemCount: number;
  unweighedItemNames: string[];
  hasUnweighedItems: boolean;
  allItemsUnweighed: boolean;
}

export function isValidPositiveWeightGrams(weightGrams: unknown): weightGrams is number {
  return (
    typeof weightGrams === 'number' &&
    Number.isFinite(weightGrams) &&
    weightGrams > 0
  );
}

export function calculateCartWeightSummary(items: CartItem[]): CartWeightSummary {
  let totalWeightGrams = 0;
  let weighedItemCount = 0;
  const unweighedItemNames: string[] = [];

  for (const item of items) {
    if (isValidPositiveWeightGrams(item.product.weightGrams)) {
      totalWeightGrams += item.product.weightGrams * item.quantity;
      weighedItemCount += 1;
    } else {
      unweighedItemNames.push(item.product.name);
    }
  }

  return {
    totalWeightGrams: Math.round(totalWeightGrams * 100) / 100,
    weighedItemCount,
    unweighedItemNames,
    hasUnweighedItems: unweighedItemNames.length > 0,
    allItemsUnweighed: items.length > 0 && weighedItemCount === 0,
  };
}

export function formatWeightDisplay(totalWeightGrams: number): string {
  const safeGrams =
    Number.isFinite(totalWeightGrams) && totalWeightGrams > 0
      ? Math.round(totalWeightGrams * 100) / 100
      : 0;
  const gramsLabel = new Intl.NumberFormat('id-ID', {
    maximumFractionDigits: 2,
  }).format(safeGrams);

  if (safeGrams >= 1000) {
    const kgLabel = new Intl.NumberFormat('id-ID', {
      minimumFractionDigits: 1,
      maximumFractionDigits: 2,
    }).format(safeGrams / 1000);
    return `${gramsLabel} g (${kgLabel} kg)`;
  }

  return `${gramsLabel} g`;
}

export function buildCheckoutIdempotencySignature(
  items: CartItem[],
  fulfillmentType: FulfillmentType,
  shippingProvider: ShippingProvider = 'JNT_EXPRESS',
  options?: {
    destinationDistrictId?: number;
    selectedServiceCode?: string;
  }
): string {
  const cartPart = items
    .map((i) => `${i.product.id}:${i.quantity}`)
    .sort()
    .join('|');
  const effectiveProvider =
    fulfillmentType === 'delivery' ? shippingProvider : 'pickup';
  let deliveryPart =
    fulfillmentType === 'delivery' ? `delivery:${effectiveProvider}` : 'pickup';
  if (fulfillmentType === 'delivery') {
    if (
      typeof options?.destinationDistrictId === 'number' &&
      Number.isSafeInteger(options.destinationDistrictId) &&
      options.destinationDistrictId > 0
    ) {
      deliveryPart += `:dest=${options.destinationDistrictId}`;
    }
    const cleanServiceCode =
      typeof options?.selectedServiceCode === 'string'
        ? options.selectedServiceCode.trim().toUpperCase()
        : '';
    if (cleanServiceCode) {
      deliveryPart += `:svc=${cleanServiceCode}`;
    }
  }
  return `${deliveryPart}::${cartPart}`;
}

export function buildCreateGuestOrderPayload(params: {
  customerName: string;
  customerPhone: string;
  fulfillmentType: FulfillmentType;
  deliveryAddress: string;
  destinationDistrictId?: number;
  selectedServiceCode?: string;
  expectedShippingFee?: number;
  notes: string;
  idempotencyKey: string;
  items: CartItem[];
}): CreateGuestOrderPayload {
  const basePayload: CreateGuestOrderPayload = {
    customerName: params.customerName.trim(),
    customerPhone: params.customerPhone.trim(),
    fulfillmentType: params.fulfillmentType,
    deliveryAddress:
      params.fulfillmentType === 'delivery' ? params.deliveryAddress.trim() : '',
    notes: params.notes.trim(),
    idempotencyKey: params.idempotencyKey,
    items: params.items.map((item) => ({
      productId: item.product.id,
      quantity: item.quantity,
    })),
  };

  // Preserve exact pickup contract; all delivery orders now exclusively use JNT_EXPRESS.
  if (params.fulfillmentType === 'delivery') {
    basePayload.shippingProvider = 'JNT_EXPRESS';
    const hasValidDest =
      typeof params.destinationDistrictId === 'number' &&
      Number.isSafeInteger(params.destinationDistrictId) &&
      params.destinationDistrictId > 0;
    if (hasValidDest) {
      basePayload.destinationDistrictId = params.destinationDistrictId;
    }
    const cleanServiceCode =
      typeof params.selectedServiceCode === 'string'
        ? params.selectedServiceCode.trim().toUpperCase()
        : '';
    if (cleanServiceCode) {
      basePayload.selectedServiceCode = cleanServiceCode;
    }
    if (
      hasValidDest &&
      cleanServiceCode &&
      typeof params.expectedShippingFee === 'number' &&
      Number.isFinite(params.expectedShippingFee) &&
      params.expectedShippingFee >= 0
    ) {
      basePayload.expectedShippingFee =
        Math.round(params.expectedShippingFee * 100) / 100;
    }
  }

  return basePayload;
}

function normalizeInlineText(value: string | undefined, maxLength: number): string {
  if (typeof value !== 'string') return '';
  return value.trim().replace(/\s+/g, ' ').slice(0, maxLength);
}

export function formatStructuredDeliveryAddress(
  details: DeliveryAddressDetails
): string {
  const manualFallback = normalizeInlineText(details.manualFallbackAddress, 360);
  if (
    !details.province ||
    !details.city ||
    !details.district ||
    !details.village
  ) {
    return manualFallback;
  }

  const street = normalizeInlineText(details.streetAddress, 90);
  if (!street) {
    return manualFallback;
  }

  const villageName = normalizeInlineText(details.village.name, 60);
  const districtName = normalizeInlineText(details.district.name, 60);
  const cityName = normalizeInlineText(details.city.name, 60);
  const provinceName = normalizeInlineText(details.province.name, 60);

  const cityLabel = /^(kab\.?|kabupaten|kota)\b/i.test(cityName)
    ? `${cityName} (${details.city.code.trim()})`
    : `Kab./Kota ${cityName} (${details.city.code.trim()})`;

  const parts: string[] = [
    street,
    `Kel./Desa ${villageName} (${details.village.code.trim()})`,
    `Kec. ${districtName} (${details.district.code.trim()})`,
    cityLabel,
    `Prov. ${provinceName} (${details.province.code.trim()})`,
  ];

  return parts.join(', ').slice(0, 360);
}
