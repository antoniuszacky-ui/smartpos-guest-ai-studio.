import { Minus, Plus, ShoppingBag, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Product } from '../types/pos';
import { formatRupiah } from '../utils/format';
import { SmartImage } from './SmartImage';

interface ProductDetailModalProps {
  product: Product | null;
  existingCartQty: number;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number) => void;
}

export function ProductDetailModal({
  product,
  existingCartQty,
  onClose,
  onAddToCart,
}: ProductDetailModalProps) {
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    setQuantity(1);
  }, [product?.id]);

  useEffect(() => {
    if (!product) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [product, onClose]);

  if (!product) return null;

  const remainingAddable = Math.max(0, product.stock - existingCartQty);
  const isOutOfStock = product.stock <= 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-slate-900/50 backdrop-blur-sm p-0 md:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pdp-title"
      onClick={onClose}
    >
      <div
        className="w-full md:max-w-3xl bg-white rounded-t-3xl md:rounded-3xl overflow-hidden shadow-2xl max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="md:hidden w-10 h-1.5 bg-slate-300 rounded-full mx-auto mt-3 mb-1 shrink-0" />

        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-100 shrink-0">
          <div className="text-xs text-slate-500 flex items-center gap-2">
            <span>{product.categoryName}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">{product.sku}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup detail produk"
            className="w-10 h-10 flex items-center justify-center rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-6 p-5 md:p-6">
          <div className="aspect-[4/3] w-full rounded-2xl overflow-hidden bg-slate-100 border border-slate-200/70">
            <SmartImage
              src={product.imageUrl}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex flex-col justify-between gap-5">
            <div>
              <h2
                id="pdp-title"
                className="text-xl md:text-2xl font-bold text-slate-900 leading-snug text-balance"
              >
                {product.name}
              </h2>

              <div className="mt-3 flex items-baseline gap-2">
                <span className="font-mono tabular-nums text-2xl font-bold text-blue-700">
                  {formatRupiah(product.price)}
                </span>
                <span className="text-sm text-slate-500">/ {product.unit}</span>
              </div>

              <div className="mt-3 text-sm text-slate-600 flex items-center gap-2">
                <span>Ketersediaan:</span>
                <span
                  className={`font-mono tabular-nums font-semibold ${
                    isOutOfStock
                      ? 'text-rose-600'
                      : product.stock <= 5
                      ? 'text-amber-700'
                      : 'text-blue-700'
                  }`}
                >
                  {isOutOfStock
                    ? 'Stok Habis'
                    : `${product.stock} ${product.unit} tersedia`}
                </span>
              </div>

              {existingCartQty > 0 && (
                <p className="mt-2 text-xs text-blue-700 bg-blue-50 border border-blue-100 rounded-xl px-3 py-2">
                  Sudah ada <span className="font-mono font-semibold">{existingCartQty}</span>{' '}
                  {product.unit} di keranjang Anda.
                </p>
              )}

              <p className="mt-4 text-sm md:text-[15px] leading-relaxed text-slate-600">
                {product.description}
              </p>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-3">
              {!isOutOfStock && remainingAddable > 0 ? (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-slate-700">Jumlah</span>
                    <div className="flex items-center gap-2 bg-slate-100 rounded-xl p-1">
                      <button
                        type="button"
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        disabled={quantity <= 1}
                        aria-label="Kurangi jumlah"
                        className="w-10 h-10 flex items-center justify-center rounded-lg bg-white text-slate-700 hover:text-blue-700 disabled:opacity-40 shadow-xs transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-9 text-center font-mono tabular-nums text-sm font-bold text-slate-900">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setQuantity((q) => Math.min(remainingAddable, q + 1))
                        }
                        disabled={quantity >= remainingAddable}
                        aria-label="Tambah jumlah"
                        className="w-10 h-10 flex items-center justify-center rounded-lg bg-white text-slate-700 hover:text-blue-700 disabled:opacity-40 shadow-xs transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      onAddToCart(product, quantity);
                      onClose();
                    }}
                    className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white text-sm font-semibold flex items-center justify-center gap-2 shadow-sm shadow-blue-600/20 transition-all"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>
                      Tambah ke Keranjang ·{' '}
                      <span className="font-mono tabular-nums">
                        {formatRupiah(product.price * quantity)}
                      </span>
                    </span>
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  disabled
                  className="w-full min-h-[48px] px-5 py-3 rounded-xl bg-slate-100 text-slate-500 text-sm font-semibold cursor-not-allowed"
                >
                  {isOutOfStock
                    ? 'Stok Produk Habis'
                    : 'Batas Stok di Keranjang Tercapai'}
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
