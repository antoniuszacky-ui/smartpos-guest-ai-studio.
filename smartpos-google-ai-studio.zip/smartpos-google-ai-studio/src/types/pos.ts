export type FulfillmentType = 'pickup' | 'delivery';

export type GuestOrderStatus =
  | 'PENDING'
  | 'ACCEPTED'
  | 'READY'
  | 'COMPLETED'
  | 'REJECTED'
  | 'CANCELLED'
  | 'pending'
  | 'accepted'
  | 'ready'
  | 'completed'
  | 'rejected'
  | 'cancelled';

export type ShippingProvider = 'STORE_COURIER' | 'JNT_EXPRESS';

export type ShippingStatus =
  | 'PENDING_RATE'
  | 'READY_TO_SHIP'
  | 'PICKED_UP'
  | 'IN_TRANSIT'
  | 'DELIVERED'
  | 'FAILED';

export interface GuestOrderShipping {
  provider?: ShippingProvider;
  serviceCode?: string;
  destinationDistrictId?: number;
  status?: ShippingStatus;
  /** Non-negative total package weight in grams */
  totalWeightGrams?: number;
  hasUnweighedItems?: boolean;
  /** Non-negative manual or calculated shipping fee in IDR */
  shippingFee?: number;
  shippingFeeConfirmed?: boolean;
  trackingNumber?: string;
  notes?: string;
  updatedAt?: string;
  shippedAt?: string;
  deliveredAt?: string;
}

export interface ShippingLocationOption {
  districtId: number;
  subdistrictId?: number;
  label: string;
  provinceName?: string;
  cityName?: string;
  districtName?: string;
  subdistrictName?: string;
  postalCode?: string;
}

export interface JntRateOption {
  courier: 'jnt';
  courierName: string;
  serviceCode: string;
  serviceName: string;
  description?: string;
  cost: number;
  etd?: string;
  cod?: boolean;
}

export interface ShippingLocationSearchResponse {
  available: boolean;
  locations: ShippingLocationOption[];
  reason?: string;
}

export interface ShippingRateQuoteRequest {
  destinationDistrictId: number;
  items: Array<{
    productId: string;
    quantity: number;
  }>;
}

export interface ShippingRateQuoteResponse {
  available: boolean;
  fallbackToManual: boolean;
  reason?: string;
  originDistrictId?: number;
  destinationDistrictId: number;
  totalWeightGrams: number;
  normalizedWeightGrams: number | null;
  hasUnweighedItems: boolean;
  itemsSubtotal: number;
  rates: JntRateOption[];
}

export interface RajaOngkirDestinationOption {
  id: number;
  label: string;
  provinceName?: string;
  cityName?: string;
  districtName?: string;
  subdistrictName?: string;
  zipCode?: string;
}

export interface RajaOngkirDestinationSearchResponse {
  available: boolean;
  destinations: RajaOngkirDestinationOption[];
  reason?: string;
}

export interface RajaOngkirJntCostResponse {
  available: boolean;
  fallbackToManual: boolean;
  reason?: string;
  destinationId: number;
  totalWeightGrams: number;
  normalizedWeightGrams: number | null;
  hasUnweighedItems: boolean;
  itemsSubtotal: number;
  rates: JntRateOption[];
}

export type RegionLevel = 'provinces' | 'cities' | 'districts' | 'villages';

export interface RegionOption {
  code: string;
  name: string;
}

export interface RegionListResponse {
  available: boolean;
  level: RegionLevel;
  parentCode?: string;
  regions: RegionOption[];
  reason?: string;
}

export interface DeliveryAddressDetails {
  province?: RegionOption | null;
  city?: RegionOption | null;
  district?: RegionOption | null;
  village?: RegionOption | null;
  streetAddress: string;
  manualFallbackAddress?: string;
}

export interface LocalShippingRate {
  id: string;
  provinceCode: string;
  provinceName: string;
  cityCode: string;
  cityName: string;
  districtCode: string;
  districtName: string;
  courierName: string;
  serviceName: string;
  weightMinGram: number;
  weightMaxGram: number;
  shippingFee: number;
  isActive: boolean;
  updatedAt: string;
}

export interface LocalShippingRateInput {
  id?: string;
  provinceCode: string;
  provinceName: string;
  cityCode: string;
  cityName: string;
  districtCode: string;
  districtName: string;
  courierName: string;
  serviceName: string;
  weightMinGram: number;
  weightMaxGram: number;
  shippingFee: number;
  isActive: boolean;
}

export interface LocalShippingRateQuoteOption {
  id: string;
  provinceCode: string;
  provinceName: string;
  cityCode: string;
  cityName: string;
  districtCode: string;
  districtName: string;
  courierName: string;
  serviceName: string;
  weightMinGram: number;
  weightMaxGram: number;
  shippingFee: number;
  updatedAt: string;
}

export interface LocalShippingRateQuoteRequest {
  districtCode: string;
  items: Array<{
    productId: string;
    quantity: number;
  }>;
}

export interface LocalShippingRateQuoteResponse {
  available: boolean;
  districtCode: string;
  totalWeightGrams: number;
  normalizedWeightGrams: number | null;
  hasUnweighedItems: boolean;
  itemsSubtotal: number;
  rates: LocalShippingRateQuoteOption[];
  reason?: string;
}


export interface Category {
  id: string;
  name: string;
  slug: string;
  sortOrder: number;
}

// Public product representation for SmartPOS Guest (never includes cost)
export interface Product {
  id: string;
  storeId?: string;
  sku: string;
  barcode?: string;
  brand?: string;
  name: string;
  categoryId: string;
  categoryName: string;
  subCategory?: string;
  size?: string;
  price: number;
  stock: number;
  minStock?: number;
  expiryDate?: string;
  unit: string;
  /** Optional non-negative product weight in grams */
  weightGrams?: number;
  imageUrl: string;
  description: string;
  featured?: boolean;
  isActive: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface GuestOrderItem {
  productId: string;
  sku: string;
  barcode?: string;
  name: string;
  unitPrice: number;
  quantity: number;
  subtotal: number;
  /** Optional non-negative item unit weight in grams */
  weightGrams?: number;
  imageUrl: string;
}

export interface GuestOrder {
  id: string;
  storeId?: string;
  orderNumber: string;
  idempotencyKey?: string;
  customerName: string;
  customerPhone: string;
  fulfillmentType: FulfillmentType;
  deliveryAddress: string;
  notes: string;
  items: GuestOrderItem[];
  /** Optional non-negative items subtotal before shipping fee */
  itemsSubtotal?: number;
  totalAmount: number;
  status: GuestOrderStatus;
  rejectionReason?: string;
  stockDeducted: boolean;
  stockRestored?: boolean;
  shipping?: GuestOrderShipping;
  createdAt: string;
  updatedAt: string;
}

export type OwnerOrderFilter = 'cancelled' | 'all' | 'active' | 'completed';

export interface OwnerGuestOrder extends GuestOrder {
  transactionId?: string;
  saleId?: string;
  kasirTransactionId?: string;
  receiptNumber?: string;
  convertedToSale?: boolean;
  linkedToCashierTransaction: boolean;
  canDelete: boolean;
  deleteBlockedReason?: string;
}

export interface CreateGuestOrderPayload {
  customerName: string;
  customerPhone: string;
  fulfillmentType: FulfillmentType;
  shippingProvider?: ShippingProvider;
  deliveryAddress?: string;
  destinationDistrictId?: number;
  selectedServiceCode?: string;
  /** Client-observed shipping fee estimate used only as a mismatch guard before server saves the order */
  expectedShippingFee?: number;
  notes?: string;
  idempotencyKey: string;
  items: Array<{
    productId: string;
    quantity: number;
  }>;
}

export interface ShippingRateChangedConflict {
  code: 'SHIPPING_RATE_CHANGED';
  error: string;
  expectedShippingFee: number;
  verifiedShippingFee: number;
  verifiedShippingStatus: 'READY_TO_SHIP' | 'PENDING_RATE';
  fallbackToManual: boolean;
  selectedServiceCode?: string;
  rates: JntRateOption[];
  itemsSubtotal?: number;
  totalWeightGrams?: number;
  hasUnweighedItems?: boolean;
}

