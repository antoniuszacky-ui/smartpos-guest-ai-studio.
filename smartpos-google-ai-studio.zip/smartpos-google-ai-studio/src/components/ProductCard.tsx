import { Minus, Plus } from 'lucide-react';
import type { Product } from '../types/pos';
import { formatRupiah } from '../utils/format';
import { SmartImage } from './SmartImage';

interface ProductCardProps {
  product: Product;
  cartQuantity: number;
  onSelect: (product: Product) => void;
  onAdd: (product: Product) => void;
  onUpdateQty: (productId: string, nextQty: number) => void;
}

export function ProductCard({
  product,
  cartQuantity,
  onSelect,
  onAdd,
  onUpdateQty,
}: ProductCardProps) {
  const isOutOfStock = product.stock <= 0;
  const isMaxed = cartQuantity >= product.stock;

  return (
    <article className="group bg-white border border-slate-200/90 rounded-2xl overflow-hidden flex flex-col transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md hover:shadow-blue-950/5 hover:border-blue-200">
      <button
        type="button"
        onClick={() => onSelect(product)}
        className="text-left focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-blue-600"
      >
        <div className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden">
          <SmartImage
            src={product.imageUrl}
            alt={product.name}
            className={`w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03] ${
              isOutOfStock ? 'opacity-50 grayscale' : ''
            }`}
          />
          {isOutOfStock && (
            <div className="absolute inset-0 bg-slate-900/35 flex items-center justify-center">
              <span className="px-3 py-1.5 rounded-lg bg-white/95 text-slate-900 text-xs font-semibold tracking-wide">
                Stok Habis
              </span>
            </div>
          )}
        </div>

        <div className="px-4 pt-4 pb-2 flex-1 flex flex-col">
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1.5">
            <span className="truncate">{product.categoryName}</span>
            <span aria-hidden="true">·</span>
            <span
              className={`font-mono tabular-nums whitespace-nowrap ${
                isOutOfStock
                  ? 'text-rose-600 font-medium'
                  : product.stock <= 5
                  ? 'text-amber-700 font-medium'
                  : 'text-slate-600'
              }`}
            >
              {isOutOfStock ? 'Habis' : `Stok ${product.stock}`}
            </span>
          </div>

          <h3 className="text-[15px] sm:text-base font-semibold text-slate-900 leading-snug line-clamp-2 min-h-[2.6em]">
            {product.name}
          </h3>
        </div>
      </button>

      <div className="px-4 pb-4 pt-2 mt-auto flex items-center justify-between gap-2 border-t border-slate-100">
        <div className="min-w-0">
          <p className="font-mono tabular-nums text-[15px] sm:text-base font-bold text-blue-700 truncate">
            {formatRupiah(product.price)}
          </p>
          <p className="text-[11px] text-slate-500">per {product.unit}</p>
        </div>

        {isOutOfStock ? (
          <button
            type="button"
            disabled
            className="min-h-[44px] px-3.5 rounded-xl bg-slate-100 text-slate-400 text-xs font-medium cursor-not-allowed whitespace-nowrap shrink-0"
          >
            Habis
          </button>
        ) : cartQuantity > 0 ? (
          <div className="flex items-center gap-1 bg-blue-50 border border-blue-200 rounded-xl p-1 shrink-0">
            <button
              type="button"
              onClick={() => onUpdateQty(product.id, cartQuantity - 1)}
              aria-label={`Kurangi jumlah ${product.name}`}
              className="w-9 h-9 flex items-center justify-center rounded-lg text-blue-700 hover:bg-white transition-colors"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="w-6 text-center font-mono tabular-nums text-xs font-bold text-blue-900">
              {cartQuantity}
            </span>
            <button
              type="button"
              disabled={isMaxed}
              onClick={() => onUpdateQty(product.id, cartQuantity + 1)}
              aria-label={`Tambah jumlah ${product.name}`}
              className="w-9 h-9 flex items-center justify-center rounded-lg text-blue-700 hover:bg-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => onAdd(product)}
            className="min-h-[44px] px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <Plus className="w-4 h-4" />
            <span>Tambah</span>
          </button>
        )}
      </div>
    </article>
  );
}
