import { getApp, getApps, initializeApp, type FirebaseApp } from 'firebase/app';
import { getAuth, type Auth } from 'firebase/auth';
import {
  doc,
  getDocFromServer,
  getFirestore,
  initializeFirestore,
  type Firestore,
} from 'firebase/firestore';
import appletConfig from '../../firebase-applet-config.json';

// Firebase Web App configuration for SmartPOS Guest (project: gen-lang-client-0419468994).
// Uses VITE_FIREBASE_* environment variables when provided and falls back to the
// public Web App config in firebase-applet-config.json. Never put Admin SDK
// private credentials in client code.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || appletConfig.apiKey,
  authDomain:
    import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || appletConfig.authDomain,
  projectId:
    import.meta.env.VITE_FIREBASE_PROJECT_ID ||
    appletConfig.projectId ||
    'gen-lang-client-0419468994',
  storageBucket:
    import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || appletConfig.storageBucket,
  messagingSenderId:
    import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID ||
    appletConfig.messagingSenderId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || appletConfig.appId,
};

const requiredConfig = [
  'apiKey',
  'authDomain',
  'projectId',
  'appId',
] as const;

for (const key of requiredConfig) {
  if (!firebaseConfig[key]) {
    throw new Error(
      `Firebase configuration is missing: ${key}. ` +
        'Set the corresponding VITE_FIREBASE_* value in your .env file.'
    );
  }
}

// Reuse the existing app during Vite HMR to avoid duplicate initialization.
const isNewApp = getApps().length === 0;
const app: FirebaseApp = isNewApp ? initializeApp(firebaseConfig) : getApp();

const databaseId =
  import.meta.env.VITE_FIREBASE_DATABASE_ID || appletConfig.firestoreDatabaseId;
const targetDatabaseId =
  databaseId && databaseId !== '(default)' ? databaseId : undefined;

// Firestore client SDK with auto-detected long polling for proxy/iframe reliability.
// Access is governed by Firebase Authentication and Firestore Security Rules.
export const db: Firestore = (() => {
  if (isNewApp) {
    return initializeFirestore(
      app,
      { experimentalAutoDetectLongPolling: true },
      targetDatabaseId
    );
  }
  return targetDatabaseId ? getFirestore(app, targetDatabaseId) : getFirestore(app);
})();

export const auth: Auth = getAuth(app);
export { app };

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: Array<{
      providerId?: string | null;
      email?: string | null;
    }>;
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    // Permission denied proves Firestore server is reachable and enforcing rules.
    if (message.includes('permission-denied') || message.includes('Missing or insufficient permissions')) {
      return true;
    }
    if (message.includes('the client is offline')) {
      console.warn('Firestore client is currently offline or unreachable.');
    }
    return false;
  }
}
