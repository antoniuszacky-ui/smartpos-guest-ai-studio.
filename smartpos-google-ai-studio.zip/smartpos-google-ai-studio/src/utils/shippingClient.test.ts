import assert from 'node:assert/strict';
import test from 'node:test';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { createServer as createViteServer } from 'vite';
import type { CartItem, JntRateOption, Product } from '../types/pos.ts';

const vite = await createViteServer({
  server: { middlewareMode: true },
  appType: 'custom',
});

const shippingClient = (await vite.ssrLoadModule(
  '/src/utils/shippingClient.ts'
)) as typeof import('./shippingClient.ts');

const { CartCheckoutDrawer } = (await vite.ssrLoadModule(
  '/src/components/CartCheckoutDrawer.tsx'
)) as typeof import('../components/CartCheckoutDrawer.tsx');

test.after(async () => {
  await vite.close();
});

function makeProduct(overrides: Partial<Product> = {}): Product {
  return {
    id: 'prod_1',
    sku: 'SKU-1',
    name: 'Kopi Susu 250ml',
    categoryId: 'minuman',
    categoryName: 'Minuman',
    price: 18000,
    stock: 15,
    unit: 'botol',
    weightGrams: 300,
    imageUrl: '',
    description: '',
    isActive: true,
    ...overrides,
  };
}

test('buildCartQuoteItems strips price, weight, subtotal, and sends only productId + quantity', () => {
  const items: CartItem[] = [
    { product: makeProduct({ id: 'p_a', price: 25000, weightGrams: 500 }), quantity: 2 },
    { product: makeProduct({ id: 'p_b', price: 10000, weightGrams: 150 }), quantity: 1 },
  ];

  const payloadItems = shippingClient.buildCartQuoteItems(items);
  assert.deepEqual(payloadItems, [
    { productId: 'p_a', quantity: 2 },
    { productId: 'p_b', quantity: 1 },
  ]);
  for (const item of payloadItems) {
    assert.deepEqual(Object.keys(item).sort(), ['productId', 'quantity']);
  }
});

test('searchShippingLocations enforces min 3 chars, forwards AbortSignal, handles available:false and HTTP 400/429', async () => {
  let called = false;
  const shortRes = await shippingClient.searchShippingLocations({
    search: 'po',
    fetchImpl: async () => {
      called = true;
      throw new Error('Should not fetch for < 3 chars');
    },
  });
  assert.equal(called, false);
  assert.equal(shortRes.ok, true);
  assert.deepEqual(shortRes.locations, []);

  // Valid location search with deduplication and filtering
  let requestedUrl = '';
  let receivedSignal: AbortSignal | undefined;
  const controller = new AbortController();
  const okRes = await shippingClient.searchShippingLocations({
    search: '  ponorogo  ',
    limit: 10,
    signal: controller.signal,
    fetchImpl: async (input, init) => {
      requestedUrl = String(input);
      receivedSignal = init?.signal ?? undefined;
      return new Response(
        JSON.stringify({
          available: true,
          locations: [
            {
              districtId: 5783,
              label: 'Babadan, Ponorogo, Jawa Timur',
              postalCode: '63491',
            },
            {
              districtId: 5783,
              label: 'Duplicate',
            },
            {
              districtId: -1,
              label: 'Invalid',
            },
          ],
        }),
        { status: 200 }
      );
    },
  });
  assert.equal(requestedUrl, '/api/shipping/locations?search=ponorogo&limit=10');
  assert.equal(receivedSignal, controller.signal);
  assert.equal(okRes.ok, true);
  assert.equal(okRes.available, true);
  assert.equal(okRes.locations.length, 1);
  assert.equal(okRes.locations[0].districtId, 5783);

  // available: false fallback
  const unavailRes = await shippingClient.searchShippingLocations({
    search: 'ponorogo',
    fetchImpl: async () =>
      new Response(
        JSON.stringify({
          available: false,
          locations: [],
          reason: 'Pencarian kecamatan belum aktif.',
        }),
        { status: 200 }
      ),
  });
  assert.equal(unavailRes.ok, true);
  assert.equal(unavailRes.available, false);
  assert.equal(unavailRes.reason, 'Pencarian kecamatan belum aktif.');

  // HTTP 400 and 429 error mapping
  const err400 = await shippingClient.searchShippingLocations({
    search: 'ponorogo',
    fetchImpl: async () =>
      new Response(JSON.stringify({ error: 'Query tidak valid.' }), { status: 400 }),
  });
  assert.equal(err400.ok, false);
  assert.equal(err400.statusCode, 400);
  assert.equal(err400.errorMessage, 'Query tidak valid.');

  const err429 = await shippingClient.searchShippingLocations({
    search: 'ponorogo',
    fetchImpl: async () => new Response(JSON.stringify({}), { status: 429 }),
  });
  assert.equal(err429.ok, false);
  assert.equal(err429.statusCode, 429);
  assert.match(err429.errorMessage || '', /Terlalu banyak/);

  // AbortSignal handling
  const abortController = new AbortController();
  const abortedRes = await shippingClient.searchShippingLocations({
    search: 'ponorogo',
    signal: abortController.signal,
    fetchImpl: async () => {
      abortController.abort();
      const err = new Error('The operation was aborted');
      err.name = 'AbortError';
      throw err;
    },
  });
  assert.equal(abortedRes.aborted, true);
  assert.equal(abortedRes.errorMessage, undefined);
});

test('quoteJntShippingRates sends minimal safe payload, sorts rates, handles fallbackToManual and HTTP 400/404/409/429', async () => {
  const items: CartItem[] = [
    { product: makeProduct({ id: 'prod_ok', price: 50000, weightGrams: 500 }), quantity: 2 },
  ];

  let sentBody: Record<string, unknown> | null = null;
  const okQuote = await shippingClient.quoteJntShippingRates({
    destinationDistrictId: 5507,
    items,
    fetchImpl: async (_url, init) => {
      sentBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return new Response(
        JSON.stringify({
          available: true,
          fallbackToManual: false,
          destinationDistrictId: 5507,
          totalWeightGrams: 1000,
          normalizedWeightGrams: 1000,
          hasUnweighedItems: false,
          itemsSubtotal: 100000,
          rates: [
            {
              courier: 'jnt',
              courierName: 'J&T Express',
              serviceCode: 'JSD',
              serviceName: 'J&T Super',
              cost: 32000,
              etd: '1',
            },
            {
              courier: 'jnt',
              courierName: 'J&T Express',
              serviceCode: 'ez',
              serviceName: 'J&T Reguler',
              cost: 18000,
              etd: '2-3',
            },
          ],
        }),
        { status: 200 }
      );
    },
  });

  assert.deepEqual(sentBody, {
    destinationDistrictId: 5507,
    items: [{ productId: 'prod_ok', quantity: 2 }],
  });
  assert.equal(okQuote.ok, true);
  assert.equal(okQuote.available, true);
  assert.equal(okQuote.fallbackToManual, false);
  assert.equal(okQuote.rates.length, 2);
  assert.equal(okQuote.rates[0].serviceCode, 'EZ');
  assert.equal(okQuote.rates[0].cost, 18000);
  assert.equal(shippingClient.formatEtdLabel(okQuote.rates[0].etd), 'Estimasi 2-3 hari');
  assert.equal(shippingClient.formatEtdLabel('1 hari'), 'Estimasi 1 hari');

  // fallbackToManual / available: false / unweighed items
  const manualQuote = await shippingClient.quoteJntShippingRates({
    destinationDistrictId: 5507,
    items,
    fetchImpl: async () =>
      new Response(
        JSON.stringify({
          available: false,
          fallbackToManual: true,
          hasUnweighedItems: true,
          reason: 'Sebagian produk belum memiliki data berat valid.',
          rates: [],
        }),
        { status: 200 }
      ),
  });
  assert.equal(manualQuote.ok, true);
  assert.equal(manualQuote.available, false);
  assert.equal(manualQuote.fallbackToManual, true);
  assert.equal(manualQuote.hasUnweighedItems, true);
  assert.match(manualQuote.reason || '', /berat valid/);

  // HTTP 400, 404, 409, 429 mappings
  for (const [status, expectedPattern] of [
    [400, /tidak valid/],
    [404, /tidak ditemukan/],
    [409, /Stok/],
    [429, /Terlalu banyak/],
  ] as const) {
    const errRes = await shippingClient.quoteJntShippingRates({
      destinationDistrictId: 5507,
      items,
      fetchImpl: async () => new Response(JSON.stringify({}), { status }),
    });
    assert.equal(errRes.ok, false);
    assert.equal(errRes.statusCode, status);
    assert.equal(errRes.fallbackToManual, true);
    assert.match(errRes.errorMessage || '', expectedPattern);
  }

  // AbortSignal during rate quote
  const abortController = new AbortController();
  const abortedQuote = await shippingClient.quoteJntShippingRates({
    destinationDistrictId: 5507,
    items,
    signal: abortController.signal,
    fetchImpl: async () => {
      abortController.abort();
      const err = new Error('Aborted');
      err.name = 'AbortError';
      throw err;
    },
  });
  assert.equal(abortedQuote.aborted, true);
});

test('selectDefaultJntRate picks cheapest valid rate by default and preserves matching user selection', () => {
  const rates: JntRateOption[] = [
    {
      courier: 'jnt',
      courierName: 'J&T Express',
      serviceCode: 'JSD',
      serviceName: 'Super',
      cost: 32000,
    },
    {
      courier: 'jnt',
      courierName: 'J&T Express',
      serviceCode: 'EZ',
      serviceName: 'Reguler',
      cost: 18000,
    },
  ];

  assert.equal(shippingClient.selectDefaultJntRate(rates)?.serviceCode, 'EZ');
  assert.equal(shippingClient.selectDefaultJntRate(rates, 'jsd')?.serviceCode, 'JSD');
  assert.equal(shippingClient.selectDefaultJntRate(rates, 'MISSING')?.serviceCode, 'EZ');
  assert.equal(shippingClient.selectDefaultJntRate([]), null);
});

test('CartCheckoutDrawer SSR renders cleanly with cart items', () => {
  const html = renderToStaticMarkup(
    React.createElement(CartCheckoutDrawer, {
      isOpen: true,
      items: [{ product: makeProduct(), quantity: 2 }],
      onClose: () => {},
      onUpdateQty: () => {},
      onRemoveItem: () => {},
      onOrderCreated: () => {},
    })
  );
  assert.match(html, /Keranjang Belanja/);
  assert.match(html, /Kopi Susu 250ml/);
  assert.match(html, /Lanjut ke Pengiriman/);
});
