import type { GuestOrder, ShippingStatus } from '../types/pos';
import { formatWeightDisplay } from './checkout';

export type ShippingProgressStepKey =
  | 'READY_TO_SHIP'
  | 'PICKED_UP'
  | 'IN_TRANSIT'
  | 'DELIVERED';

export interface JntShippingViewModel {
  isJntExpress: boolean;
  serviceLabel: string;
  shippingStatus: ShippingStatus;
  statusLabel: string;
  statusDescription: string;
  isFailed: boolean;
  progressSteps: Array<{ key: ShippingProgressStepKey; label: string }>;
  currentProgressIndex: number;
  trackingNumber: string | null;
  hasTrackingNumber: boolean;
  weightLabel: string | null;
  hasIncompleteWeightWarning: boolean;
  incompleteWeightMessage: string | null;
  itemsSubtotal: number;
  isShippingFeeConfirmed: boolean;
  confirmedShippingFee: number | null;
  shippingFeePendingText: string;
  totalAmount: number;
  totalLabel: string;
  shippingNotes: string | null;
  updatedAt?: string;
  shippedAt?: string;
  deliveredAt?: string;
}

const SHIPPING_PROGRESS_STEPS: Array<{
  key: ShippingProgressStepKey;
  label: string;
}> = [
  { key: 'READY_TO_SHIP', label: 'Menunggu pengiriman' },
  { key: 'PICKED_UP', label: 'Diambil kurir' },
  { key: 'IN_TRANSIT', label: 'Dalam perjalanan' },
  { key: 'DELIVERED', label: 'Diterima' },
];

export const JNT_SHIPPING_STATUS_META: Record<
  ShippingStatus,
  { label: string; description: string }
> = {
  PENDING_RATE: {
    label: 'Menunggu konfirmasi ongkir',
    description:
      'Ongkos kirim J&T Express sedang diperiksa dan akan dikonfirmasi oleh Owner toko.',
  },
  READY_TO_SHIP: {
    label: 'Menunggu pengiriman',
    description:
      'Pesanan siap dikirim melalui J&T Express dan menunggu penjemputan atau penyerahan ke kurir.',
  },
  PICKED_UP: {
    label: 'Paket telah diambil kurir',
    description:
      'Paket Anda telah diserahkan kepada kurir J&T Express untuk diproses lebih lanjut.',
  },
  IN_TRANSIT: {
    label: 'Paket sedang dalam perjalanan',
    description:
      'Paket sedang berada dalam proses pengiriman menuju alamat tujuan.',
  },
  DELIVERED: {
    label: 'Paket telah diterima',
    description: 'Pengiriman paket J&T Express telah selesai diterima.',
  },
  FAILED: {
    label: 'Pengiriman mengalami kendala',
    description:
      'Pengiriman paket melalui J&T Express sedang mengalami kendala. Silakan hubungi toko untuk koordinasi lebih lanjut.',
  },
};

function computeItemsSubtotal(order: GuestOrder): number {
  if (
    typeof order.itemsSubtotal === 'number' &&
    Number.isFinite(order.itemsSubtotal) &&
    order.itemsSubtotal >= 0
  ) {
    return order.itemsSubtotal;
  }
  const fromItems = order.items.reduce(
    (sum, item) => sum + (Number.isFinite(item.subtotal) ? item.subtotal : 0),
    0
  );
  return Math.round(fromItems * 100) / 100;
}

export function getJntShippingViewModel(
  order: GuestOrder
): JntShippingViewModel | null {
  if (
    order.fulfillmentType !== 'delivery' ||
    !order.shipping ||
    order.shipping.provider !== 'JNT_EXPRESS'
  ) {
    return null;
  }

  const shipping = order.shipping;
  const rawStatus = shipping.status;
  const shippingStatus: ShippingStatus =
    rawStatus && rawStatus in JNT_SHIPPING_STATUS_META
      ? rawStatus
      : 'PENDING_RATE';
  const meta = JNT_SHIPPING_STATUS_META[shippingStatus];

  const trackingNumber =
    typeof shipping.trackingNumber === 'string' && shipping.trackingNumber.trim()
      ? shipping.trackingNumber.trim()
      : null;

  const totalWeightGrams =
    typeof shipping.totalWeightGrams === 'number' &&
    Number.isFinite(shipping.totalWeightGrams) &&
    shipping.totalWeightGrams >= 0
      ? shipping.totalWeightGrams
      : null;

  const hasUnweighedItems = Boolean(shipping.hasUnweighedItems);
  const hasPositiveWeight = totalWeightGrams !== null && totalWeightGrams > 0;

  let weightLabel: string | null = null;
  if (hasPositiveWeight && totalWeightGrams !== null) {
    weightLabel = formatWeightDisplay(totalWeightGrams);
  } else if (totalWeightGrams === 0 && !hasUnweighedItems) {
    weightLabel = formatWeightDisplay(0);
  }

  let incompleteWeightMessage: string | null = null;
  if (hasUnweighedItems) {
    incompleteWeightMessage = hasPositiveWeight
      ? 'Sebagian produk belum memiliki data berat lengkap; berat akhir diverifikasi Owner.'
      : 'Data berat produk belum lengkap di katalog dan akan ditimbang oleh Owner.';
  }

  const isShippingFeeConfirmed =
    shipping.shippingFeeConfirmed === true &&
    typeof shipping.shippingFee === 'number' &&
    Number.isFinite(shipping.shippingFee) &&
    shipping.shippingFee >= 0;

  const confirmedShippingFee = isShippingFeeConfirmed
    ? (shipping.shippingFee as number)
    : null;

  const currentProgressIndex =
    shippingStatus === 'FAILED' || shippingStatus === 'PENDING_RATE'
      ? -1
      : SHIPPING_PROGRESS_STEPS.findIndex((step) => step.key === shippingStatus);

  const serviceCode =
    typeof shipping.serviceCode === 'string' && shipping.serviceCode.trim()
      ? shipping.serviceCode.trim()
      : null;

  return {
    isJntExpress: true,
    serviceLabel: serviceCode ? `J&T Express · ${serviceCode}` : 'J&T Express',
    shippingStatus,
    statusLabel: meta.label,
    statusDescription: meta.description,
    isFailed: shippingStatus === 'FAILED',
    progressSteps: SHIPPING_PROGRESS_STEPS,
    currentProgressIndex,
    trackingNumber,
    hasTrackingNumber: trackingNumber !== null,
    weightLabel,
    hasIncompleteWeightWarning: hasUnweighedItems,
    incompleteWeightMessage,
    itemsSubtotal: computeItemsSubtotal(order),
    isShippingFeeConfirmed,
    confirmedShippingFee,
    shippingFeePendingText: 'Ongkos kirim sedang menunggu konfirmasi Owner.',
    totalAmount: order.totalAmount,
    totalLabel: isShippingFeeConfirmed ? 'Total Pembayaran' : 'Total Sementara',
    shippingNotes:
      typeof shipping.notes === 'string' && shipping.notes.trim()
        ? shipping.notes.trim()
        : null,
    updatedAt: shipping.updatedAt,
    shippedAt: shipping.shippedAt,
    deliveredAt: shipping.deliveredAt,
  };
}

export async function copyTrackingNumberText(
  trackingNumber: string
): Promise<boolean> {
  const cleanText = trackingNumber.trim();
  if (!cleanText) return false;

  if (
    typeof navigator !== 'undefined' &&
    navigator.clipboard &&
    typeof navigator.clipboard.writeText === 'function'
  ) {
    try {
      await navigator.clipboard.writeText(cleanText);
      return true;
    } catch {
      // Fallback below
    }
  }

  if (typeof document !== 'undefined' && document.body) {
    try {
      const textarea = document.createElement('textarea');
      textarea.value = cleanText;
      textarea.setAttribute('readonly', 'true');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      const copied = document.execCommand('copy');
      document.body.removeChild(textarea);
      return copied;
    } catch {
      return false;
    }
  }

  return false;
}
