import { apiUrl } from '../lib/api';
import type {
  CartItem,
  JntRateOption,
  ShippingLocationOption,
  ShippingLocationSearchResponse,
  ShippingRateQuoteRequest,
  ShippingRateQuoteResponse,
} from '../types/pos';

export interface ShippingLocationSearchResult {
  ok: boolean;
  aborted: boolean;
  statusCode?: number;
  available: boolean;
  locations: ShippingLocationOption[];
  reason?: string;
  errorMessage?: string;
}

export interface JntRateQuoteResult {
  ok: boolean;
  aborted: boolean;
  statusCode?: number;
  available: boolean;
  fallbackToManual: boolean;
  hasUnweighedItems: boolean;
  rates: JntRateOption[];
  reason?: string;
  errorMessage?: string;
  totalWeightGrams?: number;
  normalizedWeightGrams?: number | null;
  itemsSubtotal?: number;
}

export function isShippingAbortError(err: unknown): boolean {
  return (
    err instanceof Error &&
    (err.name === 'AbortError' || err.message.toLowerCase().includes('aborted'))
  );
}

export function buildCartQuoteItems(
  items: CartItem[]
): ShippingRateQuoteRequest['items'] {
  return items.map((item) => ({
    productId: item.product.id,
    quantity: item.quantity,
  }));
}

export function mapShippingHttpError(
  status: number,
  serverMessage?: string,
  context: 'locations' | 'rates' = 'rates'
): string {
  const cleanServerMsg =
    typeof serverMessage === 'string' && serverMessage.trim()
      ? serverMessage.trim()
      : undefined;

  if (status === 400) {
    return (
      cleanServerMsg ||
      (context === 'locations'
        ? 'Kata kunci pencarian kecamatan tidak valid.'
        : 'Data tujuan atau daftar barang untuk cek ongkir tidak valid.')
    );
  }
  if (status === 404) {
    return (
      cleanServerMsg ||
      'Sebagian produk di keranjang tidak ditemukan atau sudah tidak tersedia.'
    );
  }
  if (status === 409) {
    return (
      cleanServerMsg ||
      'Stok produk di keranjang tidak mencukupi untuk menghitung ongkos kirim.'
    );
  }
  if (status === 429) {
    return (
      cleanServerMsg ||
      (context === 'locations'
        ? 'Terlalu banyak pencarian kecamatan. Tunggu sebentar lalu coba lagi.'
        : 'Terlalu banyak permintaan cek ongkir. Tunggu sebentar lalu coba lagi.')
    );
  }
  if (status >= 500) {
    return (
      cleanServerMsg ||
      'Layanan cek ongkir sedang mengalami gangguan. Pesanan tetap dapat dikirim dengan konfirmasi ongkir oleh Owner.'
    );
  }
  return cleanServerMsg || 'Gagal memuat informasi pengiriman.';
}

function sanitizeLocationOptions(rawLocations: unknown): ShippingLocationOption[] {
  if (!Array.isArray(rawLocations)) return [];
  const valid: ShippingLocationOption[] = [];
  const seenIds = new Set<number>();

  for (const item of rawLocations) {
    if (!item || typeof item !== 'object') continue;
    const loc = item as Partial<ShippingLocationOption>;
    if (
      typeof loc.districtId !== 'number' ||
      !Number.isSafeInteger(loc.districtId) ||
      loc.districtId <= 0 ||
      typeof loc.label !== 'string' ||
      !loc.label.trim()
    ) {
      continue;
    }
    if (seenIds.has(loc.districtId)) continue;
    seenIds.add(loc.districtId);

    valid.push({
      districtId: loc.districtId,
      ...(typeof loc.subdistrictId === 'number' &&
      Number.isSafeInteger(loc.subdistrictId) &&
      loc.subdistrictId > 0
        ? { subdistrictId: loc.subdistrictId }
        : {}),
      label: loc.label.trim(),
      ...(typeof loc.provinceName === 'string' && loc.provinceName.trim()
        ? { provinceName: loc.provinceName.trim() }
        : {}),
      ...(typeof loc.cityName === 'string' && loc.cityName.trim()
        ? { cityName: loc.cityName.trim() }
        : {}),
      ...(typeof loc.districtName === 'string' && loc.districtName.trim()
        ? { districtName: loc.districtName.trim() }
        : {}),
      ...(typeof loc.subdistrictName === 'string' && loc.subdistrictName.trim()
        ? { subdistrictName: loc.subdistrictName.trim() }
        : {}),
      ...(typeof loc.postalCode === 'string' && loc.postalCode.trim()
        ? { postalCode: loc.postalCode.trim() }
        : {}),
    });
  }

  return valid;
}

export function sanitizeJntRates(rawRates: unknown): JntRateOption[] {
  if (!Array.isArray(rawRates)) return [];
  const valid: JntRateOption[] = [];

  for (const entry of rawRates) {
    if (!entry || typeof entry !== 'object') continue;
    const rate = entry as Partial<JntRateOption>;
    if (
      rate.courier !== 'jnt' ||
      typeof rate.serviceCode !== 'string' ||
      !rate.serviceCode.trim() ||
      typeof rate.cost !== 'number' ||
      !Number.isFinite(rate.cost) ||
      rate.cost < 0
    ) {
      continue;
    }
    valid.push({
      courier: 'jnt',
      courierName:
        typeof rate.courierName === 'string' && rate.courierName.trim()
          ? rate.courierName.trim()
          : 'J&T Express',
      serviceCode: rate.serviceCode.trim().toUpperCase(),
      serviceName:
        typeof rate.serviceName === 'string' && rate.serviceName.trim()
          ? rate.serviceName.trim()
          : rate.serviceCode.trim().toUpperCase(),
      ...(typeof rate.description === 'string' && rate.description.trim()
        ? { description: rate.description.trim() }
        : {}),
      cost: Math.round(rate.cost * 100) / 100,
      ...(typeof rate.etd === 'string' && rate.etd.trim()
        ? { etd: rate.etd.trim() }
        : {}),
      ...(typeof rate.cod === 'boolean' ? { cod: rate.cod } : {}),
    });
  }

  return valid.sort((a, b) => a.cost - b.cost);
}

export function selectDefaultJntRate(
  rates: JntRateOption[],
  preferredServiceCode?: string | null
): JntRateOption | null {
  const sorted = sanitizeJntRates(rates);
  if (sorted.length === 0) return null;

  const cleanPreferred =
    typeof preferredServiceCode === 'string'
      ? preferredServiceCode.trim().toUpperCase()
      : '';
  if (cleanPreferred) {
    const matched = sorted.find(
      (r) => r.serviceCode.toUpperCase() === cleanPreferred
    );
    if (matched) return matched;
  }

  // Rates are already sorted ascending by cost
  return sorted[0];
}

export function formatEtdLabel(etd?: string): string | null {
  if (typeof etd !== 'string') return null;
  const clean = etd.trim();
  if (!clean) return null;
  return /hari/i.test(clean) ? `Estimasi ${clean}` : `Estimasi ${clean} hari`;
}

export async function searchShippingLocations(params: {
  search: string;
  limit?: number;
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
}): Promise<ShippingLocationSearchResult> {
  const cleanSearch = params.search.trim().replace(/\s+/g, ' ');
  if (cleanSearch.length < 3) {
    return {
      ok: true,
      aborted: false,
      available: true,
      locations: [],
    };
  }

  const queryParams = new URLSearchParams({ search: cleanSearch });
  if (
    typeof params.limit === 'number' &&
    Number.isSafeInteger(params.limit) &&
    params.limit > 0
  ) {
    queryParams.set('limit', String(params.limit));
  }

  const fetchFn = params.fetchImpl ?? fetch;

  try {
    const response = await fetchFn(
      apiUrl(`/api/shipping/locations?${queryParams.toString()}`),
      {
        method: 'GET',
        cache: 'no-store',
        headers: { Accept: 'application/json' },
        signal: params.signal,
      }
    );

    const json = (await response.json().catch(() => ({}))) as Partial<
      ShippingLocationSearchResponse & { error?: string }
    >;

    if (!response.ok) {
      return {
        ok: false,
        aborted: false,
        statusCode: response.status,
        available: false,
        locations: [],
        errorMessage: mapShippingHttpError(
          response.status,
          json.error,
          'locations'
        ),
      };
    }

    const available = Boolean(json.available);
    const locations = sanitizeLocationOptions(json.locations);
    const reason =
      typeof json.reason === 'string' && json.reason.trim()
        ? json.reason.trim()
        : undefined;

    return {
      ok: true,
      aborted: false,
      statusCode: response.status,
      available,
      locations,
      ...(reason ? { reason } : {}),
    };
  } catch (err) {
    if (isShippingAbortError(err) || params.signal?.aborted) {
      return {
        ok: false,
        aborted: true,
        available: false,
        locations: [],
      };
    }
    return {
      ok: false,
      aborted: false,
      available: false,
      locations: [],
      errorMessage:
        'Gagal mencari kecamatan karena koneksi terganggu. Pesanan tetap dapat dikirim untuk dikonfirmasi Owner.',
    };
  }
}

export async function quoteJntShippingRates(params: {
  destinationDistrictId: number;
  items: CartItem[];
  signal?: AbortSignal;
  fetchImpl?: typeof fetch;
}): Promise<JntRateQuoteResult> {
  if (
    !Number.isSafeInteger(params.destinationDistrictId) ||
    params.destinationDistrictId <= 0 ||
    params.items.length === 0
  ) {
    return {
      ok: false,
      aborted: false,
      statusCode: 400,
      available: false,
      fallbackToManual: true,
      hasUnweighedItems: false,
      rates: [],
      errorMessage: 'Pilih kecamatan tujuan dan pastikan keranjang tidak kosong.',
    };
  }

  // Strictly send only destinationDistrictId and productId/quantity pairs
  const requestBody: ShippingRateQuoteRequest = {
    destinationDistrictId: params.destinationDistrictId,
    items: buildCartQuoteItems(params.items),
  };

  const fetchFn = params.fetchImpl ?? fetch;

  try {
    const response = await fetchFn(apiUrl('/api/shipping/jnt-rates'), {
      method: 'POST',
      cache: 'no-store',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify(requestBody),
      signal: params.signal,
    });

    const json = (await response.json().catch(() => ({}))) as Partial<
      ShippingRateQuoteResponse & { error?: string }
    >;

    if (!response.ok) {
      return {
        ok: false,
        aborted: false,
        statusCode: response.status,
        available: false,
        fallbackToManual: true,
        hasUnweighedItems: false,
        rates: [],
        errorMessage: mapShippingHttpError(response.status, json.error, 'rates'),
      };
    }

    const rates = sanitizeJntRates(json.rates);
    const available = Boolean(json.available) && rates.length > 0;
    const fallbackToManual = Boolean(json.fallbackToManual) || !available;
    const reason =
      typeof json.reason === 'string' && json.reason.trim()
        ? json.reason.trim()
        : undefined;

    return {
      ok: true,
      aborted: false,
      statusCode: response.status,
      available,
      fallbackToManual,
      hasUnweighedItems: Boolean(json.hasUnweighedItems),
      rates,
      ...(reason ? { reason } : {}),
      ...(typeof json.totalWeightGrams === 'number'
        ? { totalWeightGrams: json.totalWeightGrams }
        : {}),
      ...(json.normalizedWeightGrams !== undefined
        ? { normalizedWeightGrams: json.normalizedWeightGrams }
        : {}),
      ...(typeof json.itemsSubtotal === 'number'
        ? { itemsSubtotal: json.itemsSubtotal }
        : {}),
    };
  } catch (err) {
    if (isShippingAbortError(err) || params.signal?.aborted) {
      return {
        ok: false,
        aborted: true,
        available: false,
        fallbackToManual: true,
        hasUnweighedItems: false,
        rates: [],
      };
    }
    return {
      ok: false,
      aborted: false,
      available: false,
      fallbackToManual: true,
      hasUnweighedItems: false,
      rates: [],
      errorMessage:
        'Gagal menghitung tarif J&T karena koneksi terganggu. Pesanan tetap dapat dikirim dengan konfirmasi ongkir oleh Owner.',
    };
  }
}
