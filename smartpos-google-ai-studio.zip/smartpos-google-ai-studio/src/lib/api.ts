const rawApiBase = (import.meta.env.VITE_API_BASE_URL || '')
  .trim()
  .replace(/\/+$/, '');

/**
 * Resolves API endpoint paths cleanly for both single-host production deployments
 * (Cloud Run / Render, where Express serves dist/ and /api/* on the same origin)
 * and optional split-host deployments via VITE_API_BASE_URL.
 * Never defaults to localhost.
 */
export function apiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return rawApiBase ? `${rawApiBase}${normalizedPath}` : normalizedPath;
}
